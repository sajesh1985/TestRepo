// tslint:disable: import-blacklist
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ModelErrors } from '../../../shared/interfaces/model-errors';
import { ValidationManager } from '../../../shared/models/validation';
import { AppService } from '../../../core/services/app.service';
import { map, switchMap } from 'rxjs/operators';
import { OrganizationInformationService } from 'src/app/features-modules/organization-info/services/organization-information.service';
import { FinalistLocation, OrganizationInformation } from 'src/app/features-modules/organization-info/models/organization-information.model';

@Component({
  selector: 'app-finalist-location-edit',
  templateUrl: './finalist-location-edit.component.html',
  styleUrls: ['./finalist-location-edit.component.scss']
})
export class FinalistLocationEditComponent implements OnInit {  
  @Input() finalistLocation: FinalistLocation;
  @Input() organizationId: number;
  @Input() programId: number;
 //@ViewChild('mailingAddressComponent',{static:true}) private mailingAddressComponent: MailingAddressComponent;
  @Output() isInEditMode = new EventEmitter<any>();
  public isSaving = false;
  public disableSave = false;
  public hasSaveError = false;
  public mode = 'Add';
  public modelErrors: ModelErrors = {};
  public isLoaded = true;
  public isSectionValid = false;
  public isSectionModified = false;
  public hasTriedSave = false;
  public hadSaveError = false;
  public isEnding = false;
  public location: FinalistLocation;
  public useSuggestedAddress = false;
  public useEnteredAddress = false;
  public validationManager: ValidationManager = new ValidationManager(this.appService);
  public addressValidationManager: ValidationManager = new ValidationManager(this.appService);
  public currentProgram: any;
  public organization = new OrganizationInformation();
  public isReadOnly = false;
  public orgInfoId = 0;

  constructor(private appService: AppService, private orgInfoService: OrganizationInformationService) {}

  ngOnInit() {
      this.orgInfoService.modeForFinalistLocation.subscribe(res => {
          this.isReadOnly = res.readOnly;
          if (res.readOnly) {
            this.disableSave = true;
          } else {
            this.disableSave = false;
          }
          if(this.finalistLocation.id == 0)
          {
            this.newLocation();      
          }
          else
          {
            this.location = res.finalistLocation;
          }
          this.orgInfoId = res.orgInfoId;
      })  
  }

  newLocation() {
    const location = new FinalistLocation();    
    location.id = 0;
    this.location = location;
  }

  validate() {
    this.isSectionModified = true;
    if (this.hasTriedSave === true) {
      this.validationManager.resetErrors();
      const result = this.finalistLocation.validate(this.validationManager);
      this.isSectionValid = result.isValid;
      this.modelErrors = result.errors;
      if (this.modelErrors) {
        this.isSaving = false;
      }
    }
  }

  validateAddress() {    
     if(this.finalistLocation.finalistAddress)
     {
      this.addressValidationManager.resetErrors();
      const result = this.finalistLocation.finalistAddress.validate(this.validationManager);
      this.modelErrors = result.errors;
      if (result.isValid) {
        // If everything is valid, lets reset it.
        this.addressValidationManager.resetErrors();
      }
    }
  }

  exitFinalistLocationEditIgnoreChanges(e) {
    this.orgInfoService.modeForFinalistLocation.next({ readOnly: false, isInEditMode: false });
    this.isInEditMode.emit(false);
  }

  setSelectedAddress(selectedAddress : any) {
      this.useSuggestedAddress = selectedAddress.useSuggestedAddress;
      this.useEnteredAddress = selectedAddress.useEnteredAddress;
  }

  setFinalistAddress(finalistAddress : any) {
    this.location.finalistAddress = finalistAddress;
  }

  exit() {
    if (this.isSectionModified) {
      this.appService.isUrlChangeBlocked = false;
      this.appService.isDialogPresent = true;
    } else {
      this.orgInfoService.modeForFinalistLocation.next({ readOnly: false, isInEditMode: false });
      this.isInEditMode.emit(false);
    }
  }

  save() {
    if (this.isSectionValid) {
      this.isSaving = true;
      this.populateOrganisationContract();  
      this.orgInfoService.saveOrganizationInformation(this.organizationId, this.organization).subscribe(
        res => {
          this.orgInfoService.modeForFinalistLocation.next({ readOnly: false, isInEditMode: false });
          this.isSaving = false;
          this.isInEditMode.emit(false);
        },
        error => {
          this.isInEditMode.emit(true);
          this.isSaving = false;
        }
      );
    }
  }

  populateOrganisationContract()
  {
    this.organization.locations =[];
    this.organization.id = this.orgInfoId;
    this.organization.organizationId = this.organizationId;
    this.organization.programId = this.programId;

    if(this.location.id == 0)
    {      
      this.location.finalistAddress.useEnteredAddress = this.useEnteredAddress;
      this.location.finalistAddress.useSuggestedAddress = this.useSuggestedAddress;
      this.organization.locations.push(this.location);
    } 
    else
    {
      this.location.finalistAddress.useEnteredAddress = this.useEnteredAddress;
      this.location.finalistAddress.useSuggestedAddress = this.useSuggestedAddress;
      this.organization.locations.push(this.location);
    }
  }

  saveAndExit() {
    this.hasTriedSave = true;
    this.validate();
    this.save();
  }
}
