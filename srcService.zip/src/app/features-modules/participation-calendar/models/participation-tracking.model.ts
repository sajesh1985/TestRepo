import { ParticipationMakeup } from './participation-makeup.model';

export class ParticipationTracking {
  public Id: number;
  public epId: number;
  public activityId: number;
  public activityCd: string;
  public participationDate: string;
  public scheduledHours: number;
  public reportedHours: number;
  public totalMakeupHours: number;
  public participatedHours: number;
  public nonParticipatedHours: number;
  public goodCasusedHours: number;
  public nonParticipationReasonId: number;
  public nonParticipationReasonname: string;
  public nonParticipationReasonDetails: string;
  public goodCauseGranted: boolean;
  public goodCauseGrantedReasonId: number;
  public goodCauseGrantedReasonName: string;
  public goodCauseDeniedReasonId: number;
  public goodCauseDeniedReasonName: string;
  public goodCauseReasonDetails: string;
  public placementTypeId: number;
  public placementTypeName: string;
  public formalAssessmentExists: boolean;
  public hoursSactionable: boolean;
  public modifiedBy: string;
  public modifiedDate: string;
  public makeUpEntried: ParticipationMakeup;
}
