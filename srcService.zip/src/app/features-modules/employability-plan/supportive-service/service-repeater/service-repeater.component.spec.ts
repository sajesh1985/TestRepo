// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ServiceRepeaterComponent } from './service-repeater.component';

// describe('ServiceRepeaterComponent', () => {
//   let component: ServiceRepeaterComponent;
//   let fixture: ComponentFixture<ServiceRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ServiceRepeaterComponent]
//     }).compileComponents();
//   }));

//   beforeEach(() => {
//     // fixture = TestBed.createComponent(ServiceRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
