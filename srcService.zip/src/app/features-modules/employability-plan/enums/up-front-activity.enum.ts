export enum UpfrontActivityType {
  UE = 'UE',
  UR = 'UR',
  UC = 'UC'
}
