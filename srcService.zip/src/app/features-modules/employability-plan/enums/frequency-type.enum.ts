export enum FrequencyType {
  bw = 'Biweekly',
  wk = 'Weekly',

  mn = 'Monthly'
}
