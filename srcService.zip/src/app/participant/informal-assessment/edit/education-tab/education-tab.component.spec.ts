/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { EducationTabComponent } from './education-tab.component';

// describe('Component: EducationTab', () => {
//   it('should create an instance', () => {
//     let component = new EducationTabComponent();
//     expect(component).toBeTruthy();
//   });
// });
