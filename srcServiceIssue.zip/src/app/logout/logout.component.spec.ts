/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { LogoutComponent } from './logout.component';

// describe('Component: Logout', () => {
//   it('should create an instance', () => {
//     let component = new LogoutComponent();
//     expect(component).toBeTruthy();
//   });
// });
