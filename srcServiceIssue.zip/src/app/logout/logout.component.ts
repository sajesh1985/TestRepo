import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../core/services/app.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  constructor(private router: Router, private appService: AppService) {}

  ngOnInit() {
    this.appService.logoutUser();
    this.router.navigateByUrl('login');
  }
}
