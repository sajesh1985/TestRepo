import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-non-participation-details',
  templateUrl: './non-participation-details.component.html',
  styleUrls: ['./non-participation-details.component.scss']
})
export class NonParticipationDetailsComponent implements OnInit {
  
  @Output() closeDetails = new EventEmitter<any>();

  public events: any;
  public goBackUrl: string = '';
  public pageTitle: string = 'Non-Participation/Good Cause Details';
  public pin;
  public isLoaded = true;

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    forkJoin(this.route.params.pipe(take(1))).subscribe(result => {
      this.pin = result[0].pin;
      this.goBackUrl = '/pin/' + this.pin;
    });
  } 
  
  close() {
    this.closeDetails.emit(false);
  }
}
