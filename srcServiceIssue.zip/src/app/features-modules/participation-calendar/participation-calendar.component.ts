import { Component, OnInit } from '@angular/core';

import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { take, concatMap } from 'rxjs/operators';
import { ParticipationTracking } from './models/participation-tracking.model';
import { AppService } from 'src/app/core/services/app.service';
import { ParticipantService } from 'src/app/shared/services/participant.service';
import { ParticipationTrackingService } from './services/participation-tracking.service';

@Component({
  selector: 'app-participation-calendar',
  templateUrl: './participation-calendar.component.html',
  styleUrls: ['./participation-calendar.component.scss']
})
export class ParticipationCalendarComponent implements OnInit {
  public showCalendar = true;
  public momentDate = moment(new Date()).toDate();
  public viewDate: any;
  public events: any;

  public PTDetails: ParticipationTracking[];
  public participantId: number;
  public goBackUrl: string;
  public pin;
  public iseventsLoaded = false;
  // this is  only for Participation Tracking.

  constructor(private route: ActivatedRoute, private appService: AppService, private partService: ParticipantService, private ptService: ParticipationTrackingService) {}

  ngOnInit() {
    this.route.params
      .pipe(
        concatMap(result => {
          this.pin = result.pin;
          this.goBackUrl = '/pin/' + this.pin;
          return this.partService.getCachedParticipant(this.pin);
        })
      )
      .subscribe(res => {
        this.participantId = res.id;
        this.ptService.viewDate.next({ viewDate: moment(new Date(this.momentDate.getFullYear(), this.momentDate.getMonth(), 16)).toDate() });
        this.getEvents();
      });
  }

  showCalendarView() {
    this.showCalendar = !this.showCalendar;
  }
  closeCalendar(e: boolean) {
    this.showCalendar = e;
  }
  nextMonthClicked(e) {
    this.ptService.viewDate.next({ viewDate: e });
    this.getEvents();
  }
  previousMonthClicked(e) {
    this.ptService.viewDate.next({ viewDate: e });
    this.getEvents();
  }
  getEvents() {
    let startDate;
    let endDate;
    this.ptService.viewDate.subscribe(res => {
      this.viewDate = res.viewDate;
      startDate = moment(res.viewDate).format('MMDDYYYY');
      // ToDo: subtract one day here
      endDate = moment(this.viewDate)
        .add(1, 'M')
        .format('MMDDYYYY');
    });
    this.ptService.getParticipationTrackingDetails(this.pin, this.participantId, startDate, endDate).subscribe(res => {
      this.iseventsLoaded = true;
      this.events = res;
    });
  }
}
