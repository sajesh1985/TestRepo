import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, NavigationExtras, Router } from '@angular/router';
import { Observable, of } from 'rxjs';

import { AppService } from 'src/app/core/services/app.service';
import { AccessType } from '../../../shared/enums/access-type.enum';
import { ParticipantService } from '../../../shared/services/participant.service';
import { flatMap, map } from 'rxjs/operators';

@Injectable()
export class WorkHistoryAppGuard implements CanActivate {
  constructor(private router: Router, private appService: AppService, private participantService: ParticipantService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    let pin = route.parent.params['pin'];
    if (pin === undefined) {
      pin = route.params['pin'];
    }
    let canActivate;
    // Check if the user has a special Authorization that allows app access across
    if (pin) {
      canActivate = this.participantService.getCachedParticipant(pin).pipe(
        flatMap(p => {
          // const accessType = this.appService.getWorkHistoryAppAccess(p);
          const accessType = AccessType.view;

          if (accessType === AccessType.view || accessType === AccessType.edit) {
            return of(true);
          }

          this.reRouteToUnauthorized(state.url, this.appService.user.authorizations);
          return of(false);
        })
      );
    } else {
      this.reRouteToUnauthorized(state.url, this.appService.user.authorizations);
      canActivate = of(false);
    }

    return canActivate;
  }

  private reRouteToUnauthorized(url: string, authorizations: string[]): void {
    const navigationExtras: NavigationExtras = {
      queryParams: {
        url: url,
        guard: 'work-history-app-guard',
        authorizations: JSON.stringify(authorizations)
      }
    };

    this.router.navigate(['/unauthorized'], navigationExtras);
  }
}
