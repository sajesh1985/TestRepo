import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { OrganizationInformationRoutingModule } from './organization-information-routing.module';
import { FinalistLocationEditComponent } from './edit/finalist-location-edit.component';
import { FinalistLocationListComponent } from './list/finalist-location-list.component';
import { OrganizationInformationComponent } from './organization-information.component';
import { OrganizationInformationService } from './services/organization-information.service';

@NgModule({
  imports: [CommonModule, SharedModule,  OrganizationInformationRoutingModule],
  declarations: [FinalistLocationEditComponent, FinalistLocationListComponent, OrganizationInformationComponent],
  providers: [OrganizationInformationService]
})
export class OrganizationInformationModule {}
