// tslint:disable: import-blacklist
import { Component, OnInit, Input, Output, EventEmitter,ViewChild } from '@angular/core';
import { ModelErrors } from '../../../shared/interfaces/model-errors';
import { ValidationManager } from '../../../shared/models/validation';
import { AppService } from '../../../core/services/app.service';
import { OrganizationInformationService } from 'src/app/features-modules/organization-info/services/organization-information.service';
import { FinalistLocation, OrganizationInformation } from 'src/app/features-modules/organization-info/models/organization-information.model';
import { FinalistAddress } from 'src/app/shared/models/finalist-address.model';

@Component({
  selector: 'app-finalist-location-edit',
  templateUrl: './finalist-location-edit.component.html',
  styleUrls: ['./finalist-location-edit.component.scss']
})
export class FinalistLocationEditComponent implements OnInit {  
  @Input() finalistLocation: FinalistLocation;
  @Input() organizationId: number;
  @Input() programId: number;
  
  @Output() isInEditMode = new EventEmitter<any>();  

  public isSaving = false;
  public modelErrors: ModelErrors = {};
  public isLoaded = true;
  public isSectionValid = false;
  public isAddressSectionValid = false;
  public isSectionModified = false;
  public isAddressSectionModified = false;
  public hadSaveError = false;
  public location: FinalistLocation;
  public useSuggestedAddress = false;
  public useEnteredAddress = false;
  public validationManager: ValidationManager = new ValidationManager(this.appService);
  public organization = new OrganizationInformation();
  public isReadOnly = false;
  public orgInfoId = 0;
  public isAddressValidated = false;

  constructor(private appService: AppService, private orgInfoService: OrganizationInformationService) {}

  ngOnInit() {
      this.orgInfoService.modeForFinalistLocation.subscribe(res => {
          this.isReadOnly = res.readOnly;          
          if(this.finalistLocation.id == 0)
          {
            this.newLocation();      
          }
          else
          {
            this.location = res.finalistLocation;
            this.isAddressValidated = true;
            this.isSectionValid = true;
          }
          this.orgInfoId = res.orgInfoId;
      })  
  }
  
  /**
   * Initializes the finalistlocation
   */
  newLocation() {
    const location = new FinalistLocation();    
    location.id = 0;
    this.location = location;
  }

  /**
   * Invoked when there is address update on MailingAddressComponent
   */
  validateAddress(finalistAddress : FinalistAddress) { 
      if(finalistAddress)
      {
        this.location.finalistAddress = finalistAddress;
        this.isAddressValidated = this.location.finalistAddress.isAddressValidated;
        this.isAddressSectionModified = true;
      } 
      this.validationManager.resetErrors();
      const resultAddress = this.location.finalistAddress.validate(this.validationManager);
      const result = this.location.validate(this.validationManager);
      this.isAddressSectionValid = result.isValid;
      Object.assign(resultAddress.errors,result.errors);
      this.modelErrors = resultAddress.errors;

  }
 
  /**
   * Invoked when there is update on End Date and EffectiveDate
   */
  validate() {
    this.isSectionModified = true;
    this.validationManager.resetErrors();
    const result = this.location.validate(this.validationManager);
    const resultAddress = this.location.finalistAddress.validate(this.validationManager);
    this.isSectionValid = result.isValid;
    Object.assign(result.errors,resultAddress.errors);
    this.modelErrors = result.errors;
    if (this.modelErrors) {
      this.isSaving = false;
    }
  }

  /**
   * Invoked when selects Ignore changes from the save confirmation
   */
  exitFinalistLocationEditIgnoreChanges(e) {
    this.orgInfoService.modeForFinalistLocation.next({ readOnly: false, isInEditMode: false });
    this.isInEditMode.emit(false);
  }
  
  /**
   * Invoked when user select Address radio button is fired in the MailingAddressComponent
   */
  setSelectedAddress(selectedAddress : any) {
      this.isAddressSectionValid = true;
      this.useSuggestedAddress = selectedAddress.useSuggestedAddress;
      this.useEnteredAddress = selectedAddress.useEnteredAddress;
  }
  
  /**
   * Invoked when user select Address radio button is fired in the MailingAddressComponent
   */
  setFinalistAddress(finalistAddress : any) {
    this.isAddressSectionValid = true;
    this.location.finalistAddress = finalistAddress;
  }

  /**
   * Invoked when Save is clicked
   */
  save() {
    if (this.isSectionValid && this.isAddressSectionValid && this.isAddressValidated) {
      this.isSaving = true;
      this.populateOrganisationContract(); 
      //Invoke save service call 
      this.orgInfoService.saveOrganizationInformation(this.organizationId, this.organization).subscribe(
        res => {
          this.orgInfoService.modeForFinalistLocation.next({ readOnly: false, isInEditMode: false });
          this.isSaving = false;
          this.isInEditMode.emit(false);
        },
        error => {
          this.isInEditMode.emit(true);
          this.isSaving = false;
          this.hadSaveError = true;
        }
      );
    }
  }
  
  /**
   * Reconstruct the Organization object
   */
  populateOrganisationContract()
  {
    this.organization.locations =[];
    this.organization.id = this.orgInfoId;
    this.organization.organizationId = this.organizationId;
    this.organization.programId = this.programId;

    if(this.location.id == 0)
    {      
      this.location.finalistAddress.useEnteredAddress = this.useEnteredAddress;
      this.location.finalistAddress.useSuggestedAddress = this.useSuggestedAddress;
      this.organization.locations.push(this.location);
    } 
    else
    {
      this.location.finalistAddress.useEnteredAddress = this.useEnteredAddress;
      this.location.finalistAddress.useSuggestedAddress = this.useSuggestedAddress;
      this.organization.locations.push(this.location);
    }
  }
   
  /**
   * Invoked when Save is clicked
   */
  saveAndExit() {    
    this.validate();
    this.save();
  }
  
  /**
   * Invoked when Exit button is clicked from the modal popup
   */
  exit() {
    if (this.isSectionModified) {
      this.appService.isUrlChangeBlocked = false;
      this.appService.isDialogPresent = true;
    } else {
      this.orgInfoService.modeForFinalistLocation.next({ readOnly: false, isInEditMode: false });
      this.isInEditMode.emit(false);
    }
  }
}
