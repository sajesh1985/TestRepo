import { Config } from '@jest/types';

const config: Config.InitialOptions = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',

  rootDir: 'src',

  transform: {
    '^.+\\.tsx?$': 'ts-jest',
  },

  setupFilesAfterEnv: ['@testing-library/jest-dom', '<rootDir>/setupTests.ts'],

  moduleNameMapper: {
    '\\.(css|less)$': 'identity-obj-proxy',
  },
  collectCoverage: true,
  coverageDirectory: 'test-coverage',
  // coverageThreshold: {
  //   global: {
  //     branches: 65,
  //     functions: 50,
  //     lines: 75,
  //   },
  // },
  collectCoverageFrom: ['<rootDir>/**/*.{ts,tsx}'],
  coveragePathIgnorePatterns: [
    '<rootDir>/assets',
    '<rootDir>/i18n',
    '<rootDir>/interfaces',
    '<rootDir>/locales',
    '<rootDir>/styles',
    '<rootDir>/types',
  ],
  coverageReporters: ['cobertura', 'lcov'],
};

export default config;
