// Generated using webpack-cli https://github.com/webpack/webpack-cli

const path = require('path');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { ModuleFederationPlugin } = require('webpack').container;
const { SourceMapSymbolServerPlugin } = require('@spglobal/sourcemapsymbolserverplugin');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

const { NODE_ENV } = process.env;
const isProduction = NODE_ENV == 'production';

const config = {
  entry: './src/entry/RatingsCriteria/entry.tsx',
  output: {
    publicPath: 'auto',
    path: path.resolve(__dirname, 'dist'),
  },
  mode: 'development',
  devtool: 'inline-source-map',
  devServer: {
    allowedHosts: 'all',
    devMiddleware: {
      writeToDisk: true,
    },
    compress: true,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization',
    },
    static: './dist',
    port: 8888,
  },
  plugins: [
    // To learn more about the usage of this plugin, please visit https://webpack.js.org/plugins/module-federation-plugin/
    new ModuleFederationPlugin({
      name: 'mfeRatingsDirect',
      filename: 'remoteEntry.js',
      exposes: {
        './RatingsCriteria': './src/entry/RatingsCriteria/entry.tsx',
        './AnalyticalContacts':'./src/entry/AnalyticalContacts/entry.tsx',
        './ChatRD':'./src/entry/ChatRD/entry.tsx'
      },
      shared: [
        //https://www.angulararchitects.io/en/aktuelles/getting-out-of-version-mismatch-hell-with-module-federation/
        { axios: { singleton: true, requiredVersion: false } },
        { react: { singleton: true, requiredVersion: false } },
        { 'react-dom': { singleton: true, requiredVersion: false } },
        { 'react-i18next': { singleton: true, requiredVersion: false } },
        { 'react-redux': { singleton: true, requiredVersion: false } },
        { 'react-router-dom': { singleton: true, requiredVersion: false } },
        { redux: { singleton: true, requiredVersion: false } },
        { i18next: { singleton: true, requiredVersion: false } },
        { '@emotion/react': { singleton: true, requiredVersion: false } },
        { '@emotion/css': { singleton: true, requiredVersion: false } },
        { '@emotion/cache': { singleton: true, requiredVersion: false } },
        { '@emotion/serialize': { singleton: true, requiredVersion: false } },
        { '@spglobal/react-components': { singleton: true, requiredVersion: false } },
        { '@spglobal/koi-icons': { singleton: true, requiredVersion: false } },
        { '@spglobal/spa': { singleton: true, requiredVersion: false } },
        { '@spglobal/koi-helpers': { singleton: true, requiredVersion: false } },
        { '@spglobal/tokens/': { singleton: true, requiredVersion: false } },
        { '@spglobal/loggingservice': { singleton: true, requiredVersion: false } },
        { '@spglobal/dataapiservice': { singleton: true, requiredVersion: false } },
        { '@spglobal/featureflags': { singleton: true, requiredVersion: false } },
        { '@spglobal/userprofileservice': { singleton: true, requiredVersion: false } },
        { '@spglobal/exportservice': { singleton: true, requiredVersion: false } },
        { '@spglobal/healthcheck': { singleton: true, requiredVersion: false } },
        { 'redux-injectors': { singleton: true, requiredVersion: false } },
        { '@reduxjs/toolkit': { singleton: true, requiredVersion: false } },
      ],
    }),
  ],
  module: {
    rules: [
      {
        test: /\.(ts|tsx)$/i,
        loader: 'ts-loader',
        options: {
          allowTsInNodeModules: true,
        },
      },
      {
        test: /\.(svg|png|jpg|gif)$/i,
        type: 'asset',
      },
    ],
  },
  resolve: {
    extensions: ['.tsx', '.ts', '.js'],
  },
};

module.exports = (env: { analyze?: 0 | undefined }) => {
  const { analyze = 0 } = env;
  if (isProduction) {
    config.mode = 'production';
    config.devtool = 'nosources-source-map';
    config.plugins.push(new MiniCssExtractPlugin());
    config.plugins.push(new SourceMapSymbolServerPlugin());
  }
  if (analyze) {
    config.plugins.splice(0, 0, new BundleAnalyzerPlugin());
  }
  console.log(`starting ${config.mode} build`);
  return config;
};
