import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';
import { Breakpoints } from '@spglobal/tokens';

export const Header = styled.div`
  text-align: center;
  margin: 0 var(--size-space-2xl);
  background: var(--color-bg-primary);
  @media (max-width: ${Breakpoints.MD}) {
    margin: 0 var(--size-space-lg);
    padding: var(--size-space-lg);
  }
  .${DARK} & {
    border-color: var(--color-base-gray-80);
  }
`;

export const Title = styled.h5`
  display: block;
  margin: 0;
  padding: var(--size-space-2xl) 0;
`;

export const Content = styled.div`
  max-width: 574px;
  margin: auto;
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: var(--size-space-sm);
  padding: 0 var(--size-space-md) var(--size-space-2xl);
`;

export const Example = styled.div`
  background: var(--color-bg-secondary);
  border: 1px solid var(--color-border-primary);
  justify-content: space-between;
  display: flex;
  align-items: center;
  cursor: pointer;
  min-width: 200px;
  color: var(--color-text-link);
  padding: var(--size-space-lg);
  gap: var(--size-space-sm);
  flex: 1;

  &:hover {
    background-color: var(--color-bg-hover);
  }

  & > span {
    text-align: left;
    font: var(--font-body-sm);
  }

  & > [data-icon] {
    color: var(--color-text-link);
  }
  .${DARK} & {
    border-color: var(--color-base-gray-80);
  }
`;

export const InlineExample = styled.div`
  display: flex;
  margin-top: var(--size-space-xl);
  gap: var(--size-space-sm);
  flex: 1;
  flex-wrap: wrap;
`;

export const Status = styled.div`
  display: inline-block;
  background: var(--color-base-gray-5);
  font-size: var(--size-font-1);
  font-weight: var(--font-weight-bold);
  padding: var(--size-space-xs) var(--size-space-sm);
  padding-top: 5px;
  border-radius: 5px;
  letter-spacing: var(--font-letter-space-10);
  margin: auto;
  color: var(--color-text-secondary);
  .${DARK} & {
    background: var(--color-base-black);
  }
`;

export const NewContent = styled.div`
  max-width: 1200px;
  margin: auto;
  text-align: left;
  display: flex;
  flex-direction: column;
  gap: var(--size-space-5xl);
  padding: var(--size-space-3xl) var(--size-space-xl);
  h2 {
    margin-bottom: var(--size-space-2xl);
    span {
      color: var(--color-core-red);
    }
  }
  .darkImage {
    display: none;
  }
  .lightImage {
    display: block;
  }
  .${DARK} & {
    .lightImage {
      display: none;
    }
    .darkImage {
      display: block;
    }
  }
`;
export const ExampleBoxWrapper = styled.div`
  display: flex;
  gap: var(--size-space-lg);
  width: 100%;
  flex-wrap: wrap;
  padding-top: var(--size-space-xl);
  padding-bottom: var(--size-space-xl);
  @media (max-width: ${Breakpoints.LG}) {
    padding: var(--size-space-lg);
  }
`;
export const ExampleBox = styled.div`
  flex: 1;
  min-width: 280px;
  border-radius: 12px;
  overflow: hidden;
  background: var(--color-base-white);
  box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.07);
  .${DARK} & {
    background: #2d2d2d;
    box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.15);
  }
`;
export const ExampleBoxHead = styled.div`
  padding: var(--size-space-lg);
  display: flex;
  gap: 10px;
  align-items: center;
  align-content: center;
  background: var(--color-base-gray-1);
  > svg > circle {
    stroke: var(--color-base-gray-20);
  }
  > svg > path {
    fill: var(--color-base-gray-50);
  }
  > span {
    font-size: var(--size-font-3);
    color: var(--color-base-black);
  }
  .${DARK} & {
    background: var(--color-dark-gray-75);
    > svg > circle {
      stroke: var(--color-base-gray-65);
    }
    > svg > path {
      fill: var(--color-base-gray-20);
    }
    > span {
      color: var(--color-base-gray-11);
    }
  }
`;
export const ExampleBoxLists = styled.div`
  padding: var(--size-space-xs) var(--size-space-lg);
`;
export const ExampleList = styled.div`
  padding-bottom: var(--size-space-md);
  padding-top: var(--size-space-md);
  border-bottom: 1px solid var(--color-base-gray-11);
  display: flex;
  justify-content: space-between;
  font-size: var(--size-font-3);
  color: var(--color-text-link);
  cursor: pointer;
  gap: 5px;
  align-items: center;
  > span {
    text-align: left;
    line-height: var(--scale-line-height-150);
  }
  & > [data-icon] {
    color: var(--color-text-link);
  }
  &:last-child {
    border: none;
  }
  .${DARK} & {
    border-color: #3b3b3b;
  }
`;

export const FaqDesclimer = styled.div`
  text-align: center;
  display: flex;
  align-items: center;
  align-content: center;
  gap: var(--size-space-2xl);
  margin-top: var(--size-space-xl);
  margin-bottom: var(--size-space-xl);
  justify-content: center;
  button {
    display: flex;
    gap: 5px;
    font-weight: normal;
  }
`;

export const ChatRDModel = styled.div`
  display: flex;
  gap: 53px;
  flex-wrap: wrap;
  align-items: center;
  > div {
    flex: 1;
    img {
      width: 100%;
    }
  }
  h4 {
    font-size: var(--size-font-8);
    margin-bottom: var(--size-space-2xl);
  }
  ul {
    margin-bottom: var(--size-space-2xl);
    li {
      font-size: var(--size-font-3);
      margin-bottom: var(--size-space-lg);
    }
  }
  p {
    font-size: var(--size-font-3);
  }
`;
export const Suggestions = styled.div`
  display: inline-flex;
  align-items: flex-start;
  align-content: flex-start;
  gap: 10px;
  flex-wrap: wrap;
`;
export const SuggestionsChip = styled.span`
  display: flex;
  padding: 18px 25px;
  justify-content: center;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  border-radius: var(--size-radius-3);
  background: #e9e9e9;
  box-shadow: 0px 4px 8px 0px rgba(105, 105, 105, 0.05);
  color: var(--color-text-link);
  font-size: var(--size-font-3);
  .${DARK} & {
    background: #2d2d2d;
    box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.15);
  }
`;

export const SliderMain = styled.div`
  .red {
    color: #d6002a;
  }

  .animation {
    -webkit-transition: 0.35s ease-in-out;
    -moz-transition: 0.35s ease-in-out;
    -o-transition: 0.35s ease-in-out;
    transition: 0.35s ease-in-out;
  }
`;
export const SliderImgWrap = styled.div`
  position: relative;
  width: 505px;
  height: 445px;
  overflow: hidden;

  .images {
    position: relative;
    z-index: 1;
    height: 100%;
    width: 100%;

    .illustrative-1,
    .illustrative-2,
    .illustrative-3,
    .illustrative-4 {
      width: 100%;
      position: absolute;
      top: 55px;
      right: 0;
    }
    .illustrative-2,
    .illustrative-3,
    .illustrative-4 {
      opacity: 0;
      visibility: hidden;
      left: -280px;
      width: 271px;
      top: auto;
      bottom: 0;
    }
    .illustrative-3 {
      width: 238px;
      -webkit-transition: 0.45s ease-in-out;
      -moz-transition: 0.45s ease-in-out;
      -o-transition: 0.45s ease-in-out;
      transition: 0.45s ease-in-out;
    }
    .illustrative-4 {
      width: 278px;
      top: 38px;
    }
  }

  &.slide-2 {
    .images .illustrative-3 {
      left: 55px;
      opacity: 1;
      visibility: visible;
      bottom: 59px;
    }
    .images .illustrative-1 {
      width: 297px;
    }
  }

  &.slide-2 .images .illustrative-2,
  &.slide-3 .images .illustrative-2 {
    left: 45px;
    opacity: 1;
    visibility: visible;
  }

  &.slide-3 {
    .images .illustrative-1,
    .images .illustrative-3 {
      opacity: 0;
      visibility: hidden;
    }
    .images .illustrative-1 {
      width: 30%;
    }
    .images .illustrative-2 {
      width: 314px;
      left: 150px;
    }
    .images .illustrative-4 {
      width: 278px;
      -webkit-transition: 0.45s ease-in-out;
      -moz-transition: 0.45s ease-in-out;
      -o-transition: 0.45s ease-in-out;
      transition: 0.45s ease-in-out;
      opacity: 1;
      visibility: visible;
      left: 160px;
      top: 38px;
    }
  }
`;

export const Slider = styled.div`
  position: relative;
  display: flex;
  flex-wrap: wrap;
  gap: 80px;
  align-items: center;
  justify-content: space-between;
`;

export const SliderText = styled.div`
  font-size: 20px;
  line-height: 160%;
  flex: 1;
  min-width: 200px;
`;

export const SliderImgWrapCircle = styled.div`
  position: absolute;
  top: calc(50% - 181px);
  width: 362px;
  height: 362px;
  left: calc(50% - 181px);
  background: #e9e9e9;
  border-radius: 50%;
  .${DARK} & {
    background: #1b1b1b;
  }
`;
export const SliderDots = styled.div`
  display: flex;
  justify-content: center;
  gap: 10px;
  align-items: center;
  span {
    cursor: pointer;
    display: inline-block;
  }
  span:not([data-icon]) {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 1px solid #737676;
    &.active {
      background: #347bb7;
      border-color: #347bb7;
    }
  }
`;
