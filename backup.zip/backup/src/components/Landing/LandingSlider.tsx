import React from 'react';
import {
  Slider,
  SliderDots,
  SliderImgWrap,
  SliderImgWrapCircle,
  SliderMain,
  SliderText,
} from './Landing.styles';
import { ANGLE_LEFT, ANGLE_RIGHT } from '@spglobal/koi-icons';
import { Icon } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';

export const LandingSlider: React.FC = () => {
  const [slide, setSlide] = React.useState<number>(1);

  return (
    <SliderMain>
      <Slider>
        <SliderImgWrap className={`slide-${slide}`}>
          <SliderImgWrapCircle />
          <div className="images darkImage">
            <img
              src={require('../../assets/images/illustrative1.svg')}
              className="illustrative-1 animation"
            />
            <img
              src={require('../../assets/images/illustrative2.svg')}
              className="illustrative-2 animation"
            />
            <img
              src={require('../../assets/images/illustrative3.svg')}
              className="illustrative-3 animation"
            />
            <img
              src={require('../../assets/images/illustrative4.svg')}
              className="illustrative-4 animation"
            />
          </div>
          <div className="images lightImage">
            <img
              src={require('../../assets/images/illustrative1Light.svg')}
              className="illustrative-1 animation"
            />
            <img
              src={require('../../assets/images/illustrative2Light.svg')}
              className="illustrative-2 animation"
            />
            <img
              src={require('../../assets/images/illustrative3.svg')}
              className="illustrative-3 animation"
            />
            <img
              src={require('../../assets/images/illustrative4.svg')}
              className="illustrative-4 animation"
            />
          </div>
        </SliderImgWrap>
        <SliderText>
          {slide == 1 && (
            <div>
              Chat<span className="red">RD</span> is trained to answer questions about companies,
              markets and finance. Chat<span className="red">IQ</span> exclusively uses information
              provided by S&P Global Market Intelligence.
            </div>
          )}
          {slide == 2 && (
            <div>
              What can Chat<span className="red">RD</span> do?
              <br />
              Answer questions about a company, or industry. Search transcripts and documents. Find
              recent acquisitions and deals.
            </div>
          )}
          {slide == 3 && (
            <div>
              Chat<span className="red">RD</span> is currently in training and not intended to
              provide financial advice. Your feedback will help us make Chat
              <span className="red">RD</span> better and better.
            </div>
          )}
        </SliderText>
      </Slider>
      <SliderDots>
        <Icon
          color="var(--color-text-primary)"
          size={Size.XXSMALL}
          icon={ANGLE_LEFT}
          className={'arrow-back'}
          onClick={() => {
            const prev = slide > 1 ? slide - 1 : 3;
            setSlide(prev);
          }}
        />
        <span className={slide == 1 ? 'active' : ''} onClick={() => setSlide(1)}></span>
        <span className={slide == 2 ? 'active' : ''} onClick={() => setSlide(2)}></span>
        <span className={slide == 3 ? 'active' : ''} onClick={() => setSlide(3)}></span>
        <Icon
          color="var(--color-text-primary)"
          size={Size.XXSMALL}
          icon={ANGLE_RIGHT}
          className={'arrow-next'}
          onClick={() => {
            const next = slide < 3 ? slide + 1 : 1;
            setSlide(next);
          }}
        />
      </SliderDots>
    </SliderMain>
  );
};
