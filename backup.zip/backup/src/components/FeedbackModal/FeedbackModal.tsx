import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  ModalHeader,
  ModalContent,
  Button,
  Modal,
  useNotification,
  NotificationType,
  ChoiceList,
  ChoiceCapsule,
} from '@spglobal/react-components';
import { Purpose, Size } from '@spglobal/koi-helpers';

import { useChatRD } from '../../context/chatrd';
import { interactionFeedback, sessionFeedback } from '../../services/api';
import { Footer, FeedbackText, FeedbackTextLabel, FeedbackLogo } from './FeedbackModal.styles';
import { Sentiment, Tag } from '../../types/interaction';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  interactionId?: string;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  isOpen,
  onClose,
  interactionId = '',
}) => {
  const { t } = useTranslation(['chatiq_main']);
  const [isLoading, setLoading] = React.useState<boolean>(false);
  const [feedback, setFeedback] = React.useState<string>('');
  const { session } = useChatRD();
  const { addNotification } = useNotification();
  const { updateInteraction } = useChatRD();
  const [feedbackCategory, setFeedbackCategory] = React.useState<Tag[]>([]);
  const submitFeedback = async () => {
    setLoading(true);

    try {
      if (interactionId !== '') {
        await interactionFeedback(interactionId, {
          sentiment: Sentiment.Negative,
          text: feedback,
          tags: feedbackCategory,
        });
        updateInteraction(interactionId, {
          feedback: { sentiment: Sentiment.Negative, text: feedback, tags: feedbackCategory },
        });
      } else {
        await sessionFeedback(session, {
          sentiment: Sentiment.None,
          text: feedback,
          tags: feedbackCategory,
        });
      }
      addNotification(
        t('feedbackModal.sucessToastMessage'),
        NotificationType.SUCCESS,
        () => {
          return;
        },
        3000,
        false
      );
    } catch (error) {
      addNotification(
        t('feedbackModal.failToastMessage'),
        NotificationType.ERROR,
        () => {
          return;
        },
        3000,
        false
      );
    }

    setLoading(false);
    onClose();
  };

  return (
    <Modal
      ariaLabel={t('feedbackModal.title')}
      autoFocus
      canEscapeKeyClose
      enforceFocus
      hasBackdrop
      usePortal
      isOpen={isOpen}
      size={Size.LARGE}
    >
      <ModalHeader title={<FeedbackLogo small>Feedback</FeedbackLogo>}></ModalHeader>
      <ModalContent>
        <FeedbackTextLabel htmlFor="feedbackText">Tell us about your Chat RD experience</FeedbackTextLabel>
        <ChoiceList
          capsuleSize={Size.MEDIUM}
          isCheckIcon
          multiselect
          onChange={(data: any) => {
            setFeedbackCategory(data);
          }}
          skeletonConfig={{
            animation: true,
            loading: false,
          }}
        >
          <ChoiceCapsule label="Data not accurate" value={Tag.Accuracy} />
          <ChoiceCapsule label="Response incomplete" value={Tag.Completeness} />
        </ChoiceList>
        <FeedbackText
          id="feedbackText"
          aria-label="textareaLabel"
          maxRows={20}
          minRows={10}
          name="feedback"
          placeholder="Optional Details"
          rows={10}
          value={feedback}
          onInput={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFeedback(e.target.value)}
        />
      </ModalContent>
      <Footer>
        <Button
          onClick={submitFeedback}
          purpose={Purpose.PRIMARY}
          loading={isLoading}
          disabled={
            interactionId == '' ? feedback == '' : feedback == '' && feedbackCategory.length == 0
          }
          text="Submit"
        />
        <Button
          onClick={onClose}
          purpose={Purpose.SECONDARY}
          text="Cancel"
        />
      </Footer>
    </Modal>
  );
};
