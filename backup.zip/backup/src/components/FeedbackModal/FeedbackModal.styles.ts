import styled from '@emotion/styled';
import { TextArea } from '@spglobal/react-components';
import { Breakpoints } from '@spglobal/tokens';
import { Logo } from '../_common/Logo/Logo';
import { DARK } from '@spglobal/koi-helpers';

export const FeedbackLogo = styled(Logo)`
  font-weight: bold;
`;

export const FeedbackTextLabel = styled.label`
  display: block;
  margin-bottom: var(--size-space-sm);
  font-size: var(--size-font-3);
`;

export const FeedbackText = styled(TextArea)`
  && {
    width: 100%;
    @media (max-width: ${Breakpoints.MD}) {
      font-size: 16px;
    }
  }
`;

export const Footer = styled.div`
  border-top: 1px solid var(--color-border-primary);
  display: flex;
  padding: 1rem;
  gap: 12px;
  justify-content: end;
  .${DARK} & {
    &:nth-child(even) {
      border-color: var(--color-base-gray-80);
    }
  }
`;
