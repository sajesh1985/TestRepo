import React from 'react';
import {
  ContentType,
  KnowledgeDiscoveryResponseNode,
  TableResponseNode,
  TextResponseNode,
} from '../../../types/api';
import { DivformattedContent } from '../Content';
import { TableView } from '../TableView/TableView';
import { KnowledgeDiscoveryView } from '../KnowledgeDiscoveryView/KnowledgeDiscoveryView';

interface ResponseViewProps {
  data: Array<TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode>;
}

export const ResponseView: React.FC<ResponseViewProps> = ({ data }) => {
  const dataType = data?.map(
    (value: TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode, id) => {
      switch (value.type) {
        case ContentType.Table:
          return {
            element: <TableView key={id} columns={value.columns} rows={value.rows} />,
          };
        case ContentType.KnowledgeDiscovery:
          return {
            element: (
              <KnowledgeDiscoveryView key={id} answer={value.answer} documents={value.documents} />
            ),
          };
        default:
          return {
            element: <DivformattedContent key={id}>{value.content}</DivformattedContent>,
          };
      }
    }
  );

  return <>{dataType.map((item) => item.element)}</>;
};
