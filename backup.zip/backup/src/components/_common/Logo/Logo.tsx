import React from 'react';
import { Container } from './Logo.styles';

interface LogoProps extends React.ComponentPropsWithoutRef<'div'> {
  small?: boolean;
  leftAligned?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ children, ...rest }: LogoProps) => {
  return (
    <Container {...rest}>
      Chat<span>RD<span className='beta'>Beta</span></span>
      {children && <> {children}</>}
    </Container>
  );
};
