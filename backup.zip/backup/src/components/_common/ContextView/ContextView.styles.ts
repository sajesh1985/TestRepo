import styled from '@emotion/styled';
import { Button } from '@spglobal/react-components';
import SyntaxHighlighter from 'react-syntax-highlighter';
import { DARK } from '@spglobal/koi-helpers';
import { Breakpoints } from '@spglobal/tokens';

export const ContextContainer = styled.div`
  position: relative;
  margin-top: var(--size-space-lg);
  min-height: 40px;
  @media (min-width: ${Breakpoints.MD}) {
    min-height: var(--size-space-xl);
  }
`;

export const ContextToggleButton = styled(Button)`
  position: absolute;
  top: 0;
  left: 0;
`;

export const ContextContent = styled.div`
  padding: var(--size-space-lg);
  padding-top: var(--size-space-2xl);
  background: var(--color-bg-primary);
  border: 1px solid var(--color-border-primary);
  .${DARK} & {
    border-color: var(--color-base-gray-80);
  }
`;

export const SyntaxHighlighterStyle = styled(SyntaxHighlighter)`
  .hljs {
    &-comment,
    &-quote {
      color: var(--color-text-disabled);
    }
    &-variable,
    &-template-variable,
    &-tag,
    &-name,
    &-selector-id,
    &-selector-class,
    &-regexp,
    &-deletion {
      color: var(--color-text-error);
    }
    &-number,
    &-built_in,
    &-builtin-name,
    &-literal,
    &-type,
    &-params,
    &-meta,
    &-link,
    &-attribute {
      color: var(--color-state-warning);
    }
    &-string,
    &-symbol,
    &-bullet,
    &-addition {
      color: var(--color-text-success);
    }
    &-title,
    &-section {
      color: var(--color-text-link);
    }
    &-keyword,
    &-selector-tag {
      color: var(--color-text-link-visited);
    }
    &-emphasis {
      font-style: italic;
    }
    &-strong {
      font-weight: bold;
    }
  }
`;
