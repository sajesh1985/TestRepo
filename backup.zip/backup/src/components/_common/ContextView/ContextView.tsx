import { Purpose, Size } from '@spglobal/koi-helpers';
import React from 'react';
import { ContextContainer, ContextContent, ContextToggleButton } from './ContextView.styles';

interface ContextViewProps extends React.ComponentPropsWithoutRef<'div'> {
  isOpen?: boolean;
}

export const ContextView: React.FC<ContextViewProps> = ({
  children,
  isOpen = false,
}: ContextViewProps) => {
  const [open, setOpen] = React.useState<boolean>(isOpen);
  return (
    <ContextContainer>
      <ContextToggleButton
        size={Size.SMALL}
        onClick={() => setOpen(!open)}
        purpose={Purpose.SECONDARY}
      >
        {open ? 'Hide Context' : 'Show Context'}
      </ContextToggleButton>
      {children && open && (
        <ContextContent>
          <> {children}</>
        </ContextContent>
      )}
    </ContextContainer>
  );
};
