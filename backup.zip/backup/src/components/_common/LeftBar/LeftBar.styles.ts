import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';

export const AccordionList = styled.div`
  padding-bottom: var(--size-space-md);
  listStyleType:none;
  padding:0;
  margin:0;
  
  .${DARK} & {
    border-color: #3b3b3b;
    background-color: #272727;
  }
`;

export const ListHeader = styled.div`
  font-size: var(--size-font-3);
  font-style: italic;
  padding: 2px;
  .${DARK} & {
    color: White;
    background-color: #272727;
  }
`;

export const ListText = styled.div`
  font-size: var(--size-font-3);
  color: var(--color-text-link);
  cursor:pointer;
  padding: 5px;
  .${DARK} & {
    background-color: #272727;
  }
`;

export const LeftSideBar = styled.div`
    background-color: #f0f0f0;
    border-right: '1px solid #ccc';
    transition: 'transform 0.3s ease';
    .css-css-veg span {
      text-transform : 'inherit !important';
    }
    .${DARK} & {
      background-color: #272727;
      border-right:#3b3b3b;
    }

`;

export const styles = {
  leftBar: {
    width: '200px', 
  },

  leftBarOpen:{
    width: '60px',
  },
  
  togglebtn: {
    position: 'absolute',
    right: '-3px',
    top:'9px',
    width:'7px',
    cursor:'pointer',
    border: '2px solid #4527a0',
    borderRadius: '50%',
    transition: 'transform 0.3s ease',
  },

  togglebtnRotate:{
    transform: 'rotate(180deg)'
  },

  titlehide: {
    transform: 'scale(0)'
  },
  
  newChat:{
    fontSize: 'var(--size-font-3)',
    color: 'var(--color-text-link)',
    cursor:'pointer'
  },
  
 

};






