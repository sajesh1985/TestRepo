import { ChatHistory } from '@root/types/chatHistory';
import React from 'react';
import { useChatRD } from '../../../context/chatrd';
import {  styles, AccordionList, ListHeader, ListText,LeftSideBar  } from './LeftBar.styles';
import { MouseEventHandler } from 'react';
import { faAngleDoubleLeft,faAngleDoubleRight } from '@fortawesome/free-solid-svg-icons';
import { Accordion,AccordionItem, Icon } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';

interface LeftBarProps {
  chatHistory: ChatHistory[];
  expanded: MouseEventHandler<HTMLSpanElement>;
  isLeftMenuExpanded:boolean;
  

}
export const LeftBar: React.FC<LeftBarProps> = ({ chatHistory,expanded,isLeftMenuExpanded }) => {
  const { newInteraction } = useChatRD();

  var aboutList: ChatHistory[] = [
    { 
      header: 'About',
      message: ["Methodology", "Capabilities & Limitations", "What's Coming","Full Disclaimer"]
    }
  ];

  const reload = () => {
    window.location.reload();
  };

  
  return (
    <LeftSideBar>
    <div css={isLeftMenuExpanded ? styles.leftBar:styles.leftBarOpen}>
      <span style={{width:'5px',padding:'0px 16px 0px 0px',float:'right'}} data-icon="chevron-left" data-icon-size="xsmall" data-icon-purpose="none" data-testid="icon" onClick={expanded}>
          {isLeftMenuExpanded ? <Icon icon={faAngleDoubleLeft} /> : <Icon icon={faAngleDoubleRight} />}
          </span>
        <div style={{padding:'14px'}}>
          <img style={{verticalAlign: 'middle'}} src={require('../../../assets/images/chatRDAI.svg')} />
          <span style={styles.newChat} onClick={reload}>Start A New Chat</span>
        
        </div>
        <div css={isLeftMenuExpanded ? '':styles.titlehide }>
        <Accordion accordionSize={Size.SMALL} removeItemSpacing >
          <AccordionItem isDefaultOpen header="Chat History" style={{textTransform:'inherit'}}>
            <AccordionList>
              {chatHistory.map((message:any) => (
                  <div style={{padding:'10px'}}>
                    <ListHeader>
                      {message.header}
                    </ListHeader>
                      {message.message.map((mess:any) => (
                            <ListText onClick={() => {window.scrollTo(0, document.body.scrollHeight); newInteraction('How has Microsoft stock performed YTD? ');}}>{mess}</ListText>
                      )) }
                </div>
              ))}
            </AccordionList>
            
          </AccordionItem>
          <AccordionItem isDefaultOpen header="About ChatRD(Beta)" style={{textTransform:'inherit'}}>
          <AccordionList>
              {aboutList.map((message:any) => (
                  <div style={{padding:'10px'}}>
                    <ListHeader>
                    </ListHeader>
                    {message.message.map((mess:any) => (
                          <ListText>{mess}</ListText>
                    )) }
                </div>
              ))}         
          </AccordionList>
          </AccordionItem>
        </Accordion>
        </div>
      </div>
    </LeftSideBar>
  );
};

