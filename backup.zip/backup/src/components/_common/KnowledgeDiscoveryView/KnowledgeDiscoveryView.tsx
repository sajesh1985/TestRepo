import { H5 } from '@spglobal/react-components';
import React from 'react';
import { AgGridStyle } from '../TableView/TableView.styles';
import { Answer, Doc, DocWrapper } from './KnowledgeDiscoveryView.styles';
import {
  ColumnWidthCallbackParams,
  ExcelCell,
  ExcelData,
  GetContextMenuItemsParams,
  LicenseManager,
  ProcessCellForExportParams,
  ProcessRowGroupForExportParams,
} from 'ag-grid-enterprise';
import { config } from '@spglobal/spa';
import {
  KnowledgeDiscoveryDocuments,
  KnowledgeDiscoveryResponseNode,
  Snippet,
} from '@root/types/api';
import { SnippetRenderer } from './snippetRenderer';
const AG_GRID_LICENSE_KEY = config('agGridLicenseKey');
LicenseManager.setLicenseKey(AG_GRID_LICENSE_KEY);

interface KnowledgeDiscoveryViewProps extends React.ComponentPropsWithoutRef<'div'> {
  answer: KnowledgeDiscoveryResponseNode['answer'];
  documents: KnowledgeDiscoveryResponseNode['documents'];
}

export const KnowledgeDiscoveryView: React.FC<KnowledgeDiscoveryViewProps> = ({
  answer,
  documents,
}: KnowledgeDiscoveryViewProps) => {
  const monthToComparableNumber = (date: string) => {
    if (date === undefined || date === null || date.length !== 10) {
      return null;
    }
    const yearNumber = Number.parseInt(date.substring(6, 10));
    const monthNumber = Number.parseInt(date.substring(0, 2));
    const dayNumber = Number.parseInt(date.substring(3, 5));
    return yearNumber * 10000 + monthNumber * 100 + dayNumber;
  };

  const dateComparator = (date1: string, date2: string) => {
    const date1Number = monthToComparableNumber(date1);
    const date2Number = monthToComparableNumber(date2);
    if (date1Number === null && date2Number === null) {
      return 0;
    }
    if (date1Number === null) {
      return -1;
    }
    if (date2Number === null) {
      return 1;
    }
    return date1Number - date2Number;
  };

  const cell = (value: ExcelData['value'], styleId: ExcelCell['styleId']) => {
    const data: ExcelCell = {
      styleId: styleId,
      data: {
        type: 'String',
        value: value,
      },
    };
    return data;
  };

  return (
    <DocWrapper>
      <Answer>{answer}</Answer>
      <Doc>
        <H5>Source Documents</H5>
        <AgGridStyle
          frameworkComponents={{
            snippetRenderer: SnippetRenderer,
          }}
          enableRangeSelection={true}
          suppressContextMenu={false}
          defaultColDef={{
            sortable: true,
            wrapText: true,
            resizable: false,
            filter: true,
          }}
          getContextMenuItems={(params: GetContextMenuItemsParams) => {
            return [
              'copy',
              'copyWithHeaders',
              'separator',
              {
                name: 'Excel Export',
                action: () => params.api.exportDataAsExcel(),
              },
            ];
          }}
          excelStyles={[
            {
              id: 'blueCell',
              font: {
                color: '#0D71C6',
              },
            },
          ]}
          defaultExcelExportParams={{
            getCustomContentBelowRow: (params: ProcessRowGroupForExportParams) => {
              return params.node.data?.snippets.length > 0
                ? [
                    [
                      cell(
                        `${params.node.data?.snippets.map(
                          (item: Snippet) => `${item.text}
`
                        )}`,
                        'body'
                      ),
                    ],
                  ]
                : null;
            },
            columnWidth: (params: ColumnWidthCallbackParams) =>
              params.column.getColDef().field === 'document' ? 800 : 100,
            autoConvertFormulas: true,
            fileName: 'SourceDocumentsExlExport',
            processCellCallback: (params: ProcessCellForExportParams) => {
              const field = params.column.getColDef().field;
              return field === 'document'
                ? `=HYPERLINK("https://www.capitaliq.spglobal.com/apisv3/docviewer/documents?mid=${params.node.data.id}","${params.value}")`
                : params.value;
            },
          }}
          columnDefs={[
            {
              field: 'document',
              headerName: 'Document',
              headerTooltip: 'Document',
              filter: 'agTextColumnFilter',
              cellRenderer: 'snippetRenderer',
              autoHeight: true,
              cellClass: 'blueCell',
            },
            {
              field: 'date',
              headerName: 'Date',
              headerTooltip: 'Date',
              width: 100,
              maxWidth: 100,
              filter: 'agDateColumnFilter',
              comparator: dateComparator,
              filterParams: {
                comparator: (filterLocalDateAtMidnight: Date, cellValue: string) => {
                  const dateAsString = cellValue;

                  if (dateAsString == 'NA') {
                    return 0;
                  }

                  //dates are stored as mm/dd/yyyy
                  // We create a Date object for comparison against the filter date
                  const dateParts = dateAsString.split('/');
                  const year = Number(dateParts[2]);
                  const month = Number(dateParts[0]) - 1;
                  const day = Number(dateParts[1]);
                  const cellDate = new Date(year, month, day);

                  // Now that both parameters are Date objects, we can compare
                  if (cellDate < filterLocalDateAtMidnight) {
                    return -1;
                  } else if (cellDate > filterLocalDateAtMidnight) {
                    return 1;
                  }
                  return 0;
                },
              },
              type: 'rightAligned',
            },
          ]}
          enableCellTextSelection={true}
          isMobileAutoSize
          processCellForClipboard={(params: ProcessCellForExportParams) => {
            const snip = params.node.data.snippets?.map(
              (item: Snippet) => `${item.text}
`
            );
            return params.column.getColDef().field === 'document'
              ? `${params.value}             
https://www.capitaliq.spglobal.com//apisv3/docviewer/documents?mid=${params.node.data.id}          
${snip}`
              : params.value;
          }}
          rowData={documents.map((data: KnowledgeDiscoveryDocuments) => {
            return {
              document: data.title,
              id: data.id,
              snippets: data.snippets,
              date:
                data.date == null
                  ? 'NA'
                  : Intl.DateTimeFormat('en-us', {
                      year: 'numeric',
                      month: '2-digit',
                      day: '2-digit',
                      timeZone: 'UTC',
                    }).format(new Date(data.date)),
            };
          })}
        />
      </Doc>
    </DocWrapper>
  );
};
