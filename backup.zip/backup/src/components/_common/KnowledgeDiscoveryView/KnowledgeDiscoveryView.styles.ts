import styled from '@emotion/styled';
import { P } from '@spglobal/react-components';

export const Answer = styled.div`
  margin-bottom: var(--size-space-lg);
  white-space: pre-line;
  font-size: var(--font-body-lg);
  line-height: var(--scale-line-height-150);
`;

export const DocWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: var(--size-space-lg);
`;

export const Doc = styled.div`
  padding: 0;
  h5 {
    margin-bottom: var(--size-space-sm);
  }
`;

export const DocList = styled.div`
  display: flex;
  padding: var(--size-space-xs) 0;
  justify-content: space-between;
  gap: var(--size-space-sm);
`;
export const DocListTitle = styled.div`
  flex: 1;
`;
export const DocListDate = styled.div`
  flex: 1;
  max-width: 70px;
  text-align: right;
`;

export const SnippetStyle = styled(P)`
  display: inline;
`;

export const SnippetGapStyle = styled.div`
  height: var(--size-space-md);
}
`;

export const SnippetExpandCollapseStyle = styled.span`
  font-style: italic;
  cursor:pointer;
  color:var(--color-text-link);
  display: inline-block;
  margin-left: var(--size-space-sm);
}
`;
