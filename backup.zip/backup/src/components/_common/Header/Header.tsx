import React from 'react';
import { Container, StatusChat,Title  } from './Header.styles';
import { Logo } from '../Logo/Logo';

interface HeaderProps {
  onLogoClick: () => void;
  children?: React.ReactNode;
}

export const Header: React.FC<HeaderProps> = ({ onLogoClick, children }) => {
  return (
    <Container>
      <Logo small onClick={onLogoClick}>
        <StatusChat>STATUS: IN TRAINING</StatusChat>
      </Logo>
      <Title>Here are some ways I can help you today</Title>
      <div>{children}</div>
    </Container>
  );
};
