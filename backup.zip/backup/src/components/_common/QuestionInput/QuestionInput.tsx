import React, { KeyboardEvent } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ClearableField,
  useIsBreakpoint,
  Icon,
  DropDownItem,
  DropDownGroup,
} from '@spglobal/react-components';
import 'regenerator-runtime';
import { BreakPoint, DISPLAYNAME_PREFIX, Purpose, Size } from '@spglobal/koi-helpers';
import {
  InputContainer,
  Container,
  StyledSpeechIcon,
  HistoryDropdown,
  HistoryDropdownItem,
  GenerateButton,
} from './QuestionInput.styles';
import { faArrowRight, faHistory } from '@fortawesome/free-solid-svg-icons';
//import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import { Interaction } from '../../../types/interaction';
import { useChatRD } from '../../../context/chatrd';

interface QuestionInputProps {
  onSearch: (searchValue: string) => void;
  domUpdateValue?: string;
  onSearchValueUpdate?: (searchValue: string) => void;
}

export const generateIcon = (
  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M5.6377 5.89795L7.22828 2.7168L8.81886 5.89795L12 7.48853L8.81886 9.07911L7.22828 12.2603L5.6377 9.07911L2.45654 7.48853L5.6377 5.89795Z"
      fill="#8AB4F8"
    />
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M1.4494 2.18915L2.1741 0.739746L2.8988 2.18915L4.34821 2.91385L2.8988 3.63855L2.1741 5.08795L1.4494 3.63855L0 2.91385L1.4494 2.18915Z"
      fill="#8AB4F8"
    />
  </svg>
);

export const QuestionInput = React.forwardRef<HTMLInputElement, QuestionInputProps>(
  ({ onSearch, domUpdateValue, onSearchValueUpdate }, ref) => {
    const { t } = useTranslation(['chatiq_main']);
    const [searchValue, setSearchValue] = React.useState('');
    React.useEffect(() => {
      setSearchValue(domUpdateValue);
    }, [domUpdateValue]);
    const search = () => {
      if (searchValue.toString().trim() !== '') {
        stopHandle();
        setTimeout(() => {
          onSearch(searchValue.trim());
          onSearchValueUpdate('');
          setSearchValue('');
        }, 200);
      }
    };

    const isMobile = useIsBreakpoint(BreakPoint.MD);

    //const { transcript, resetTranscript, browserSupportsSpeechRecognition } =
      //useSpeechRecognition();
    //const [isListening, setIsListening] = React.useState(false);

    //const handleListing = () => {
      //setIsListening(true);
      //document.body.classList.add('focuseTemp');
      //SpeechRecognition.startListening({
        //continuous: true,
      //});
    //};

    const stopHandle = () => {
      //SpeechRecognition.stopListening();
      document.body.classList.remove('focuseTemp');
      //setIsListening(false);
      //resetTranscript();
    };

    //const [speechSupport, setSpeechSupport] = React.useState<boolean>(true);
    //const [allowSpeech, setAllowSpeech] = React.useState<boolean>(true);
    const { interactions } = useChatRD();

    /*React.useEffect(() => {
      if (transcript) {
        setSearchValue(transcript);
        if (!isListening) {
          resetTranscript();
        }
      }

      if (!browserSupportsSpeechRecognition) {
        setSpeechSupport(false);
      }
    }, [transcript, isListening, browserSupportsSpeechRecognition]);*/

    const IQuestions = React.useMemo(
      () => Array.from(new Set(interactions.map((item: Interaction) => item.req.toString()))),
      [interactions]
    );
    const SQuestionsIndex = React.useMemo(() => {
      let selectedIndex = null;
      IQuestions.forEach((item: string, index: number) => {
        if (item == searchValue) {
          selectedIndex = index;
        }
      });
      return selectedIndex;
    }, [IQuestions, searchValue]);

    const onKeyDownHandler = (event: KeyboardEvent) => {
      if (event.key === 'Enter') {
        search();
      } else if (event.key === 'ArrowUp' && IQuestions.length > 0) {
        event.preventDefault();
        SQuestionsIndex == null
          ? setSearchValue(IQuestions[IQuestions.length - 1].toString())
          : SQuestionsIndex == 0
          ? setSearchValue(IQuestions[0].toString())
          : setSearchValue(IQuestions[SQuestionsIndex - 1].toString());
      } else if (event.key === 'ArrowDown' && IQuestions.length > 0) {
        event.preventDefault();
        SQuestionsIndex == null
          ? setSearchValue(IQuestions[0].toString())
          : SQuestionsIndex == IQuestions.length - 1
          ? setSearchValue(IQuestions[IQuestions.length - 1].toString())
          : setSearchValue(IQuestions[SQuestionsIndex + 1].toString());
      }
    };

    return (
      <Container>
        <InputContainer>
          <ClearableField
            ref={ref}
            placeholder={true ? "Ask a Question" : t('questionInput.placeholder')}
            value={searchValue}
            onChange={(e:any) => setSearchValue(e.target.value)}
            onClean={() => {
              stopHandle();
              setSearchValue('');
              onSearchValueUpdate('');
            }}
            type="text"
            onKeyDown={onKeyDownHandler}
          />
          {interactions.length > 0 && (
            <HistoryDropdown
              mobileMenuTitle={t('questionInput.questionsHistory')}
              disablePortal={true}
              transitionContainerClassName={'historyWrapper'}
              triggerElement={
                <StyledSpeechIcon>
                  <Icon icon={faHistory} size={Size.MEDIUM} />
                </StyledSpeechIcon>
              }
            >
              <DropDownGroup>
                {IQuestions.map((question: string, index: number) => (
                  <DropDownItem key={index} selected={question == searchValue ? true : false}>
                    <HistoryDropdownItem
                      size={Size.LARGE}
                      onClick={() => setSearchValue(IQuestions[index].toString())}
                      casenatural
                    >
                      {question}
                    </HistoryDropdownItem>
                  </DropDownItem>
                ))}
              </DropDownGroup>
            </HistoryDropdown>
          )}
          <GenerateButton
            leftIcon={isMobile ? null : generateIcon}
            purpose={Purpose.MARKETING}
            onClick={search}
          >
            {isMobile ? <Icon icon={faArrowRight} /> : 'Generate'}
          </GenerateButton>
        </InputContainer>
      </Container>
    );
  }
);

QuestionInput.displayName = `${DISPLAYNAME_PREFIX}.QuestionInput`;
