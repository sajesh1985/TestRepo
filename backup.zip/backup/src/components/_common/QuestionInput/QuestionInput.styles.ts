import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';
import { Button, DropDown } from '@spglobal/react-components';

export const Container = styled.div`
  width: 80%;
  left: 0;
  padding: var(--size-space-lg);
  padding-top: var(--size-space-3xl);
  padding-bottom: var(--size-space-xl);
  background: linear-gradient(180deg, rgba(34, 34, 34, 0) 0%, #fff 29.5%);
  z-index: 9;
  .${DARK} & {
    border-color: var(--color-base-gray-80);
    background: linear-gradient(180deg, rgba(34, 34, 34, 0) 0%, #1f1c1c 29.5%);
  }
`;

export const InputContainer = styled.div`
  --border-color: var(--color-base-gray-30);
  width: 1226px;
  margin: auto auto auto 15%;
  max-width: 100%;
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
  border: 1px solid var(--border-color);
  padding: 10px;
  border-radius: var(--size-radius-2);
  position: relative;

  .historyWrapper {
    inset: auto !important;
    transform: none !important;
    bottom: calc(100% + 5px) !important;
    left: 0 !important;
    width: 100%;
  }

  button {
    border-radius: var(--size-radius-1);
  }

  [data-input='input-group'],
  .spg-input-group {
    border: none;
    box-shadow: none;
    outline: none;
    input {
      font-size: 16px;
      &::selection {
        color: var(--color-base-white);
        background: var(--color-state-info);
      }
    }
    .${DARK} & {
      input::selection {
        color: var(--color-base-white);
        background: var(--color-state-info);
      }
    }
  }

  .focuseTemp & {
    background-color: var(--color-bg-hover) !important;
    border-color: var(--color-state-info) !important;
    > div,
    input {
      background: none !important;
    }
  }

  .${DARK} & {
    --border-color: var(--color-base-gray-65);
    background-color: var(--color-dark-gray-75);
  }
`;

export const StyledSpeechIcon = styled.div`
  border: none;
  outline: none;
  cursor: pointer;
  margin-right: var(--size-space-xs);
  position: relative;
  padding: 6px;

  > span {
    position: relative;
    z-index: 2;
  }

  &:before {
    content: none;
    position: absolute;
    background: rgba(128, 187, 237, 0.14);
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: auto;
    border-radius: 1000px;
    animation: listeningAnimation 0.8s infinite alternate linear;
    z-index: 1;
  }
  &.listening:before {
    content: '';
  }

  @keyframes listeningAnimation {
    from {
      width: 5px;
      height: 5px;
      opacity: 1;
    }
    to {
      width: 30px;
      height: 30px;
      opacity: 1;
    }
  }
`;

export const HistoryDropdown = styled(DropDown)`
  width: 100% !important;
  [data-role='dropMenu'] {
    border: 1px solid var(--border-color);
    border-radius: var(--size-radius-2);
    padding: var(--size-space-xs) !important;
    max-height: calc(100vh - 130px);
  }

  .${DARK} & {
    [data-role='dropMenu'] {
      --border-color: var(--color-base-gray-65);
      background-color: var(--color-dark-gray-75);
    }
  }
`;
export const HistoryDropdownItem = styled(Button)`
  padding: var(--size-space-lg) !important;
  font-size: var(--size-font-3) !important;
`;
export const GenerateButton = styled(Button)`
  margin-left: var(--size-space-md);
`;
