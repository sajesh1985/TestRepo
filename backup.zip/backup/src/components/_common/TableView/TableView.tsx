import React from 'react';
import { AgGridStyle, ExportWrapperStyle } from './TableView.styles';
import { GetContextMenuItemsParams, LicenseManager } from 'ag-grid-enterprise';
import { config } from '@spglobal/spa';
import { TableColumnNode, TableResponseNode } from '@root/types/api';
import { Button } from '@spglobal/react-components';
import { Purpose, Size } from '@spglobal/koi-helpers';
const AG_GRID_LICENSE_KEY = config('agGridLicenseKey');
LicenseManager.setLicenseKey(AG_GRID_LICENSE_KEY);

interface TableViewProps extends React.ComponentPropsWithoutRef<'div'> {
  columns: TableResponseNode['columns'];
  rows: TableResponseNode['rows'];
}

export const TableView: React.FC<TableViewProps> = ({ columns, rows }: TableViewProps) => {
  const [gridApi, setGridApi] = React.useState(null);
  const onGridReady = (params: any) => {
    setGridApi(params.api);
  };

  const csvExport = () => {
    gridApi.exportDataAsCsv();
  };
  const exlExport = () => {
    gridApi.exportDataAsExcel();
  };

  const monthToComparableNumber = (dateInitial: string) => {
    const date = Intl.DateTimeFormat('en-us', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      timeZone: 'UTC',
    }).format(new Date(dateInitial));

    if (date === undefined || date === null || date.length !== 10) {
      return null;
    }
    const yearNumber = Number.parseInt(date.substring(6, 10));
    const monthNumber = Number.parseInt(date.substring(0, 2));
    const dayNumber = Number.parseInt(date.substring(3, 5));
    return yearNumber * 10000 + monthNumber * 100 + dayNumber;
  };

  const dateComparator = (date1: string, date2: string) => {
    const date1Number = monthToComparableNumber(date1);
    const date2Number = monthToComparableNumber(date2);
    if (date1Number === null && date2Number === null) {
      return 0;
    }
    if (date1Number === null) {
      return -1;
    }
    if (date2Number === null) {
      return 1;
    }
    return date1Number - date2Number;
  };

  return (
    <div>
      <ExportWrapperStyle>
        <Button size={Size.MEDIUM} purpose={Purpose.SECONDARY} onClick={() => exlExport()}>
          Excel Export
        </Button>
        <Button size={Size.MEDIUM} purpose={Purpose.SECONDARY} onClick={() => csvExport()}>
          CSV Export
        </Button>
      </ExportWrapperStyle>
      <AgGridStyle
        enableRangeSelection={true}
        suppressContextMenu={false}
        isAutoHeight={true}
        onColumnResized={() => {
          document.body.classList.remove('chatRDCustom');
          setTimeout(() => document.body.classList.add('chatRDCustom'), 2000);
        }}
        defaultCsvExportParams={{
          fileName: 'TableCsvExport',
        }}
        defaultExcelExportParams={{
          fileName: 'TableExlExport',
        }}
        getContextMenuItems={(params: GetContextMenuItemsParams) => {
          return [
            'copy',
            'copyWithHeaders',
            'separator',
            {
              name: 'Excel Export',
              action: () => params.api.exportDataAsExcel(),
            },
          ];
        }}
        defaultColDef={{
          width: 120,
          minWidth: 100,
          sortable: true,
          wrapText: true,
          autoHeight: true,
          resizable: true,
          filter: true,
        }}
        columnDefs={columns.map((data: TableColumnNode) => {
          const headerName = data.name.replace(/([A-Z])/g, ' $1').toUpperCase();
          const dateFilterOptions = {
            comparator: dateComparator,
            filterParams: {
              comparator: (filterLocalDateAtMidnight: Date, cellValue: string) => {
                const dateAsString = Intl.DateTimeFormat('en-us', {
                  year: 'numeric',
                  month: '2-digit',
                  day: '2-digit',
                  timeZone: 'UTC',
                }).format(new Date(cellValue));

                if (dateAsString == 'NA') {
                  return 0;
                }

                //dates are stored as mm/dd/yyyy
                // We create a Date object for comparison against the filter date
                const dateParts = dateAsString.split('/');
                const year = Number(dateParts[2]);
                const month = Number(dateParts[0]) - 1;
                const day = Number(dateParts[1]);
                const cellDate = new Date(year, month, day);

                // Now that both parameters are Date objects, we can compare
                if (cellDate < filterLocalDateAtMidnight) {
                  return -1;
                } else if (cellDate > filterLocalDateAtMidnight) {
                  return 1;
                }
                return 0;
              },
            },
            cellRenderer: (params: any) => {
              return params.value == null
                ? 'NA'
                : Intl.DateTimeFormat('en-us', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    timeZone: 'UTC',
                  }).format(new Date(params.value));
            },
          };
          const defaultOptions = {
            field: data.name,
            headerName: headerName,
            headerTooltip: headerName,
            type: data.type == 'date' || data.type == 'number' ? 'rightAligned' : 'leftAligned',
            filter:
              data.type == 'number'
                ? 'agNumberColumnFilter'
                : data.type == 'date'
                ? 'agDateColumnFilter'
                : 'agTextColumnFilter',
          };
          return data.type == 'date' ? { ...defaultOptions, ...dateFilterOptions } : defaultOptions;
        })}
        onGridReady={onGridReady}
        isMobileAutoSize
        rowData={rows}
      />
    </div>
  );
};
