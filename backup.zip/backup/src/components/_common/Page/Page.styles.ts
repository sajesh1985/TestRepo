import styled from '@emotion/styled';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  padding-bottom: 114px;
  width: 100%;
`;

export const MainContent = styled.div`
  flex: 1;
  width: 1080px;
  max-width: 100%;
  margin: auto;
`;
