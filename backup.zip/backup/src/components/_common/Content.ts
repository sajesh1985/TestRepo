import styled from '@emotion/styled';

export const PreformattedContent = styled.pre`
  font-family: var(--font-family-mono);
  margin: 0;
`;
export const DivformattedContent = styled.div`
  font-family: var(--font-family-base);
  margin: 0;
  white-space: pre-line;
  font-size: var(--font-body-lg);
  line-height: var(--scale-line-height-150);
`;
