//import { TopHeaderStyle } from '../../components/App.styles';
import { NotificationProvider, NotificationStyle, useIsBreakpoint } from '@spglobal/react-components';
import React, { useEffect} from 'react';
import { Chat } from '../../components/ChatScreen/Chat';
import { LeftBar } from '../_common/LeftBar/LeftBar';
import { useState } from 'react';
import { getChatHistory } from '../../services/api';
import { BreakPoint } from '@spglobal/koi-helpers';
//import { useChatRD } from '@root/context/chatrd';
//import { useChatIQ } from '@root/context/chatiq';

export const App: React.FC = () => {
  //const { session } = useChatRD();
  //const { t } = useTranslation(['chatiq_main']);
  const [chatHistoryList, setchatHistory] = useState([]);
  useEffect(() => { 
    const loadChatHistory = async () => { 
       
        // Await make wait until that 
        // promise settles and return its result 
        const response = await getChatHistory();

        // After fetching data stored it in posts state. 
        setchatHistory(response); 

    }; 

    // Call the function 
    loadChatHistory(); 
}, []); 

  const [isLeftMenuExpanded, setLeftMenuExpanded] = useIsBreakpoint(BreakPoint.MD) ? useState(false):useState(true);
  const [mainWidth, setMainWidth] = useState('80%');

  const toggleSidebar = () => {
    setLeftMenuExpanded(!isLeftMenuExpanded);
    setMainWidth(isLeftMenuExpanded ? '95%':'80%');
  };
  
  return (
    <NotificationProvider closable toastBottomOffset={20} type={NotificationStyle.TOAST}>
        <div style={{display: 'flex'}}>
          <LeftBar chatHistory={chatHistoryList} isLeftMenuExpanded={isLeftMenuExpanded} expanded={toggleSidebar}/>
          <div style={{width:mainWidth,transition:'width 0.3s ease',paddingLeft:'7px'}} >
            <Chat />
          </div>
        </div>
    </NotificationProvider>
  );
};