import styled from '@emotion/styled';
import { DARK } from '@spglobal/koi-helpers';
import { Breakpoints } from '@spglobal/tokens';

export const Container = styled.div`
  background: var(--color-bg-primary);
  box-shadow: 0 0 30px 8px rgba(0, 0, 0, 0.1);
  max-width: 1460px;
  width: calc(100% - 60px);
  margin: 25px auto;
  margin-top: 70px;
  border: 1px solid #e9e9e9;
  @media (max-width: ${Breakpoints.MD}) {
    margin: 0 auto;
  }
  .${DARK} & {
    box-shadow: 0 0 30px 8px rgba(0, 0, 0, 0.4);
    border-color: var(--color-base-gray-80);
  }
`;
export const TopHeaderStyle = styled.div`
  display: flex;
  justify-content: space-between;
  background: var(--color-base-gray-80);
  box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.34);
  width: 100%;
  min-height: 46px;
  padding: 9px 16px;
  z-index: 1;
  position: relative;
  button {
    height: 28px !important;
  }
`;
