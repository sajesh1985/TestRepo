import { Size } from '@spglobal/koi-helpers';
import { FormGroup, IOption, Label, Select } from '@spglobal/react-components';
import { criteriaDropdown, dropdownLabel, dropdownValue } from './ratingsCriteria.styles';

interface CriteriaDropDownProps {
  sectors: IOption[];
  onSectorChange: (data: IOption[]) => void;
}

const CriteriaDropDown = ({ sectors, onSectorChange }: CriteriaDropDownProps) => {
  return (
    <div css={criteriaDropdown}>
      <Label css={dropdownLabel}>Sectors</Label>
      <FormGroup css={dropdownValue}>
        <Select
          options={sectors}
          closeOnSelection={true}
          isSearchable={false}
          isMulti={false}
          componentSize={Size.MEDIUM}
          defaultValue={[sectors[0]]}
          onChange={onSectorChange}
        />
      </FormGroup>
    </div>
  );
};

export default CriteriaDropDown;
