import { css } from '@emotion/react';

export const ratingsCriteriaMain = css({
  marginTop: '12px',
});
export const tabContent = css({
  paddingTop: '15px',
  '.spg-tabs__list-item:focus': {
    outline: 'none',
  },
});
export const pdfLink = css({
  background: '#d31e27',
  color: 'var(--color-base-white) !important',
  border: 'none',
  fontSize: 'var(--size-font-2)',
  fontWeight: 'var(--font-weight-bold)',
  textAlign: 'center',
  margin: 'var(--size-space-xs)',
  padding: 'var(--size-space-2xs) var(--size-space-xs)',
  ':hover': {
    background: '#f5787e',
    color: 'var(--color-base-white) !important',
    textDecoration: 'none !important',
  },
});

export const accordianBorder = css({
  border: '1px var(--color-base-gray-11) solid',
});
export const disclaimerSpan = css({
  fontSize: 'var(--size-font-3) !important',
  lineHeight: 'var(--scale-line-height-135)',
  a: {
    color: 'var(--color-text-link)',
  },
});

export const timeZone = css({
  fontSize: 'var(--size-font-3) !important',
  marginTop: '10px',
  marginBottom: '20px',
});

export const logo = css({
  width: '100%',
  span: {
    paddingLeft: 'var(--size-space-2xs)',
    fontSize: 'var(--size-font-3) !important',
  },
});
export const logoText = css({
  textAlign: 'right',
  width: '50%',
});
export const logoPath = css({
  paddingLeft: 'var(--size-space-2xs)',
});

export const criteriaDropdown = css({
  display: 'flex',
  width: '500px',
});
export const dropdownLabel = css({
  paddingRight: '10px',
});
export const dropdownValue = css({
  width: '50%',
});
export const criteriaGrid = css({
  th: {
    paddingTop: '0px',
    paddingBottom: '0px',
  },
  td: {
    padding: '1px 4px 1px 4px',
  },
});

export const criteriaTabToc = css({
  width: '54%',
  fontFamily: 'var(--font-family-base)',
  ' .infoSubHead .exportpdf,  .articleLabel,  h1,  #ArticleSidebar,  .footer-disclaimer': {
    display: 'none',
  },
  '.innerinfoSubHead': {
    display: 'flex',
  },
  'p#pubDate': {
    color: 'var(--color-text-primary)',
    fontSize: 'var(--size-font-4)',
    fontWeight: 'bold',
    letterSpacing: 'var(--size-space-0)',
    lineHeight: 'var(--scale-line-height-125)',
    marginBottom: 'var(--size-space-md)',
    marginTop: 'var(--size-space-0)',
  },
  '.wrapper-toolbox': {
    marginBottom: '15px',
    ul: {
      padding: 'var(--size-space-0)',
      marginBottom: '10px',
      marginTop: '0px',
    },
  },
  '.wrapper-toolbox ul li': {
    listStyleType: 'none',
    display: 'list-item',
  },
  'a.btn-default': {
    color: '#333',
  },
  '.btn-default': {
    textTransform: 'uppercase',
    fontSize: 'var(--size-font-3)',
    fontWeight: 'var(--font-weight-bold)',
    border: '1px solid #999',
    paddingLeft: '10px',
    paddingRight: '10px',
    display: 'inline-block',
    marginTop: 'var(--size-space-2xs)',
  },
  p: {
    fontSize: 'var(--size-font-3)',
    marginBottom: 'var(--size-space-sm)',
    fontWeight: 'var(--font-weight-regular)',
    lineHeight: 'var(--scale-line-height-135)',
  },
  'a#ratingsHyperlink': {
    fontSize: 'var(--size-font-3)',
    fontWeight: 'var(--font-weight-regular)',
    lineHeight: 'var(--scale-line-height-135)',
    cursor: 'pointer',
    color: 'var(--color-text-link)',
  },
  'a span': {
    display: 'inline-block',
    lineHeight: '20px',
    marginTop: 'var(--size-space-2xs)',
  },
  '.caret': {
    verticalAlign: 'middle',
    borderTop: '4px solid',
    borderRight: '4px solid transparent',
    borderLeft: '4px solid transparent',
    marginLeft: '10px',
    marginTop: '-2px',
  },
  '.dropdown-menu': {
    margin: 'var(--size-space-0)',
    boxShadow: 'none',
    border: '1px solid #000',
    minWidth: '175px',
    display: 'none',
    'li a': {
      paddingTop: 'var(--size-space-2xs)',
      paddingBottom: 'var(--size-space-2xs)',
      color: '#000',
      paddingLeft: '14px',
      paddingRight: '14px',
      lineHeight: '18px',
      fontWeight: 'var(--font-weight-light)',
      textDecoration: 'none',
    },
  },
});
