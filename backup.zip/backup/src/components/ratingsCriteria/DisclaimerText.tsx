import { Accordion, AccordionItem, accordionAppearance } from '@spglobal/react-components';
import { accordianBorder, disclaimerSpan } from './ratingsCriteria.styles';
import { useTranslation } from 'react-i18next';
import { Size } from '@spglobal/koi-helpers';

interface DisclaimerProps {
  disclaimerText: string;
}
const DisclaimerText = ({ disclaimerText }: DisclaimerProps) => {
  const { t } = useTranslation('main');

  return (
    <Accordion
      css={accordianBorder}
      appearance={accordionAppearance.light}
      accordionSize={Size.LARGE}
    >
      <AccordionItem header={t('viewDisclaimer')}>
        <span css={disclaimerSpan} dangerouslySetInnerHTML={{ __html: disclaimerText }}></span>
      </AccordionItem>
    </Accordion>
  );
};

export default DisclaimerText;
