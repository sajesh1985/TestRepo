import { Card, CardBody, CardHeader, Pagination } from '@spglobal/react-components';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { getPageSizeList } from './ratingsCriteriaModel';
import DisclaimerText from './DisclaimerText';
import UserTimeZone from './UserTimeZone';
import CriteriaGrid from './CriteriaGrid';
import CriteriaFooter from './CriteriaFooter';
import {
  useGetDisclaimerDataQuery,
  useGetUserTimeZoneQuery,
  useGetRatingsCriteriaQuery,
} from './api/ratingsCriteria.api';
import { useUserTraits } from '@spglobal/userprofileservice';
import { useDispatch } from 'react-redux';
import { updatePageNumber, updatePageSize } from './localStorage/ratingsCriteria.slice';

interface InputProps {
  languageList: string;
}
const Uspf = ({ languageList }: InputProps) => {
  const { t } = useTranslation('main');
  const userProfile = useUserTraits(['keyLanguageData', 'mSTimeZoneID']);
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const { data: disclaimerText } = useGetDisclaimerDataQuery(userProfile?.keyLanguageData);
  const { data: timeZoneName } = useGetUserTimeZoneQuery(userProfile?.mSTimeZoneID);
  const { data: ratingsCriteria } = useGetRatingsCriteriaQuery({
    pageSize,
    pageNumber,
    tabName: t('uspfTab'),
    languageList,
  });
  const dispatch = useDispatch();
  const pageSizeOptions = getPageSizeList();

  return (
    <Card removeSidePadding={true} isSmallPadding={true}>
      <CardHeader title={t('uspfTitle')} />
      <CardBody>
        {ratingsCriteria && ratingsCriteria.length > 0 && (
          <div>
            <CriteriaGrid ratingsCriteria={ratingsCriteria} />
            <Pagination
              totalItems={ratingsCriteria[0].TotalRecords}
              pageSizeOptions={pageSizeOptions}
              defaultPageSize={20}
              onChangePageSize={(value) => {
                setPageSize(value);
                dispatch(updatePageSize(value));
              }}
              onChange={(value) => {
                setPageNumber(value);
                dispatch(updatePageNumber(value));
              }}
            />
            <UserTimeZone timeZoneName={timeZoneName} />
            <DisclaimerText disclaimerText={disclaimerText} />
            <CriteriaFooter />
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default Uspf;
