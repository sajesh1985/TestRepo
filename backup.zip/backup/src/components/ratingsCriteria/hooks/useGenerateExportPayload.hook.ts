import { ExportableHelper, getTable, ReportHelper } from '@spglobal/exportservice';
import { Exportable, ExportType, Report, Row, Table } from '@spglobal/exportservice/export.types';
import { useRows } from '../export/useRows';
import { useUserTraits } from '@spglobal/userprofileservice';
import { useTranslation } from 'react-i18next';

export const useGenerateExportPayload = (exportType: ExportType) => {
  const { t } = useTranslation('main');
  const userProfile = useUserTraits(['culture', 'email']);

  const tableRows: Row[] = useRows(exportType);
  if (!tableRows) return undefined;

  const reportTable: Table = getTable(tableRows, 'pageContainer');
  const companyTitle = t('ratingsCriteriaTitle');

  const report: Report = new ReportHelper()
    .withTitle(companyTitle)
    .withBrowserTitle(companyTitle)
    .withUserMail(userProfile?.email)
    .withWatermark()
    .withReportTable(reportTable)
    .build();

  const exportable = new ExportableHelper()
    .withSchemaType('UserFriendly')
    .withFormat(exportType)
    .withReports([report])
    .withLogo()
    .withStylesLink(
      'https://cdn.spgi.spglobal.com/spg/platform/1804548/browser/Content/styles/export.css'
    )
    .withFooter();

  const payload: Exportable = exportable.build();

  return () => payload;
};
