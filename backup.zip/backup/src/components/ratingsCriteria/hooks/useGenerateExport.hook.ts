import { ExportPDFResponse, ExportType } from '@spglobal/exportservice/export.types';
import { exportRequest } from '@spglobal/exportservice';
import { config, ConfigKey } from '@spglobal/spa';
import { useGenerateExportPayload } from './useGenerateExportPayload.hook';

export const useGenerateExport = (exportType: ExportType) => {
  const generateExportPayload = useGenerateExportPayload(exportType);
  const isReport = false;
  if (!generateExportPayload) return undefined;

  return (exportType: ExportType) => {
    const payload = generateExportPayload();
    if (isReport) {
      return `<div name="reportManifest"><!-- ${JSON.stringify(payload)} --></div>`;
    }
    return exportRequest(
      `${config('exportService' as ConfigKey)}v2/Export/Generate`,
      payload,
      (response: ExportPDFResponse) => {
        openFileName(response.Message);
      },
      () => {
        onError(exportType);
      }
    );
  };
};

const onError = (format: string) => {
  return new Error('Failed to generate ' + format);
};

const openFileName = (fileName: string) => {
  const params = new URLSearchParams();
  params.append('filename', fileName);
  const url = `${config('exportService' as ConfigKey)}v2/Export/Retrieve?${params.toString()}`;
  const link = Object.assign(document.createElement('a'), {
    target: '_blank',
    href: url,
  });
  link.click();
  link.remove();
};
