import { useEffect, useState } from 'react';
import { getTableOfContents } from '../ratingsCriteriaModel';
import { ART_OBJECT_Id } from '../../../constants/constants';

export const useTableOfContentsData = () => {
  const [tableOfContents, setTableOfContents] = useState<string>('');
  useEffect(() => {
    const asyncGetTableOfContents = async () => {
      const data = await getTableOfContents(ART_OBJECT_Id);
      if (data) {
        setTableOfContents(data);
      }
    };
    asyncGetTableOfContents();
  }, []);
  return { tableOfContents };
};
