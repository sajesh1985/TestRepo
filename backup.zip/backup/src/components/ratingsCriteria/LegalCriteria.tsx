import { Card, CardBody, CardHeader, Pagination } from '@spglobal/react-components';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { getPageSizeList } from './ratingsCriteriaModel';
import DisclaimerText from './DisclaimerText';
import UserTimeZone from './UserTimeZone';
import CriteriaGrid from './CriteriaGrid';
import CriteriaFooter from './CriteriaFooter';
import {
  useGetDisclaimerDataQuery,
  useGetRatingsCriteriaQuery,
  useGetUserTimeZoneQuery,
} from './api/ratingsCriteria.api';
import { useUserTraits } from '@spglobal/userprofileservice';
import { LEGAL_CRITERIA } from '../../constants/constants';

interface InputProps {
  languageList: string;
}

const LegalCriteria = ({ languageList }: InputProps) => {
  const { t } = useTranslation('main');
  const userProfile = useUserTraits(['keyLanguageData', 'mSTimeZoneID']);
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const { data: disclaimerText } = useGetDisclaimerDataQuery(userProfile?.keyLanguageData);
  const { data: timeZoneName } = useGetUserTimeZoneQuery(userProfile?.mSTimeZoneID);
  const { data: ratingsCriteria } = useGetRatingsCriteriaQuery({
    sectorId: LEGAL_CRITERIA,
    pageNumber,
    pageSize,
    allSectors: LEGAL_CRITERIA,
    tabName: t('legalCriteriaTab'),
    languageList,
  });
  const pageSizeOptions = getPageSizeList();

  return (
    <Card removeSidePadding={true} isSmallPadding={true}>
      <CardHeader title={t('legalCriteriaTitle')} />
      <CardBody>
        {ratingsCriteria && ratingsCriteria.length > 0 && (
          <div>
            <CriteriaGrid ratingsCriteria={ratingsCriteria} />
            <Pagination
              totalItems={ratingsCriteria[0].TotalRecords}
              pageSizeOptions={pageSizeOptions}
              defaultPageSize={20}
              onChangePageSize={(value) => {
                setPageSize(value);
              }}
              onChange={(value) => {
                setPageNumber(value);
              }}
            />
            <UserTimeZone timeZoneName={timeZoneName} />
            <DisclaimerText disclaimerText={disclaimerText} />
            <CriteriaFooter />
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default LegalCriteria;
