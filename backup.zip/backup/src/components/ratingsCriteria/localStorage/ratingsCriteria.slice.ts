import { createSlice } from '@reduxjs/toolkit';

const defaultState: RatingsCriteria = {
  tabName: 'general',
  sectorId: '0',
  pageNumber: 1,
  pageSize: 20,
  sectorName: 'All',
};
export interface RatingsCriteria {
  tabName: string;
  sectorId: string;
  pageNumber: number;
  pageSize: number;
  sectorName: string;
}
export const ratingsCriteriaSlice = createSlice({
  name: 'ratingsCriteria',
  initialState: defaultState,
  reducers: {
    addCriteria: (state, { payload }) => {
      state.sectorId = payload.sectorId;
      state.tabName = payload.tabName;
      state.sectorName = payload.sectorName;
    },
    updatePageNumber: (state, { payload }) => {
      state.pageNumber = payload;
    },
    updatePageSize: (state, { payload }) => {
      state.pageSize = payload;
    },
  },
});
export const { addCriteria, updatePageNumber, updatePageSize } = ratingsCriteriaSlice.actions;
export default ratingsCriteriaSlice.reducer;

declare module 'react-redux' {
  interface DefaultRootState {
    ratingsCriteria: RatingsCriteria;
  }
}
