import { createSlice } from '@reduxjs/toolkit';
import { ExportType } from '@spglobal/exportservice';

const defaultState: ExportType | '' = '';
export const exportTypeSlice = createSlice({
  name: 'exportType',
  initialState: defaultState,
  reducers: {
    setExportType: (state, { payload }) => {
      state = payload;
      return state;
    },
  },
});

export const { setExportType } = exportTypeSlice.actions;
export default exportTypeSlice.reducer;

declare module 'react-redux' {
  interface DefaultRootState {
    exportType: ExportType | '';
  }
}
