import CriteriaDropDown from './CriteriaDropDown';
import { Card, CardBody, CardHeader, IOption, Pagination } from '@spglobal/react-components';
import { useState } from 'react';
import { getPageSizeList } from './ratingsCriteriaModel';
import DisclaimerText from './DisclaimerText';
import UserTimeZone from './UserTimeZone';
import CriteriaGrid from './CriteriaGrid';
import CriteriaFooter from './CriteriaFooter';
import {
  useGetDisclaimerDataQuery,
  useGetRatingsCriteriaQuery,
  useGetUserTimeZoneQuery,
} from './api/ratingsCriteria.api';
import { useUserTraits } from '@spglobal/userprofileservice';
import { useDispatch, useSelector } from 'react-redux';
import { addCriteria } from './localStorage/ratingsCriteria.slice';

interface CriteriaLayoutProps {
  tabName: string;
  title: string;
  sectors: IOption[];
  allSectors: string;
  languageList: string;
}
const CriteriaLayout = ({
  tabName,
  title,
  sectors,
  allSectors,
  languageList,
}: CriteriaLayoutProps) => {
  const sectorId = useSelector((store) => store.ratingsCriteria.sectorId);
  const userProfile = useUserTraits(['keyLanguageData', 'mSTimeZoneID']);
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const { data: disclaimerText } = useGetDisclaimerDataQuery(userProfile?.keyLanguageData);
  const { data: timeZoneName } = useGetUserTimeZoneQuery(userProfile?.mSTimeZoneID);
  const { data: ratingsCriteria } = useGetRatingsCriteriaQuery({
    sectorId,
    pageNumber,
    pageSize,
    allSectors,
    tabName,
    languageList,
  });
  const dispatch = useDispatch();
  const pageSizeOptions = getPageSizeList();

  const onSectorChange = (data: IOption[]) => {
    dispatch(
      addCriteria({ sectorId: data[0].value.toString(), tabName, sectorName: data[0].label })
    );
  };

  return (
    <Card removeSidePadding={true} isSmallPadding={true}>
      <CardHeader title={title} />
      <CardBody>
        {sectors && ratingsCriteria && ratingsCriteria.length > 0 && (
          <div>
            <CriteriaDropDown sectors={sectors} onSectorChange={onSectorChange} />
            <CriteriaGrid ratingsCriteria={ratingsCriteria} />
            <Pagination
              totalItems={ratingsCriteria[0].TotalRecords}
              pageSizeOptions={pageSizeOptions}
              defaultPageSize={20}
              onChangePageSize={(value) => {
                setPageSize(value);
              }}
              onChange={(value) => {
                setPageNumber(value);
              }}
            />
            <UserTimeZone timeZoneName={timeZoneName} />
            <DisclaimerText disclaimerText={disclaimerText} />
            <CriteriaFooter />
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default CriteriaLayout;
