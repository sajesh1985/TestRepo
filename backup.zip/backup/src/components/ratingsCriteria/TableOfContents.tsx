import { Card, CardBody, CardHeader } from '@spglobal/react-components';
import { useUserTraits } from '@spglobal/userprofileservice';
import { useTranslation } from 'react-i18next';
import { useGetDisclaimerDataQuery } from './api/ratingsCriteria.api';
import { useTableOfContentsData } from './hooks/useTableOfContentsData.hook';
import { criteriaTabToc } from './ratingsCriteria.styles';
import DisclaimerText from './DisclaimerText';
import CriteriaFooter from './CriteriaFooter';

const TableOfContents = () => {
  const { t } = useTranslation('main');
  const userProfile = useUserTraits(['keyLanguageData']);
  const { data: disclaimerText } = useGetDisclaimerDataQuery(userProfile?.keyLanguageData);
  const { tableOfContents } = useTableOfContentsData();
  return (
    <Card removeSidePadding={true} isSmallPadding={true}>
      <CardHeader title={t('tocTitle')} />
      <CardBody>
        <div css={criteriaTabToc} dangerouslySetInnerHTML={{ __html: tableOfContents }}></div>
        <DisclaimerText disclaimerText={disclaimerText} />
        <CriteriaFooter />
      </CardBody>
    </Card>
  );
};

export default TableOfContents;
