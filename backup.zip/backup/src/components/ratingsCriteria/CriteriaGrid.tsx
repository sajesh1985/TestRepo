import { Size } from '@spglobal/koi-helpers';
import {
  Button,
  DropDown,
  DropDownGroup,
  DropDownItem,
  ITableGridProps,
  Icon,
  IconButton,
  Link,
  TableGrid,
} from '@spglobal/react-components';
import { useTranslation } from 'react-i18next';
import { criteriaGrid, pdfLink } from './ratingsCriteria.styles';
import { ACTION, DOWNLOAD } from '@spglobal/koi-icons';
import { RatingsCriteria } from './ratingsCriteriaModel';
import { toFormattedDateTime } from '../../utils/dateLocalization';
import { useUserTraits } from '@spglobal/userprofileservice';

interface CriteriaGridProps {
  ratingsCriteria: RatingsCriteria[];
}

const CriteriaGrid = ({ ratingsCriteria }: CriteriaGridProps) => {
  const { t } = useTranslation('main');
  const userProfile = useUserTraits(['timeZoneAbbreviation', 'culture', 'mSTimeZoneID']);
  const triggerElement = <IconButton size={Size.SMALL} icon={ACTION} />;
  const tableColumns: ITableGridProps['columns'] = [
    {
      title: '',
      path: t('action'),
    },
    {
      title: t('headline').toUpperCase(),
      path: t('headline'),
      cellProps: {
        style: {
          width: '85%',
        },
      },
    },
    {
      title: t('date').toUpperCase(),
      path: t('date'),
      cellProps: {
        style: {
          width: '10%',
        },
      },
    },
    {
      title: t('download').toUpperCase(),
      path: t('download'),
      cellProps: {
        style: {
          width: '5%',
        },
      },
    },
  ];
  const getTableData = (): ITableGridProps['data'] => {
    if (!ratingsCriteria) return null;

    return ratingsCriteria.map((criteria, index) => ({
      action: (
        <DropDown triggerElement={triggerElement}>
          <DropDownGroup>
            <DropDownItem>
              <Button
                onClick={() => {
                  window.open(
                    `#ratingsdirect/creditresearch?printPDF=1&rid=${criteria.ARTICLE_ID}`
                  );
                }}
              >
                Print
              </Button>
            </DropDownItem>
            <DropDownItem>
              <Button
                onClick={() => {
                  window.open(
                    `#ratingsdirect/creditresearch?downloadPDF=1&rid=${criteria.ARTICLE_ID}`
                  );
                }}
              >
                Download PDF
              </Button>
            </DropDownItem>
          </DropDownGroup>
        </DropDown>
      ),
      headline:
        criteria.RT_SOURCE_OBJECT_ID !== 0 ? (
          <Link
            key={index}
            href={`#ratingsdirect/creditResearch?artObjectId=${criteria.RT_SOURCE_OBJECT_ID} &html=true `}
            target="_blank"
          >
            {criteria.RT_TITLE}
          </Link>
        ) : (
          <Link
            key={index}
            href={`#ratingsdirect/creditResearch?rid=${criteria.ARTICLE_ID}`}
            target="_blank"
          >
            {criteria.RT_TITLE}
          </Link>
        ),
      date: toFormattedDateTime(
        criteria.RT_ARTICLE_DATE,
        userProfile.culture,
        userProfile.mSTimeZoneID,
        userProfile.timeZoneAbbreviation
      ),
      download: (
        <Link
          css={pdfLink}
          href={`#ratingsdirect/creditResearch?downloadPDF=1&rid=${criteria.ARTICLE_ID}`}
          target="_blank"
        >
          PDF &nbsp;
          <Icon icon={DOWNLOAD} purpose={'secondary'} size={Size.XSMALL} color={'#fff'} />
        </Link>
      ),
    }));
  };
  return (
    <TableGrid
      size={Size.MEDIUM}
      columns={tableColumns}
      data={getTableData()}
      hasTopBorder={true}
      css={criteriaGrid}
      plain={true}
    />
  );
};

export default CriteriaGrid;
