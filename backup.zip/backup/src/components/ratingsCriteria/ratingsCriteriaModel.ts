import axios, { AxiosResponse } from 'axios';
import { config } from '@spglobal/spa';
import {
  CORPORTES_ALL_SECTORS,
  FINANCIAL_INSTITUTIONS_ALL_SECTORS,
  GENERAL_ALL_SECTORS,
  GOVERNMENTS_ALL_SECTORS,
  INFRASTRUCTURE_ALL_SECTORS,
  INSURANCE_ALL_SECTORS,
  LEGAL_CRITERIA,
  REQUEST_FOR_COMMENT_ALL_SECTORS,
  SF_ALL_SECTORS,
} from '../../constants/constants';

export const processRatingsCriteriaData = (
  rawRatingsCriteriaResult = [] as RawRatingsCriteria[]
): RatingsCriteria[] => {
  const ratingsCriteriaList: RatingsCriteria[] = [];
  rawRatingsCriteriaResult.map((rawData) =>
    ratingsCriteriaList.push({
      RT_TITLE: rawData.RT_TITLE,
      RT_ARTICLE_DATE: rawData.RT_ARTICLE_DATE,
      ARTICLE_ID: rawData.ARTICLE_ID,
      RT_SOURCE_OBJECT_ID: rawData.RT_SOURCE_OBJECT_ID,
      TotalRecords: rawData.TotalRecords,
    })
  );
  return ratingsCriteriaList;
};
export const processUSPFRatingsCriteriaData = (
  rawRatingsCriteriaResult = [] as RawRatingsCriteria[]
): RatingsCriteria[] => {
  const ratingsCriteriaList: RatingsCriteria[] = [];
  rawRatingsCriteriaResult.map((rawData) =>
    ratingsCriteriaList.push({
      RT_TITLE: rawData.RT_PREFERRED_TITLE,
      RT_ARTICLE_DATE: rawData.RT_ARTICLE_DATE,
      ARTICLE_ID: rawData.ARTICLE_ID,
      RT_SOURCE_OBJECT_ID: rawData.RT_SOURCE_OBJECT_ID,
      TotalRecords: rawData.TotalRecords,
    })
  );
  return ratingsCriteriaList;
};

export interface RatingsCriteria {
  RT_TITLE: string;
  RT_ARTICLE_DATE: string;
  ARTICLE_ID: number;
  RT_SOURCE_OBJECT_ID: number;
  TotalRecords: number;
}

export interface RawRatingsCriteriaResponse {
  metadata: string;
  value: RawRatingsCriteria[];
}
export interface RawRatingsCriteria {
  ARTICLE_ID: number;
  PageStartIndex: number;
  RT_ARTICLE_DATE: string;
  RT_PREFERRED_TITLE: string;
  RT_SOURCE_OBJECT_ID: number;
  RT_TITLE: string;
  ResearchDocumentId: number;
  TotalRecords: number;
}

export const getTableOfContents = async (artObjectId: string): Promise<string> => {
  const requestURL = `${config(
    'onCloudRootPath'
  )}SPGMI.Services.CreditResearch.Service/RDCreditResearch/GetArticle/0/${artObjectId}`;
  return await axios.get(requestURL).then((result: AxiosResponse<string>) => {
    return result.data;
  });
};

export const getGeneralDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '520', label: t('general') });
  options.push({ value: '535', label: t('legalCriteria') });
  options.push({ value: '485', label: t('corporates') });
  options.push({ value: '491', label: t('fi') });
  options.push({ value: '503', label: t('insurance') });
  options.push({ value: '498', label: t('governments') });
  options.push({ value: '540', label: t('infrastructure') });
  options.push({ value: '537', label: t('roc') });
  options.push({ value: '531', label: t('toc') });
  return options;
};
export const getRequestForCommentDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '490', label: t('corporates') });
  options.push({ value: '497', label: t('fi') });
  options.push({ value: '509', label: t('insurance') });
  options.push({ value: '502', label: t('governments') });
  options.push({ value: '537', label: t('general') });
  options.push({ value: '547', label: t('infrastructure') });
  return options;
};
export const getCorporatesDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '521', label: t('fundamentals') });
  options.push({ value: '485', label: t('general') });
  options.push({ value: '486', label: t('industrials') });
  options.push({ value: '487', label: t('projectFinance') });
  options.push({ value: '488', label: t('recovery') });
  options.push({ value: '489', label: t('utilities') });
  options.push({ value: '490', label: t('roc') });
  options.push({ value: '526', label: t('toc') });
  return options;
};
export const getFinancialInstituionsDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '522', label: t('fundamentals') });
  options.push({ value: '491', label: t('general') });
  options.push({ value: '492', label: t('banks') });
  options.push({ value: '493', label: t('brokerDealers') });
  options.push({ value: '494', label: t('financeCompanies') });
  options.push({ value: '495', label: t('fixedIncomeFunds') });
  options.push({ value: '496', label: t('other') });
  options.push({ value: '497', label: t('roc') });
  options.push({ value: '527', label: t('toc') });
  return options;
};
export const getInsuranceDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '523', label: t('fundamentals') });
  options.push({ value: '503', label: t('general') });
  options.push({ value: '504', label: t('bond') });
  options.push({ value: '506', label: t('health') });
  options.push({ value: '507', label: t('life') });
  options.push({ value: '508', label: t('propertyorcasuality') });
  options.push({ value: '505', label: t('specialty') });
  options.push({ value: '509', label: t('roc') });
  options.push({ value: '529', label: t('toc') });
  return options;
};
export const getGovernmentsDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '524', label: t('fundamentals') });
  options.push({ value: '498', label: t('internationalPublicFinance') });
  options.push({ value: '499', label: t('roc') });
  options.push({ value: '502', label: t('toc') });
  options.push({ value: '528', label: t('sovereigns') });
  return options;
};
export const getSfDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '525', label: t('fundamentals') });
  options.push({ value: '510', label: t('general') });
  options.push({ value: '511', label: t('abs') });
  options.push({ value: '512', label: t('structuredCredit') });
  options.push({ value: '513', label: t('cmbs') });
  options.push({ value: '514', label: t('coveredBond') });
  options.push({ value: '517', label: t('rmbs') });
  options.push({ value: '518', label: t('servicerEvaluation') });
  options.push({ value: '519', label: t('roc') });
  options.push({ value: '530', label: t('toc') });
  return options;
};
export const getInfraStructureDropDownList = (t: (arg0: string) => string) => {
  const options = [];
  options.push({ value: '0', label: t('all') });
  options.push({ value: '539', label: t('fundamentals') });
  options.push({ value: '540', label: t('general') });
  options.push({ value: '541', label: t('corporates') });
  options.push({ value: '543', label: t('projectDevelopers') });
  options.push({ value: '544', label: t('pfcs') });
  options.push({ value: '545', label: t('recovery') });
  options.push({ value: '546', label: t('utilities') });
  options.push({ value: '547', label: t('roc') });
  options.push({ value: '538', label: t('toc') });
  return options;
};

export const getPageSizeList = () => {
  const options = [];
  options.push({ label: '5', value: '5' });
  options.push({ label: '10', value: '10' });
  options.push({ label: '20', value: '20' });
  options.push({ label: '25', value: '25' });
  options.push({ label: '50', value: '50' });
  options.push({ label: '100', value: '100' });
  return options;
};

export const getAllSectors = (tabName: string, t: (arg0: string) => string) => {
  switch (tabName) {
    case t('generalTab'):
      return GENERAL_ALL_SECTORS;
    case t('legalCriteriaTab'):
      return LEGAL_CRITERIA;
    case t('requestforcommentsTab'):
      return REQUEST_FOR_COMMENT_ALL_SECTORS;
    case t('corporatesTab'):
      return CORPORTES_ALL_SECTORS;
    case t('financialInstitutionsTab'):
      return FINANCIAL_INSTITUTIONS_ALL_SECTORS;
    case t('insuranceTab'):
      return INSURANCE_ALL_SECTORS;
    case t('governmentsTab'):
      return GOVERNMENTS_ALL_SECTORS;
    case t('sfTab'):
      return SF_ALL_SECTORS;
    case t('infrastructureTab'):
      return INFRASTRUCTURE_ALL_SECTORS;
    default:
      return '';
  }
};
export const getRatingsCriteriaTabTitle = (tabName: string, t: (arg0: string) => string) => {
  switch (tabName) {
    case t('generalTab'):
      return t('generalTitle');
    case t('legalCriteriaTab'):
      return t('legalCriteriaTitle');
    case t('requestforcommentsTab'):
      return t('requestForCommentTitle');
    case t('corporatesTab'):
      return t('corporatesTitle');
    case t('financialInstitutionsTab'):
      return t('financialInstitutionsTitle');
    case t('insuranceTab'):
      return t('insuranceTitle');
    case t('governmentsTab'):
      return t('governmentsTitle');
    case t('uspfTab'):
      return t('uspfTitle');
    case t('sfTab'):
      return t('sfTitle');
    case t('infrastructureTab'):
      return t('infrastructureTitle');
    default:
      return '';
  }
};
export const getPageMode = (tab: string, t: (arg0: string) => string) => {
  const tabname = tab ? tab.toUpperCase() : 'TOC';
  switch (tabname) {
    case 'TOC':
      return t('tocTab');
    case 'GEN':
      return t('generalTab');
    case 'LEGAL':
      return t('legalCriteriaTab');
    case 'RFC':
      return t('requestforcommentsTab');
    case 'CORP':
      return t('corporatesTab');
    case 'FI':
      return t('financialInstitutionsTab');
    case 'INS':
      return t('insuranceTab');
    case 'GOV':
      return t('governmentsTab');
    case 'USPF':
      return t('uspfTab');
    case 'SF':
      return t('sfTab');
    case 'INFRA':
      return t('infrastructureTab');
    default:
      return t('tocTab');
  }
};
