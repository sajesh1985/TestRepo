import { useEffect, useState } from 'react';
import { useGenerateExport } from '../../ratingsCriteria/hooks/useGenerateExport.hook';
import { ExportType } from '@spglobal/exportservice';
import { useDispatch, useSelector } from 'react-redux';
import { getAllSectors } from '../ratingsCriteriaModel';
import {
  useGetRatingsCriteriaQuery,
  useGetSelectedLanguagesQuery,
} from '../api/ratingsCriteria.api';
import { setExportType } from '../localStorage/export.slice';
import { NotificationType, useNotification } from '@spglobal/react-components';

interface ReportGeneratorProps {
  exportType: ExportType;
  t: (arg0: string) => string;
}

export const ReportGenerator = ({ exportType, t }: ReportGeneratorProps) => {
  const { data: languageList } = useGetSelectedLanguagesQuery();
  const { tabName, sectorId, pageNumber, pageSize } = useSelector(
    (store) => store?.ratingsCriteria
  );

  const allSectors = getAllSectors(tabName, t);

  const { isSuccess } = useGetRatingsCriteriaQuery({
    sectorId,
    pageNumber: pageNumber,
    pageSize: pageSize,
    allSectors,
    tabName,
    languageList: languageList,
  });

  return isSuccess && <Generate exportType={exportType} t={t} />;
};
export const Generate = ({ exportType, t }: ReportGeneratorProps) => {
  const [schema, setSchema] = useState('');
  const dispatch = useDispatch();
  const generateExport = useGenerateExport(exportType);
  const { addNotification } = useNotification() || {};

  useEffect(() => {
    if (generateExport) {
      setSchema(generateExport(exportType) as string);
      dispatch(setExportType(''));
      addNotification(
        exportType === 'html' ? t('printFinished') : t('exportFinished'),
        NotificationType.SUCCESS
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generateExport]);

  return (
    <div
      dangerouslySetInnerHTML={{
        __html: schema,
      }}
    />
  );
};
