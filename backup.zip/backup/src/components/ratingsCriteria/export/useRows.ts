import {
  CellBuilder,
  ExportType,
  ReportHelper,
  Row,
  emptyRow,
  getTable,
  row,
} from '@spglobal/exportservice';
import useRatingsCriteriaExport from './useRatingsCriteria.export';
import { config } from '@spglobal/spa';
import { useTranslation } from 'react-i18next';
import {
  useGetDisclaimerDataQuery,
  useGetRatingsCriteriaQuery,
  useGetSelectedLanguagesQuery,
  useGetUserTimeZoneQuery,
} from '../api/ratingsCriteria.api';
import { useUserTraits } from '@spglobal/userprofileservice';
import { useSelector } from 'react-redux';
import { getAllSectors, getRatingsCriteriaTabTitle } from '../ratingsCriteriaModel';

/* eslint-disable  @typescript-eslint/no-explicit-any */
const useContentRow = (...params: any): Row => {
  const [exportType, tabName, sectorId, pageNumber, pageSize, t] = [...params];
  const allSectors = getAllSectors(tabName, t);
  const { data: languageList } = useGetSelectedLanguagesQuery();
  const { data: ratingsCriteria } = useGetRatingsCriteriaQuery({
    sectorId,
    pageNumber: pageNumber,
    pageSize: pageSize,
    allSectors,
    tabName,
    languageList: languageList,
  });
  const ratingsCriteriaRow = useRatingsCriteriaExport(ratingsCriteria, exportType);
  const reportTable = getTable(ratingsCriteriaRow);
  const report = new ReportHelper().withReportTable(reportTable).build();
  return row(new CellBuilder().withContent(report).withCellType('table').withNoWrap(false).build());
};
const useHeaderRow = (tabName: string, t: (arg0: string) => string): Row => {
  const title = getRatingsCriteriaTabTitle(tabName, t);
  return row(
    new CellBuilder().withContent(title).withColMerge(10).withBorderStyle('true').withBold().build()
  );
};
const useSectorRow = (
  hideSectorRow: boolean,
  sectorName: string,
  t: (arg0: string) => string
): Row => {
  return !hideSectorRow
    ? row(
        new CellBuilder()
          .withContent(`${t('Sector')}: ${sectorName}`)
          .withColMerge(10)
          .withBorderStyle('true')
          .build()
      )
    : null;
};
const useUserTimeZoneRow = (mSTimeZoneID: string): Row => {
  const { data: timeZoneName } = useGetUserTimeZoneQuery(mSTimeZoneID);
  return row(
    new CellBuilder().withContent(timeZoneName).withColMerge(10).withBorderStyle('true').build()
  );
};
const useDisclaimerTextRow = (exportType: ExportType, keyLanguageData: number): Row => {
  const { data: disclaimerText } = useGetDisclaimerDataQuery(keyLanguageData);
  return exportType === 'excel'
    ? row(
        new CellBuilder()
          .withContent(disclaimerText)
          .withColMerge(10)
          .withNoWrap(false)
          .withBorderStyle('true')
          .build()
      )
    : row(
        new CellBuilder()
          .withContent(disclaimerText)
          .withColMerge(10)
          .withBorderStyle('true')
          .withNoWrap(false)
          .build()
      );
};
const useFooterRow = (exportType: ExportType): Row => {
  const footerText =
    exportType === 'excel'
      ? 'S&P Credit Ratings and Research provided by S&P Global Ratings'
      : `<table style="width:100%">
    <tbody>
    <tr>
      <td style="text-align: right;width:50%">
        <span style="padding-left:2px;font-size:11px">S&amp;P Credit Ratings and Research provided by &nbsp;</span>
      </td>
      <td style="padding-left:2px;" >
        <img
          src=${config('onCloudRootPath')}SNLWebPlatform/Images/sandpRatingsDisclaimer.png
        />
      </td>
    </tr>
  </tbody>
</table>`;
  return row(
    new CellBuilder().withContent(footerText).withColMerge(10).withBorderStyle('true').build()
  );
};

export const useRows = (exportType: ExportType): Row[] => {
  const { t } = useTranslation('main');
  const { tabName, sectorId, sectorName, pageNumber, pageSize } = useSelector(
    (store) => store?.ratingsCriteria
  );
  const hideSectorRow = tabName === t('uspfTab') || tabName === t('legalCriteriaTab');
  const userProfile = useUserTraits([
    'keyLanguageData',
    'mSTimeZoneID',
    'timeZoneAbbreviation',
    'culture',
  ]);
  const headerRow = useHeaderRow(tabName, t);
  const sectorRow = useSectorRow(hideSectorRow, sectorName, t);
  const contentRow = useContentRow(exportType, tabName, sectorId, pageNumber, pageSize, t);
  const userTimezoneRow = useUserTimeZoneRow(userProfile?.mSTimeZoneID);
  const disclaimerTextRow = useDisclaimerTextRow(exportType, userProfile?.keyLanguageData);
  const footerRow = useFooterRow(exportType);

  if (!contentRow) return undefined;

  return [
    emptyRow(),
    headerRow,
    sectorRow,
    emptyRow(),
    contentRow,
    emptyRow(),
    userTimezoneRow,
    emptyRow(),
    emptyRow(),
    disclaimerTextRow,
    emptyRow(),
    footerRow,
  ];
};
