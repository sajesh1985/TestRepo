import { CellBuilder, ExportType, row } from '@spglobal/exportservice';
import { RatingsCriteria } from '../ratingsCriteriaModel';
import { toFormattedDateTime } from '../../../utils/dateLocalization';
import { UserProfileAllTypes, useUserTraits } from '@spglobal/userprofileservice';
import gridToRow from '../../../utils/export/gridToRow';
const useRatingsCriteriaExport = (ratingsCriteria: RatingsCriteria[], exportType: ExportType) => {
  const userProfile = useUserTraits(['mSTimeZoneID', 'timeZoneAbbreviation', 'culture']);
  return [gridToRow(getRatingsCriteriaContent(ratingsCriteria, exportType, userProfile))];
};
const getCell = (cellInfo: string, colMerge: number) => {
  const cell = new CellBuilder()
    .withContent(cellInfo)
    .withBorderStyle('true')
    .withNoWrap(true)
    .withColMerge(colMerge);
  return cell.build();
};

const getRatingsCriteriaContent = (
  ratingsCriteria: RatingsCriteria[],
  exportType: ExportType,
  userProfile: Partial<UserProfileAllTypes>
) => {
  const { timeZoneAbbreviation, culture, mSTimeZoneID } = userProfile;
  const ratingsCriteriaContent = [
    ...ratingsCriteria?.map((criteriaRow: RatingsCriteria) =>
      row([
        getCell(criteriaRow.RT_TITLE, 9),
        getCell(
          toFormattedDateTime(
            criteriaRow.RT_ARTICLE_DATE,
            culture,
            mSTimeZoneID,
            timeZoneAbbreviation
          ),
          3
        ),
      ])
    ),
  ];

  ratingsCriteriaContent.unshift(headerRow(exportType));

  return ratingsCriteriaContent;
};
const headerRow = (exportType: ExportType) =>
  row(
    tableColumns.map((rowColumn) => {
      const baseCell = new CellBuilder()
        .withNoWrap(true)
        .withContent(rowColumn.title.toString().toUpperCase())
        .withColorBackground(13882323)
        .withBold()
        .withColMerge(rowColumn.colMerge)
        .withColWidth(rowColumn.width)
        .withBorderStyle('true');
      if (exportType) {
      }

      return baseCell.build();
    })
  );
const tableColumns = [
  {
    title: 'headline',
    width: '90',
    colMerge: 9,
  },
  {
    title: 'date',
    width: '10',
    colMerge: 3,
  },
];
export default useRatingsCriteriaExport;
