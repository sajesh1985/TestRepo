import { logo, logoPath, logoText } from './ratingsCriteria.styles';
import { config } from '@spglobal/spa';

const CriteriaFooter = () => {
  return (
    <div>
      <br />
      <table css={logo}>
        <tbody>
          <tr>
            <td css={logoText}>
              <span>S&amp;P Credit Ratings and Research provided by &nbsp;</span>
            </td>
            <td css={logoPath}>
              <img
                src={`${config('onCloudRootPath')}SNLWebPlatform/Images/sandpRatingsDisclaimer.png`}
              />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default CriteriaFooter;
