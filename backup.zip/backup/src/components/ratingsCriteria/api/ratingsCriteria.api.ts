import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { getODataAPIRequest } from '@spglobal/dataapiservice/src/dataapi/model';
import { config } from '@spglobal/spa';
import axios from 'axios';
import {
  processRatingsCriteriaData,
  processUSPFRatingsCriteriaData,
} from '../ratingsCriteriaModel';

export const ratingsCriteriaApi = createApi({
  reducerPath: 'ratingsCriteriaApi',
  baseQuery: fetchBaseQuery({ baseUrl: '/' }),
  endpoints: (builder) => ({
    getDisclaimerData: builder.query({
      queryFn: async (params) => {
        const data = await getODataAPIRequest(
          `${config('dataapiSvc')}v2/Hydrobs/RDDesclimerLocalization?KeyForeignLanguage=${params}`
        );
        const OnlineFootnote =
          data.value && data.value.length > 0 ? data.value[0].OnlineFootnote : '';
        return { data: OnlineFootnote };
      },
    }),
    getUserTimeZone: builder.query({
      queryFn: async (params) => {
        const timeZoneUri = `v2/Internal/Common/GeographicTimeZones?$select=MSTimeZoneDisplayName,KeyMappingShapes&$filter=(MSTimeZoneID+eq+'${params}')`;
        const data = await getODataAPIRequest(`${config('dataapiSvc')}${timeZoneUri}`);
        const timeZone =
          data.value && data.value.length > 0 ? data.value[0].MSTimeZoneDisplayName : '';
        return { data: 'Time Zone: ' + timeZone };
      },
    }),
    getRatingsCriteria: builder.query({
      queryFn: async (params) => {
        return params.tabName === 'uspf' ? getUspfCriteria(params) : getRatingsCriteria(params);
      },
    }),
    getSelectedLanguages: builder.query<string, void>({
      queryFn: async () => {
        const requestURL = `${config(
          'onCloudRootPath'
        )}SNL.Services.Storage.Service/v1/StoredObjects('UserPreferences_IR_Preferred_Research_Language')`;
        const data = await axios
          .get(requestURL)
          .then((response) => JSON.parse(response.data.RequestJson).join(','));
        return { data };
      },
    }),
  }),
});
/* eslint-disable  @typescript-eslint/no-explicit-any */
const getUspfCriteria = async (params: any) => {
  const { pageNumber, pageSize, languageList } = params;
  const requestURL = `${config(
    'onCloudRootPath'
  )}apisv3/spg-ratingsresearch-service/api/Ratings/GetUspfCriteriaResearchDataResponse/${pageNumber}/${pageSize}/${languageList}?api-version=2.0`;
  const data = await axios
    .get(requestURL)
    .then((response) => processUSPFRatingsCriteriaData(response?.data));
  return { data };
};
/* eslint-disable  @typescript-eslint/no-explicit-any */
const getRatingsCriteria = async (params: any) => {
  const { sectorId, pageNumber, pageSize, allSectors, tabName, languageList } = params;
  const requestURL = `${config(
    'onCloudRootPath'
  )}apisv3/spg-ratingsresearch-service/api/Ratings/GetCriteriaResearchDataResponse/${
    sectorId === '0' ? allSectors : sectorId
  }/${tabName}/${pageNumber}/${pageSize}/${languageList}?api-version=2.0`;
  const data = await axios
    .get(requestURL)
    .then((response) => processRatingsCriteriaData(response?.data?.value));
  return { data };
};

export const {
  useGetDisclaimerDataQuery,
  useGetUserTimeZoneQuery,
  useGetRatingsCriteriaQuery,
  useGetSelectedLanguagesQuery,
} = ratingsCriteriaApi;
