import { timeZone } from './ratingsCriteria.styles';

interface UserTimeZoneProps {
  timeZoneName: string;
}

const UserTimeZone = ({ timeZoneName }: UserTimeZoneProps) => {
  return <div css={timeZone} dangerouslySetInnerHTML={{ __html: timeZoneName }}></div>;
};

export default UserTimeZone;
