import styled from '@emotion/styled';
import { Icon } from '@spglobal/react-components';
import { Breakpoints } from '@spglobal/tokens';
import { DARK } from '@spglobal/koi-helpers';

export const Item = styled.li`
  display: flex;
  flex-wrap: nowrap;
  gap: 10px;
  padding: var(--size-space-lg) var(--size-space-5xl);
  padding-left: var(--size-space-lg);
  position: relative;
  span{
    font-size: var(--size-font-3);
  };
  &:nth-child(even) {
    background: var(--color-bg-secondary);
  }

  @media (max-width: ${Breakpoints.MD}) {
    padding: var(--size-space-lg) var(--size-space-5xl) var(--size-space-lg) var(--size-space-lg);
  }
  .${DARK} & {
    border-color: var(--color-base-gray-80);
    &:nth-child(even) {
      background: #2a2a2a;
    }
  }
`;

export const Avatar = styled.img`
  width: var(--size-height-base);
  height: var(--size-height-base);
  border-radius: 50%;
`;

export const TextAvatar = styled.span`
  width: var(--size-height-base);
  height: var(--size-height-base);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--color-base-white);
  background: var(--color-core-red);
  font: var(--font-body-xs);
  font-weight: var(--font-weight-bold);
`;

export const Body = styled.div`
  flex: 1;
  padding-top: var(--size-space-2xs);
  font-size: var(--size-font-3);
  max-width: calc(100% - 58px);
  line-height: var(--scale-line-height-150);
`;

export const QuestionBody = styled(Body)`
  font-weight: bold;
  font-size: var(--size-font-3);
  padding-top: var(--size-space-xs);
`;

export const FeedbackContainer = styled.div`
  display: flex;
  gap: var(--size-space-sm);
  position: absolute;
  right: var(--size-space-md);
  top: var(--size-height-sm);
`;

export const FeedbackIcon = styled(Icon)`
  &.initial {
    opacity: 0.4;
    cursor: pointer;

    &:hover {
      opacity: 1;
    }
  }

  &.setUp {
    color: var(--color-text-link);
    fill: var(--color-text-link);
  }
`;

export const Dot = styled.div`
  width: 4.5px;
  height: 4.5px;
  border-radius: 50%;
  color: var(--color-icon-disabled);
  box-shadow: 21.3px 0 0 7.8px, 42.6px 0 0 3.4px, 64px 0 0 0;
  transform: translateX(-42.6px);
  animation: dots-animation 0.5s infinite alternate linear;
  margin-left: var(--size-space-2xl);
  margin-top: var(--size-space-sm);

  @keyframes dots-animation {
    50% {
      box-shadow: 21.3px 0 0 3.4px, 42.6px 0 0 7.8px, 64px 0 0 3.4px;
    }

    100% {
      box-shadow: 21.3px 0 0 0, 42.6px 0 0 3.4px, 64px 0 0 7.8px;
    }
  }
`;
export const ChatResponseContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;
