import React, { MutableRefObject } from 'react';
import { faThumbsUp, faThumbsDown, faClone } from '@fortawesome/free-solid-svg-icons';
import { Purpose } from '@spglobal/koi-helpers';
//import moment from 'moment-timezone';

import { Feedback, Interaction, Sentiment } from '../../../types/interaction';
import { useChatRD } from '../../../context/chatrd';
import { interactionFeedback } from '../../../services/api';
import { FeedbackModal } from '../../../components/FeedbackModal/FeedbackModal';
import { CurrentUserAvatar } from './CurrentUserAvatar';
import {
  FeedbackContainer,
  Item,
  Avatar,
  Body,
  FeedbackIcon,
  QuestionBody,
  Dot,
  ChatResponseContent,
} from './ChatMessage.styles';
import { Tooltip, TooltipPlacement } from '@spglobal/react-components';

interface ChatMessageProps {
  interaction: Interaction;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ interaction }) => {
  const { updateInteraction } = useChatRD();
  //const userProfile = useUserTraits(['timeZoneAbbreviation', 'culture', 'mSTimeZoneID']);
  
  const { id,date, req, res, loading, feedback, feedbackEnabled } = interaction;
  const responseBody = loading ? <Dot /> : res;
  const responseRef = React.useRef<HTMLDivElement>(null);
  const sendFeedback = async (feedback: Feedback) => {
    updateInteraction(id, { feedback });
    try {
      await interactionFeedback(id, {
        sentiment: feedback.sentiment,
        text: feedback.text,
        tags: feedback.tags,
      });
    } catch (e) {
      updateInteraction(id, {
        feedback: undefined,
      });
    }
  };
  const [isOpen, setIsOpen] = React.useState(false);
  

  const [copyText, setCopyText] = React.useState<string>('Copy Response');
  const copyDivToClipboard = (ref: MutableRefObject<HTMLDivElement>) => {
    const range = document.createRange();
    if (ref.current) {
      range.selectNodeContents(ref.current);
      window.getSelection()?.removeAllRanges(); // clear current selection
      window.getSelection()?.addRange(range); // to select text
      document.execCommand('copy');
      window.getSelection().removeAllRanges(); // to deselect
      setCopyText('Copied!');
      setTimeout(() => setCopyText('Copy Response'), 1000);
    }
  };
  return (
    <>
      <Item>
        <CurrentUserAvatar />
        <QuestionBody>{req}</QuestionBody>
        <span>{date}</span>
      </Item>
      <Item>
        <div>
          <Avatar src={require('../../../assets/images/chatRDAI.svg')} />
        </div>
        <Body>
          {!loading && feedbackEnabled && (
            <FeedbackContainer>
              <Tooltip
                open={true}
                placement={TooltipPlacement.LEFT}
                triggerElement={
                  <FeedbackIcon className="initial" icon={faClone} purpose={Purpose.NONE} />
                }
                onTriggerClick={() => copyDivToClipboard(responseRef)}
                width={'auto'}
                contentPadding={5}
              >
                {copyText}
              </Tooltip>

              {!feedback?.sentiment && (
                <>
                  <FeedbackIcon
                    className="initial"
                    icon={faThumbsUp}
                    onClick={() =>
                      sendFeedback({ sentiment: Sentiment.Positive, text: '', tags: [] })
                    }
                  />
                  <FeedbackIcon
                    className="initial"
                    icon={faThumbsDown}
                    onClick={() => setIsOpen(true)}
                  />
                </>
              )}
              {feedback?.sentiment == Sentiment.Positive && (
                <FeedbackIcon
                  className="setUp"
                  icon={faThumbsUp}
                  purpose={Purpose.NONE}
                  color={'var(--color-text-link)'}
                />
              )}
              {feedback?.sentiment == Sentiment.Negative && (
                <FeedbackIcon
                  className="setUp"
                  icon={faThumbsDown}
                  purpose={Purpose.NONE}
                  color={'var(--color-text-link)'}
                />
              )}
            </FeedbackContainer>
          )}
          <FeedbackModal isOpen={isOpen} onClose={() => setIsOpen(false)} interactionId={id} />
          <ChatResponseContent ref={responseRef}>{responseBody}</ChatResponseContent>
        </Body>
      </Item>
    </>
  );
};
