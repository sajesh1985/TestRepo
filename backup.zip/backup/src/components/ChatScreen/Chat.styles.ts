import styled from '@emotion/styled';

export const Timeline = styled.ul`
  padding: 0;
  margin: 0;
`;

export const Navbar = styled.div`
  display: flex;
  gap: var(--size-space-sm);
`;

export const ScrollBottomLi = styled.li`
  display: block;
`;
