import React from 'react';
import { Button, H2, H4, Icon, IconSize, P } from '@spglobal/react-components';

import { useChatRD } from '../../context/chatrd';
import { useState, useRef } from 'react';
import { Interaction } from '../../types/interaction';
import { ChatMessage } from './ChatMessage/ChatMessage';
import { Page } from '../_common/Page/Page';
import { QuestionInput } from '../_common/QuestionInput/QuestionInput';
import { ScrollBottomLi, Timeline } from './Chat.styles';
import { ANGLE_RIGHT } from '@spglobal/koi-icons';
import { FeedbackModal } from '../../components/FeedbackModal/FeedbackModal';
import {
  ExampleBoxWrapper,
  ExampleBox,
  ExampleBoxHead,
  ExampleBoxLists,
  ExampleList,
  FaqDesclimer,
  Status,
  Header,
  ChatRDModel,
  Suggestions,
  SuggestionsChip,
  NewContent,
  Title
} from '../Landing/Landing.styles';
import { Purpose, Size } from '@spglobal/koi-helpers';
import { Logo } from '../_common/Logo/Logo';
import { LandingSlider } from '../Landing/LandingSlider';
//import { useTranslation } from 'react-i18next';
export const Chat: React.FC = () => {
  const { interactions, newInteraction, isLoading } = useChatRD();
  const scrollToBottomRef = React.useRef(null);
  const children = interactions.map((interaction: Interaction, index: number) => (
    <>
      {index == interactions.length - 1 && (
        <>
          <ScrollBottomLi />
          <ScrollBottomLi ref={scrollToBottomRef} />
        </>
      )}
      {interaction.res !== null && <ChatMessage key={interaction.id} interaction={interaction} />}
    </>
  ));

  React.useLayoutEffect(() => {
    setTimeout(
      () =>
        interactions.length > 0 &&
        scrollToBottomRef?.current.scrollIntoView({ behavior: 'smooth', block: 'start' }),
      700
    );
  }, [isLoading, interactions.length]);

  const [dValue, setDValue] = React.useState<string>('');
  const myRef = React.useRef<HTMLInputElement>(null);
  const footer = (
    <QuestionInput
      onSearch={newInteraction}
      onSearchValueUpdate={(searchText) => setDValue(searchText)}
      ref={myRef}
      domUpdateValue={dValue}
    />
  );
  const addQuestion = (
    fullQuestion: string,
    startSubQuestion?: number,
    endSubQuestion?: number
  ) => {
    document.body.classList.add('focuseTemp');
    const input = myRef?.current;
    setDValue(fullQuestion);
    setTimeout(() => {
      input.focus();
      startSubQuestion &&
        endSubQuestion &&
        input.setSelectionRange(startSubQuestion, endSubQuestion);
    }, 200);

    setTimeout(() => document.body.classList.remove('focuseTemp'), 3000);
  };
  const [howToUse, setHowToUse] = React.useState<boolean>(false);
  //const { t } = useTranslation(['chatiq_main']);
  const [feedback, setFeedback] = useState(false);
  const feedbackButtonRef = useRef(null);
  const ExampleQuestions = (
    <>
    <div style={{width:'100%',float:'right'}}>
      {(
            <Button style={{float:'right'}}
              purpose={Purpose.NONE}
              onClick={() => setFeedback(true)}
              ref={feedbackButtonRef}
              color="#fff"
            >
              Feedback
            </Button>
      )}
      {feedback && (
        <FeedbackModal
          isOpen={feedback}
          onClose={() => {
            setFeedback(false);
            setTimeout(() => feedbackButtonRef?.current?.focus(), 500);
          }}
        />
      )}
      </div>
      <Header>
        <Logo />
        <Status>STATUS: IN TRAINING</Status>
        <Title>Here are some ways I can help you today</Title>
      </Header>
      <ExampleBoxWrapper>
        <ExampleBox>
          <ExampleBoxHead>
          <svg width="37" height="37" viewBox="0 0 37 37" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18.1719" cy="18.1562" r="17.5" stroke="#525252"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M18.1575 9.99609L27.4646 14.2499L27.0195 15.2238L26.3052 14.8973V24.4101H25.2344V15.9643H22.5066V24.4101H21.4358V15.9643H18.708V24.4101H17.6372V15.9643H14.9094V24.4101H13.8386V15.9643H11.1108V24.4101H10.04V14.8963L9.32619 15.2235L8.87988 14.2502L18.1575 9.99609ZM10.046 14.8935H26.2968L18.1582 11.1737L10.046 14.8935ZM27.1538 26.3147H9.2061V25.2439H27.1538V26.3147Z" fill="#BFBFBF"/>
          </svg>

            <span>Macroeconomic</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList
              onClick={() => addQuestion('How has Microsoft stock performed YTD? ', 8, 17)}
            >
              <span>What factors can lead to a recession this year?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList
              onClick={() => addQuestion('Compare the PE Ratio of Alphabet and NVIDIA.', 12, 43)}
            >
              <span>What sectors experienced increased demand in a higher interest rate environment?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg width="37" height="37" viewBox="0 0 37 37" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18.1719" cy="18.1562" r="17.5" stroke="#525252"/>
            <g clip-path="url(#clip0_239_4463)">
            <path d="M12 11V37H23V33H25V37H36V11H12ZM14 13H34V35H27V31H21V35H14V13ZM16 15V17H20V15H16ZM22 15V17H26V15H22ZM28 15V17H32V15H28ZM16 19V21H20V19H16ZM22 19V21H26V19H22ZM28 19V21H32V19H28ZM16 23V25H20V23H16ZM22 23V25H26V23H22ZM28 23V25H32V23H28ZM16 27V29H20V27H16ZM22 27V29H26V27H22ZM28 27V29H32V27H28ZM16 31V33H20V31H16ZM28 31V33H32V31H28Z" fill="black"/>
            <path d="M10.5 8V28H25.5V8H10.5ZM24.25 26.75H19.25V23H16.75V26.75H11.75V9.25H24.25V26.75Z" fill="#BFBFBF"/>
            <path d="M13 19.25H15.5V21.75H13V19.25ZM16.75 19.25H19.25V21.75H16.75V19.25ZM20.5 19.25H23V21.75H20.5V19.25ZM13 15.5H15.5V18H13V15.5ZM16.75 15.5H19.25V18H16.75V15.5ZM20.5 15.5H23V18H20.5V15.5ZM13 11.75H15.5V14.25H13V11.75ZM16.75 11.75H19.25V14.25H16.75V11.75ZM20.5 11.75H23V14.25H20.5V11.75Z" fill="#BFBFBF"/>
            </g>
            <defs>
            <clipPath id="clip0_239_4463">
            <rect width="20" height="20" fill="white" transform="translate(8 8)"/>
            </clipPath>
            </defs>
          </svg>

            <span>Entity Specific</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList
              onClick={() =>
                addQuestion('Find recent filings mentioning Energy Transition.', 31, 48)
              }
            >
              <span>What is the latest SWOT analysis for Tesla?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList
              onClick={() =>
                addQuestion(
                  'Show transcripts from the automotive industry that mention supply chain problems.',
                  59,
                  80
                )
              }
            >
              <span>What would cause a downgrade for Chevron?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList
              onClick={() => addQuestion("Summarize Apple's latest earnings call.", 10, 17)}
            >
              <span>Compare the ESG profile between Micron and AMD</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
          <circle cx="18.1719" cy="18.1562" r="17.5" stroke="#525252"/>
          <path d="M10.6719 18.9062H16.6719V20.4062H10.6719V18.9062Z" fill="#BFBFBF"/>
          <path d="M8.42188 20.4062C8.83609 20.4062 9.17188 20.0705 9.17188 19.6562C9.17188 19.242 8.83609 18.9062 8.42188 18.9062C8.00766 18.9062 7.67188 19.242 7.67188 19.6562C7.67188 20.0705 8.00766 20.4062 8.42188 20.4062Z" fill="#BFBFBF"/>
          <path d="M15.9219 17.4062C16.3361 17.4062 16.6719 17.0705 16.6719 16.6562C16.6719 16.242 16.3361 15.9062 15.9219 15.9062C15.5077 15.9062 15.1719 16.242 15.1719 16.6562C15.1719 17.0705 15.5077 17.4062 15.9219 17.4062Z" fill="#BFBFBF"/>
          <path d="M7.67188 15.9062H13.6719V17.4062H7.67188V15.9062ZM10.6719 12.9062H16.6719V14.4062H10.6719V12.9062Z" fill="#BFBFBF"/>
          <path d="M8.42188 14.4062C8.83609 14.4062 9.17188 14.0705 9.17188 13.6562C9.17188 13.242 8.83609 12.9062 8.42188 12.9062C8.00766 12.9062 7.67188 13.242 7.67188 13.6562C7.67188 14.0705 8.00766 14.4062 8.42188 14.4062Z" fill="#BFBFBF"/>
          <path d="M28.6719 27.6063L23.1219 22.0563C24.2469 20.5563 24.9219 18.6812 24.9219 16.6562C24.9219 11.7063 20.8719 7.65625 15.9219 7.65625C13.4469 7.65625 11.1219 8.63125 9.39688 10.5063L10.5219 11.5562C11.8719 9.98125 13.8219 9.15625 15.9219 9.15625C20.0469 9.15625 23.4219 12.5312 23.4219 16.6562C23.4219 20.7812 20.0469 24.1562 15.9219 24.1562C13.6719 24.1562 11.5719 23.1812 10.1469 21.4562L9.02188 22.4313C10.6719 24.4563 13.2219 25.6562 15.9219 25.6562C18.3219 25.6562 20.4969 24.6813 22.1469 23.1813L27.6219 28.6562L28.6719 27.6063Z" fill="#BFBFBF"/>
          </svg>
            <span>Credit Ratings Discover</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList
              onClick={() =>
                addQuestion(
                  'Show bankruptcy filings in the banking industry from the past 12 months.',
                  31,
                  38
                )
              }
            >
              <span>What is the Outlook for HMEL's BB+ ICR according to S&P Global Rating? </span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList
              onClick={() =>
                addQuestion(
                  "Compare M&A deal comps for Kaiser Permanente and Cigna's most recent acquisitions.",
                  27,
                  56
                )
              }
            >
              <span>What are the Ratings for Volkswagen according to S&P Global Ratings?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
          <circle cx="18.1719" cy="18.4043" r="17.5" stroke="#525252"/>
          <path d="M8.92856 24.7057V19.5343L13.4528 17.5957L17.9771 19.5357V24.7057L13.4528 26.6428L8.92856 24.7057Z" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M8.92856 19.5242L13.4528 21.4628L17.9771 19.5242M13.4528 12.46L17.9757 14.4L22.5 12.4614" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M17.9757 19.5244L22.5 21.463L27.0243 19.5244" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M13.4529 21.4658V26.6443M22.5029 21.4658V26.6443M17.9757 14.4001V19.5772M13.4557 17.5929V12.4215L17.9786 10.4829L22.5029 12.4215V17.5929L17.9786 19.5315L13.4557 17.5929ZM17.9757 24.7058V19.5343L22.5 17.5958L27.0243 19.5358V24.7058L22.5 26.6429L17.9757 24.7058Z" stroke="#BFBFBF" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
            <span>Industry</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList
              onClick={() =>
                addQuestion(
                  'Show bankruptcy filings in the banking industry from the past 12 months.',
                  31,
                  38
                )
              }
            >
              <span>What are a list of future trends of the automotive sector that could positively impact credit ratings?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList
              onClick={() =>
                addQuestion(
                  "Compare M&A deal comps for Kaiser Permanente and Cigna's most recent acquisitions.",
                  27,
                  56
                )
              }
            >
              <span>What is expected impact of rising interest rates on telecommunications in 2024?</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" viewBox="0 0 37 37" fill="none">
          <circle cx="18.1719" cy="18.4043" r="17.5" stroke="#525252"/>
          <path d="M8.17188 25.4043V23.3273H10.2489V25.4043H8.17188ZM13.0179 25.4043V23.3273H26.1719V25.4043H13.0179ZM8.17188 19.4423V17.3663H10.2489V19.4423H8.17188ZM13.0179 19.4423V17.3663H26.1719V19.4423H13.0179ZM8.17188 13.4813V11.4043H10.2489V13.4813H8.17188ZM13.0179 13.4813V11.4043H26.1719V13.4813H13.0179Z" fill="#BFBFBF"/>
          </svg>
            <span>List Generation</span>
          </ExampleBoxHead>
          <ExampleBoxLists> 
            <ExampleList
              onClick={() =>
                addQuestion(
                  'Show bankruptcy filings in the banking industry from the past 12 months.',
                  31,
                  38
                )
              }
            >
              <span>Provide a list of the most recent Ratings Actions</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList
              onClick={() =>
                addQuestion(
                  "Compare M&A deal comps for Kaiser Permanente and Cigna's most recent acquisitions.",
                  27,
                  56
                )
              }
            >
              <span>Provide a list of the top 10 trends in US consumer spending</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            
          </ExampleBoxLists>
        </ExampleBox>
        <ExampleBox>
          <ExampleBoxHead>
          <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none">
          <circle cx="18" cy="18" r="17.5" stroke="#525252"/>
          <path d="M15.9219 9.77916H11.4219C11.1235 9.77916 10.8374 9.89768 10.6264 10.1087C10.4154 10.3196 10.2969 10.6058 10.2969 10.9042V25.9042C10.2969 26.2025 10.4154 26.4887 10.6264 26.6997C10.8374 26.9106 11.1235 27.0292 11.4219 27.0292H15.9219C16.2202 27.0292 16.5064 26.9106 16.7174 26.6997C16.9283 26.4887 17.0469 26.2025 17.0469 25.9042V10.9042C17.0469 10.6058 16.9283 10.3196 16.7174 10.1087C16.5064 9.89768 16.2202 9.77916 15.9219 9.77916ZM11.0469 13.5292H16.2969V23.2792H11.0469V13.5292ZM11.4219 10.5292H15.9219C16.0213 10.5292 16.1167 10.5687 16.187 10.639C16.2574 10.7093 16.2969 10.8047 16.2969 10.9042V12.7792H11.0469V10.9042C11.0469 10.8047 11.0864 10.7093 11.1567 10.639C11.227 10.5687 11.3224 10.5292 11.4219 10.5292ZM15.9219 26.2792H11.4219C11.3224 26.2792 11.227 26.2396 11.1567 26.1693C11.0864 26.099 11.0469 26.0036 11.0469 25.9042V24.0292H16.2969V25.9042C16.2969 26.0036 16.2574 26.099 16.187 26.1693C16.1167 26.2396 16.0213 26.2792 15.9219 26.2792ZM27.5225 24.721L24.4109 9.92634C24.3808 9.78119 24.3223 9.64341 24.2388 9.52093C24.1553 9.39845 24.0484 9.29369 23.9242 9.21267C23.8001 9.13165 23.6611 9.07596 23.5154 9.04881C23.3697 9.02166 23.22 9.02359 23.075 9.05447L18.6866 9.99666C18.3949 10.0611 18.1404 10.2381 17.9784 10.4891C17.8163 10.7401 17.7599 11.0449 17.8213 11.3373L20.9328 26.132C20.9629 26.2771 21.0214 26.4149 21.1049 26.5374C21.1885 26.6599 21.2954 26.7646 21.4195 26.8456C21.5437 26.9267 21.6826 26.9824 21.8283 27.0095C21.9741 27.0367 22.1238 27.0347 22.2688 27.0038L26.6572 26.0607C26.9489 25.9967 27.2036 25.8199 27.3657 25.569C27.5277 25.3181 27.5841 25.0133 27.5225 24.721ZM19.7216 16.727L24.8431 15.6273L26.2494 22.2901L21.1278 23.3907L19.7216 16.727ZM19.0991 13.7682L24.2216 12.6676L24.6903 14.8932L19.5678 15.9929L19.0991 13.7682ZM18.845 10.7307L23.2344 9.78759C23.2603 9.78201 23.2867 9.77918 23.3131 9.77916C23.3844 9.77939 23.4541 9.80022 23.5138 9.83916C23.5561 9.86635 23.5925 9.90177 23.6208 9.94333C23.6492 9.98488 23.6689 10.0317 23.6788 10.081L24.0669 11.9354L18.9444 13.0342L18.5553 11.1854C18.5335 11.0867 18.5518 10.9834 18.6061 10.8981C18.6604 10.8129 18.7463 10.7527 18.845 10.7307ZM26.4997 25.3276L22.1094 26.2707C22.0125 26.2914 21.9114 26.2728 21.8281 26.2192C21.7858 26.192 21.7494 26.1565 21.721 26.115C21.6927 26.0734 21.673 26.0266 21.6631 25.9773L21.2769 24.1229L26.3994 23.0232L26.7884 24.8729C26.8103 24.9715 26.7921 25.0747 26.738 25.1599C26.6839 25.2451 26.5982 25.3054 26.4997 25.3276Z" fill="#BFBFBF"/>
          </svg>
            <span>Criteria & Definitions</span>
          </ExampleBoxHead>
          <ExampleBoxLists>
            <ExampleList
              onClick={() =>
                addQuestion(
                  'Show bankruptcy filings in the banking industry from the past 12 months.',
                  31,
                  38
                )
              }
            >
              <span>Give me a bulleted summary of a corporate  methodology.</span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            <ExampleList
              onClick={() =>
                addQuestion(
                  "Compare M&A deal comps for Kaiser Permanente and Cigna's most recent acquisitions.",
                  27,
                  56
                )
              }
            >
              <span>Explain national scale ratings to me in a few bullet points and why are they useful? </span>
              <Icon icon={ANGLE_RIGHT} size={IconSize.XXXSMALL} />
            </ExampleList>
            
          </ExampleBoxLists>
        </ExampleBox>
      </ExampleBoxWrapper>
      <FaqDesclimer>
        <Button
          size={Size.MEDIUM}
          purpose={Purpose.LINK}
          onClick={() => setHowToUse(true)}
          leftIcon={
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="14"
              height="19"
              viewBox="0 0 14 19"
              fill="none"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M0 0H10.9767V7.61783C10.9767 7.913 10.7374 8.15229 10.4423 8.15229C10.1471 8.15229 9.90779 7.913 9.90779 7.61783V1.06893H1.06893V14.8077H2.91527C3.21045 14.8077 3.44974 15.047 3.44974 15.3422C3.44974 15.6374 3.21045 15.8766 2.91527 15.8766H0V0Z"
                fill="var(--color-text-link)"
              />
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M2.36841 3.12473C2.36841 2.82956 2.6077 2.59027 2.90287 2.59027H8.07392C8.36909 2.59027 8.60838 2.82956 8.60838 3.12473C8.60838 3.41991 8.36909 3.6592 8.07392 3.6592H2.90287C2.6077 3.6592 2.36841 3.41991 2.36841 3.12473ZM2.36841 5.45598C2.36841 5.1608 2.6077 4.92151 2.90287 4.92151H8.07392C8.36909 4.92151 8.60838 5.1608 8.60838 5.45598C8.60838 5.75115 8.36909 5.99044 8.07392 5.99044H2.90287C2.6077 5.99044 2.36841 5.75115 2.36841 5.45598ZM2.36841 7.78722C2.36841 7.49204 2.6077 7.25275 2.90287 7.25275H8.07392C8.36909 7.25275 8.60838 7.49204 8.60838 7.78722C8.60838 8.0824 8.36909 8.32168 8.07392 8.32168H2.90287C2.6077 8.32168 2.36841 8.0824 2.36841 7.78722ZM2.36841 10.14C2.36841 9.84487 2.6077 9.60558 2.90287 9.60558H4.59626C4.89143 9.60558 5.13072 9.84487 5.13072 10.14C5.13072 10.4352 4.89143 10.6745 4.59626 10.6745H2.90287C2.6077 10.6745 2.36841 10.4352 2.36841 10.14Z"
                fill="var(--color-text-link)"
              />
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M9.15357 17.3441C10.9949 17.3441 12.4876 15.8514 12.4876 14.0101C12.4876 12.1688 10.9949 10.6761 9.15357 10.6761C7.31224 10.6761 5.81955 12.1688 5.81955 14.0101C5.81955 15.8514 7.31224 17.3441 9.15357 17.3441ZM9.15357 18.475C11.6194 18.475 13.6184 16.476 13.6184 14.0101C13.6184 11.5442 11.6194 9.54525 9.15357 9.54525C6.6877 9.54525 4.68872 11.5442 4.68872 14.0101C4.68872 16.476 6.6877 18.475 9.15357 18.475Z"
                fill="var(--color-text-link)"
              />
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M9.15394 13.1362C9.47717 13.1362 9.73921 13.3983 9.73921 13.7215V15.755C9.73921 16.0782 9.47717 16.3403 9.15394 16.3403C8.8307 16.3403 8.56866 16.0782 8.56866 15.755V13.7215C8.56866 13.3983 8.8307 13.1362 9.15394 13.1362Z"
                fill="var(--color-text-link)"
              />
              <path
                d="M9.7389 12.2652C9.7389 12.5884 9.47687 12.8504 9.15363 12.8504C8.83039 12.8504 8.56836 12.5884 8.56836 12.2652C8.56836 11.9419 8.83039 11.6799 9.15363 11.6799C9.47687 11.6799 9.7389 11.9419 9.7389 12.2652Z"
                fill="var(--color-text-link)"
              />
            </svg>
          }
        >
          How to use Chat RD
        </Button>
        <Button
          size={Size.MEDIUM}
          purpose={Purpose.LINK}
          onClick={() => newInteraction('ChatRD Legal Disclaimer')}
          leftIcon={
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="15"
              height="15"
              viewBox="0 0 15 15"
              fill="none"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M7.0786 12.7858C9.99786 12.7858 12.3644 10.4192 12.3644 7.49999C12.3644 4.58073 9.99786 2.21421 7.0786 2.21421C4.15935 2.21421 1.79282 4.58073 1.79282 7.49999C1.79282 10.4192 4.15935 12.7858 7.0786 12.7858ZM7.0786 14.5786C10.988 14.5786 14.1572 11.4094 14.1572 7.49999C14.1572 3.59059 10.988 0.421387 7.0786 0.421387C3.1692 0.421387 0 3.59059 0 7.49999C0 11.4094 3.1692 14.5786 7.0786 14.5786ZM7.07904 6.11451C7.5915 6.11451 8.00693 6.52994 8.00693 7.0424V10.2663C8.00693 10.7788 7.5915 11.1942 7.07904 11.1942C6.56658 11.1942 6.15115 10.7788 6.15115 10.2663V7.0424C6.15115 6.52994 6.56658 6.11451 7.07904 6.11451ZM7.07871 5.66144C7.59117 5.66144 8.0066 5.246 8.0066 4.73354C8.0066 4.22108 7.59117 3.80565 7.07871 3.80565C6.56625 3.80565 6.15082 4.22108 6.15082 4.73354C6.15082 5.246 6.56625 5.66144 7.07871 5.66144Z"
                fill="var(--color-text-link)"
              />
            </svg>
          }
        >
          Legal disclaimer
        </Button>
      </FaqDesclimer>
    </>
  );

  const HowToUseChatRD = (
    <NewContent>
      <div>
        <Logo leftAligned={true} onClick={() => setHowToUse(false)} />
        <H2 className="spg-mt-xl">
          A generative AI experience from S&P Global <br /> Market Intelligence.
        </H2>
        <LandingSlider />
      </div>
      <div>
        <H2>Try a Suggestion</H2>
        <Suggestions>
          <SuggestionsChip
            onClick={() => addQuestion("What was Apple's stock price on April 1st 2023?")}
          >
            What was Apple&apos;s stock price on April 1st 2023?
          </SuggestionsChip>
          <SuggestionsChip
            onClick={() => addQuestion('What are some recent developments at Apple?')}
          >
            What are some recent developments at Apple?
          </SuggestionsChip>
          <SuggestionsChip onClick={() => addQuestion('What is the total revenue of Apple YTD?')}>
            What is the total revenue of Apple YTD?
          </SuggestionsChip>
          <SuggestionsChip onClick={() => addQuestion("Who are some of Apple's competitors?")}>
            Who are some of Apple&apos;s competitors?
          </SuggestionsChip>
          <SuggestionsChip onClick={() => addQuestion('Who is on the board of Apple?')}>
            Who is on the board of Apple?
          </SuggestionsChip>
          <SuggestionsChip onClick={() => addQuestion("Summarize Intel's latest transcript.")}>
            Summarize Intel&apos;s latest transcript.
          </SuggestionsChip>
          <SuggestionsChip
            onClick={() => addQuestion('Show me 5 private companies making semiconductors.')}
          >
            Show me 5 private companies making semiconductors.
          </SuggestionsChip>
          <SuggestionsChip
            onClick={() =>
              addQuestion('How many acquisitions has S&P Global made in the last five years?')
            }
          >
            How many acquisitions has S&P Global made in the last five years?
          </SuggestionsChip>
        </Suggestions>
      </div>
      <div>
        <H2>
          About Chat<span>RD</span>&apos;s Model
        </H2>
        <ChatRDModel>
          <div className="darkImage" style={{ background: '#1B1B1B' }}>
            <img src={require('../../assets/images/chatIQModal.svg')} />
          </div>
          <div className="lightImage" style={{ background: '#E9E9E9' }}>
            <img src={require('../../assets/images/chatIQModal.svg')} />
          </div>
          <div>
            <H4>
              The ChatRD model was trained using data from S&P Global Market Intelligence. Currently
              the model can answer questions about{' '}
            </H4>
            <ul>
              <li>Indices</li>
              <li>Public and private company financials</li>
              <li>Events</li>
              <li>Transactions and M&A </li>
              <li>Business relationships</li>
              <li>Professionals</li>

              <li>Dow Jones and Market Intelligence News </li>
              <li>Market Intelligence Research </li>
            </ul>
            <P>
              A complete list of data and API services used by ChatRD is available upon request.
            </P>
          </div>
        </ChatRDModel>
      </div>
    </NewContent>
  );

  return (
    <Page footer={footer}>
      {howToUse ? HowToUseChatRD : ExampleQuestions}
      <Timeline>{children}</Timeline>
    </Page>
  );
};
