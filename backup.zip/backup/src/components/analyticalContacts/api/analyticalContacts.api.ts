import { config } from '@spglobal/spa';
import axios from 'axios';

export interface AnalyticalContactInfo {
  RT_ANALYST_ID: string;
  RT_EA_DEPT_ROLE_CODE: string;
  RT_EA_DEPT_ROLE_NAME: string;
  RT_EMAIL_ADDRESS: string;
  RT_EMPLOYEE_NAME: string;
  RT_LOCATION_CODE: string;
  RT_TELEPHONE_NUM: string;
}
export const getAnalyticalContacts = async (entityId: string): Promise<AnalyticalContactInfo[]> => {
  const requestURL = `${config(
    'onCloudRootPath'
  )}apisv3/spg-ratingsresearch-service/api/Ratings/analyticalcontacts/${entityId}?api-version=2.0`;

  return await axios.get(requestURL).then((result) => {
    return result.data;
  });
};
