import { Card, CardBody, CardHeader } from '@spglobal/react-components';
import { useTranslation } from 'react-i18next';
import { city, columns, contactName, email } from './analyticalContacts.styles';
import { useEffect, useState } from 'react';
import { AnalyticalContactInfo, getAnalyticalContacts } from './api/analyticalContacts.api';
import { AnalyticalContactsProps } from '../../entry/AnalyticalContacts/entry';

const AnalyticalContacts = ({ entityId }: AnalyticalContactsProps) => {
  const { t } = useTranslation('main');
  const [analyticalContacts, setAnalyticalContacts] = useState<AnalyticalContactInfo[]>([]);

  useEffect(() => {
    getAnalyticalContacts(entityId).then((result) => {
      setAnalyticalContacts(result);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  interface ContactHtmlBuilderProps {
    contacts: AnalyticalContactInfo[];
  }
  const ContactHtmlBuilder = ({ contacts }: ContactHtmlBuilderProps) => {
    const primaryContact = contacts.find(
      (contact) => contact.RT_EA_DEPT_ROLE_CODE === t('orgAnalyst')
    );
    const secondaryContact = contacts.find(
      (contact) => contact.RT_EA_DEPT_ROLE_CODE === t('teamLeader')
    );
    return (
      <table cellPadding={0} cellSpacing={0} width={'100%'}>
        <tr>
          {primaryContact && (
            <td css={columns}>
              <div css={contactName}>{primaryContact.RT_EMPLOYEE_NAME}</div>
              <div>{t('primaryCreditAnalyst')}</div>
              <div css={city}>{primaryContact.RT_LOCATION_CODE.toLowerCase()}</div>
              <div>{primaryContact.RT_TELEPHONE_NUM}</div>
              <a href={`mailto:${primaryContact.RT_EMAIL_ADDRESS}`} css={email}>
                {primaryContact.RT_EMAIL_ADDRESS}
              </a>
            </td>
          )}
          {secondaryContact && (
            <td css={columns}>
              <div css={contactName}>{secondaryContact.RT_EMPLOYEE_NAME}</div>
              <div>{t('analyticalManager')}</div>
              <div css={city}>{secondaryContact.RT_LOCATION_CODE.toLowerCase()}</div>
              <div>{secondaryContact.RT_TELEPHONE_NUM}</div>
              <a href={`mailto:${secondaryContact.RT_EMAIL_ADDRESS}`} css={email}>
                {secondaryContact.RT_EMAIL_ADDRESS}
              </a>
            </td>
          )}
        </tr>
      </table>
    );
  };

  return (
    <div>
      {analyticalContacts && analyticalContacts.length > 0 && (
        <Card>
          <CardHeader title={t('analyticalContactsTitle')} />
          <CardBody>
            <ContactHtmlBuilder contacts={analyticalContacts} />
          </CardBody>
        </Card>
      )}
    </div>
  );
};

export default AnalyticalContacts;
