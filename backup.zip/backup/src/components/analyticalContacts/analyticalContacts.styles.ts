import { css } from '@emotion/react';

export const columns = css({
  width: '50%',
  border: 'none',
  fontSize: 'var(--size-font-3)',
  lineHeight: '14px',
});

export const contactName = css({
  fontWeight: 'bold',
  marginTop: 'var(--size-space-0)',
});

export const city = css({
  textTransform: 'capitalize',
});
export const email = css({
  display: 'block',
  overflow: 'hidden',
  whiteSpace: 'nowrap',
  textOverflow: 'ellipsis',
  color: '#8ab4f8',
});
