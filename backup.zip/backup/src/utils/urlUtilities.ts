import { config } from '@spglobal/spa';
const cndomain = 'spglobal.cn/';

/**
 *   This Method will make sure we are posting data to correct domain and not to cross-site
 *
 *   @method
 *   @param {string} url                 A URL path
 *   @param {boolean} forceNewDomain     Pass true if want to use new on-prem url forcefully.
 *   @returns {string}                   Return new on prem URL if request is coming on new on-prem or forceNewDomain is true
 */
export function getRelevantDomainURL(url?: string, forceNewDomain?: boolean): string {
  let CnHost;
  if (!url) {
    url = config('interactivex');
    if (window.location.href.toLowerCase().indexOf(cndomain) >= 0) {
      url = 'https://' + window.location.hostname + '/InteractiveX';
      return url;
    }
  }

  const onPremOld = config('onPremOldRootPath')?.toLowerCase() || '';
  const onPremNew = config('onPremRootPath')?.toLocaleLowerCase() || '';
  const onMiCloud = config('onCloudRootPath')?.toLocaleLowerCase() || '';
  let lowerURL = url !== undefined ? url.toLowerCase() : '';

  // if request is coming on new domain we have to use that in url instead of config hard coded
  if (
    onPremNew &&
    onPremOld &&
    (forceNewDomain || window.location.toString().toLowerCase().indexOf(onPremNew) >= 0)
  ) {
    lowerURL = lowerURL.replace(onPremOld, onPremNew);
  }

  if (window.location.href.toLowerCase().indexOf(cndomain) >= 0) {
    if (
      lowerURL.indexOf(onPremOld) >= 0 ||
      lowerURL.indexOf(onPremNew) >= 0 ||
      lowerURL.indexOf(onMiCloud) >= 0
    ) {
      CnHost = window.location.hostname;
      lowerURL = lowerURL
        .replace(onPremOld, CnHost)
        .replace(onPremNew, CnHost)
        .replace(onMiCloud, CnHost);
    }
  }
  return lowerURL;
}
