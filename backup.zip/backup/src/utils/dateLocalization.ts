import moment from 'moment-timezone';
import { timeZone } from '../constants/dateConstants';

export const dateFormattingOption = (timezone: string) => {
  return {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    timeZone: timeZone[timezone as keyof typeof timeZone],
  } as Intl.DateTimeFormatOptions;
};
export const timeFormattingOption = (timezone: string) => {
  return {
    hour: 'numeric',
    minute: 'numeric',
    hour12: false,
    timeZone: timeZone[timezone as keyof typeof timeZone],
  } as Intl.DateTimeFormatOptions;
};

export const toFormattedDateTime = (
  date: string | Date,
  culture: string,
  timezone: string,
  timeZoneAbbreviation: string
): string => {
  const utcDate = moment
    .tz(date, timeZone['Eastern Standard Time' as keyof typeof timeZone])
    .utc()
    .format();
  const dateStr = new Intl.DateTimeFormat(culture, dateFormattingOption(timezone)).format(
    new Date(utcDate)
  );
  const timeStr = new Intl.DateTimeFormat(culture, timeFormattingOption(timezone)).format(
    new Date(utcDate)
  );
  return `${dateStr} ${timeStr} ${timeZoneAbbreviation}`;
};
