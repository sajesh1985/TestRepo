import i18next from 'i18next';
import * as en from '../locales/en/ratingsDirect.json';

export const addLocaleResourceBundle = () => {
  i18next.addResourceBundle('en', 'main', en, true);
};
