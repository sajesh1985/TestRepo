import { ChatRDProvider } from '../../context/chatrd';
import { App } from '../../components/chatrd/chatrd';
import { addLocaleResourceBundle } from '../../utils/localeManager';

addLocaleResourceBundle();

const ChatRDEntry = () => {
  return (
    <ChatRDProvider>
      <App />
    </ChatRDProvider>
    )
 
};

export default ChatRDEntry;
