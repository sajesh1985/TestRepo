import AnalyticalContacts from '../../components/analyticalContacts/AnalyticalContacts';
import { addLocaleResourceBundle } from '../../utils/localeManager';

addLocaleResourceBundle();

export interface AnalyticalContactsProps {
  entityId: string;
}
const entry: React.FC<AnalyticalContactsProps> = ({ entityId }: AnalyticalContactsProps) => {
  return <AnalyticalContacts entityId={entityId} />;
};

export default entry;
