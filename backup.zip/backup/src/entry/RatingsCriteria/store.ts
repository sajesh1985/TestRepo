import { configureStore } from '@reduxjs/toolkit';
import { ratingsCriteriaApi } from '../../components/ratingsCriteria/api/ratingsCriteria.api';
import ratingsCriteriaReducer from '../../components/ratingsCriteria/localStorage/ratingsCriteria.slice';
import exportTypeReducer from '../../components/ratingsCriteria/localStorage/export.slice';

const store = configureStore({
  reducer: {
    [ratingsCriteriaApi.reducerPath]: ratingsCriteriaApi.reducer,
    ratingsCriteria: ratingsCriteriaReducer,
    exportType: exportTypeReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(ratingsCriteriaApi.middleware),
});

export default store;
