import {
  Button,
  NotificationType,
  PageHeader,
  PageTitle,
  Tab,
  Tabs,
  ToolBar,
  ToolBarItem,
  useNotification,
} from '@spglobal/react-components';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import TableOfContents from '../../components/ratingsCriteria/TableOfContents';
import CriteriaLayout from '../../components/ratingsCriteria/CriteriaLayout';
import LegalCriteria from '../../components/ratingsCriteria/LegalCriteria';
import Uspf from '../../components/ratingsCriteria/Uspf';
import {
  getCorporatesDropDownList,
  getFinancialInstituionsDropDownList,
  getGeneralDropDownList,
  getGovernmentsDropDownList,
  getInfraStructureDropDownList,
  getInsuranceDropDownList,
  //getPageMode,
  getRequestForCommentDropDownList,
  getSfDropDownList,
} from '../../components/ratingsCriteria/ratingsCriteriaModel';
import {
  CORPORTES_ALL_SECTORS,
  FINANCIAL_INSTITUTIONS_ALL_SECTORS,
  GENERAL_ALL_SECTORS,
  GOVERNMENTS_ALL_SECTORS,
  INFRASTRUCTURE_ALL_SECTORS,
  INSURANCE_ALL_SECTORS,
  REQUEST_FOR_COMMENT_ALL_SECTORS,
  SF_ALL_SECTORS,
} from '../../constants/constants';
import {
  ratingsCriteriaMain,
  tabContent,
} from '../../components/ratingsCriteria/ratingsCriteria.styles';
import { ReportGenerator } from '../../components/ratingsCriteria/export/ReportGenerator';
import { useDispatch, useSelector } from 'react-redux';
import {
  addCriteria,
  updatePageNumber,
} from '../../components/ratingsCriteria/localStorage/ratingsCriteria.slice';
import { setExportType } from '../../components/ratingsCriteria/localStorage/export.slice';
import { useGetSelectedLanguagesQuery } from '../../components/ratingsCriteria/api/ratingsCriteria.api';
//import { useSearchParams } from 'react-router-dom';

const RatingsCriteria = () => {
  const { t } = useTranslation('main');
  // const [searchParams] = useSearchParams();
  //const [selectedTabId, setSelectedTabId] = useState(getPageMode(searchParams.get('tabName'), t));
  const { data: languageList } = useGetSelectedLanguagesQuery();
  const [selectedTabId, setSelectedTabId] = useState('toc');
  const exportType = useSelector((store) => store.exportType);
  const { addNotification } = useNotification() || {};
  const dispatch = useDispatch();
  const onChange = (newTabId: string) => {
    setSelectedTabId(newTabId);
    dispatch(addCriteria({ sectorId: '0', tabName: newTabId, sectorName: t('all') }));
    if (newTabId !== t('uspfTab')) {
      dispatch(updatePageNumber(0));
    } else {
      dispatch(updatePageNumber(1));
    }
  };
  const generateTabs: Array<JSX.Element> = [
    <Tab key="toc" id={t('tocTab')} title={t('toc')}>
      <TableOfContents />
    </Tab>,
    <Tab key="general" id={t('generalTab')} title={t('general')}>
      <CriteriaLayout
        tabName={t('generalTab')}
        title={t('generalTitle')}
        sectors={getGeneralDropDownList(t)}
        allSectors={GENERAL_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
    <Tab key="legal" id={t('legalCriteriaTab')} title={t('legalCriteria')}>
      <LegalCriteria languageList={languageList} />
    </Tab>,
    <Tab key="comment" id={t('requestforcommentsTab')} title={t('roc')}>
      <CriteriaLayout
        tabName={t('requestforcommentsTab')}
        title={t('requestForCommentTitle')}
        sectors={getRequestForCommentDropDownList(t)}
        allSectors={REQUEST_FOR_COMMENT_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
    <Tab key="corporates" id={t('corporatesTab')} title={t('corporates')}>
      <CriteriaLayout
        tabName={t('corporatesTab')}
        title={t('corporatesTitle')}
        sectors={getCorporatesDropDownList(t)}
        allSectors={CORPORTES_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
    <Tab key="fi" id={t('financialInstitutionsTab')} title={t('fi')}>
      <CriteriaLayout
        tabName={t('financialInstitutionsTab')}
        title={t('financialInstitutionsTitle')}
        sectors={getFinancialInstituionsDropDownList(t)}
        allSectors={FINANCIAL_INSTITUTIONS_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
    <Tab key="insurance" id={t('insuranceTab')} title={t('insurance')}>
      <CriteriaLayout
        tabName={t('insuranceTab')}
        title={t('insuranceTitle')}
        sectors={getInsuranceDropDownList(t)}
        allSectors={INSURANCE_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
    <Tab key="governments" id={t('governmentsTab')} title={t('governments')}>
      <CriteriaLayout
        tabName={t('governmentsTab')}
        title={t('governmentsTitle')}
        sectors={getGovernmentsDropDownList(t)}
        allSectors={GOVERNMENTS_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
    <Tab key="uspf" id={t('uspfTab')} title={t('uspf')}>
      <Uspf languageList={languageList} />
    </Tab>,
    <Tab key="sf" id={t('sfTab')} title={t('sf')}>
      <CriteriaLayout
        tabName={t('sfTab')}
        title={t('sfTitle')}
        sectors={getSfDropDownList(t)}
        allSectors={SF_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
    <Tab key="infrastructure" id={t('infrastructureTab')} title={t('infrastructure')}>
      <CriteriaLayout
        tabName={t('infrastructureTab')}
        title={t('infrastructureTitle')}
        sectors={getInfraStructureDropDownList(t)}
        allSectors={INFRASTRUCTURE_ALL_SECTORS}
        languageList={languageList}
      />
    </Tab>,
  ];

  return (
    <div data-testid="ratingsCriteria" css={ratingsCriteriaMain}>
      <PageHeader
        toolbar={
          selectedTabId !== t('tocTab') && (
            <ToolBar hideButtons={true}>
              <ToolBarItem id="bar1">
                <Button
                  onClick={() => {
                    dispatch(setExportType('html'));
                    addNotification(t('printMessage'), NotificationType.INFO);
                  }}
                >
                  {t('print')}
                </Button>
              </ToolBarItem>
              <ToolBarItem id="bar2">
                <Button
                  onClick={() => {
                    dispatch(setExportType('excel'));
                    addNotification(t('exportMessage'), NotificationType.INFO);
                  }}
                >
                  {t('exportExcel')}
                </Button>
              </ToolBarItem>
              <ToolBarItem id="bar3">
                <Button
                  onClick={() => {
                    dispatch(setExportType('pdf'));
                    addNotification(t('exportMessage'), NotificationType.INFO);
                  }}
                >
                  {t('exportPdf')}
                </Button>
              </ToolBarItem>
              <ToolBarItem id="bar2">
                <Button
                  onClick={() => {
                    dispatch(setExportType('word'));
                    addNotification(t('exportMessage'), NotificationType.INFO);
                  }}
                >
                  {t('exportWord')}
                </Button>
              </ToolBarItem>
            </ToolBar>
          )
        }
      >
        <PageTitle title={t('ratingsCriteriaTitle')} />
      </PageHeader>
      <Tabs isPrimary={false} css={tabContent} selectedTabId={selectedTabId} onChange={onChange}>
        {generateTabs}
      </Tabs>
      {exportType && <ReportGenerator exportType={exportType} t={t} />}
    </div>
  );
};

export default RatingsCriteria;
