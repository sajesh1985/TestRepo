import { NotificationProvider, NotificationStyle } from '@spglobal/react-components';
import { addLocaleResourceBundle } from '../../utils/localeManager';
import { useUserTraits } from '@spglobal/userprofileservice';
import RatingsCriteria from './RatingCriteria';
import { Provider } from 'react-redux';
import store from './store';

addLocaleResourceBundle();

const App = () => {
  const userProfile = useUserTraits(['keyOnlineServices']);

  return (
    userProfile && (
      <NotificationProvider toastBottomOffset={20} type={NotificationStyle.TOAST}>
        <Provider store={store}>
          <RatingsCriteria />
        </Provider>
      </NotificationProvider>
    )
  );
};
export default App;
