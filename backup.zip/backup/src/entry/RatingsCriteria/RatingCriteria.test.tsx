import { cleanup, render } from '@testing-library/react';
import RatingsCriteria from './RatingCriteria';
import { MemoryRouter } from 'react-router';
import { Provider } from 'react-redux';
import { ratingsCriteriaApi } from '../../components/ratingsCriteria/api/ratingsCriteria.api';
import { configureStore } from '@reduxjs/toolkit';

describe('Ratings Criteria', () => {
  afterAll(() => {
    cleanup();
  });

  it('should render the ratings criteria page', () => {
    const store = configureStore({
      reducer: {
        [ratingsCriteriaApi.reducerPath]: ratingsCriteriaApi.reducer,
        // Add other reducers if needed
      },
      middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(ratingsCriteriaApi.middleware),
    });

    const criteria = render(
      <MemoryRouter>
        <Provider store={store}>
          <RatingsCriteria />
        </Provider>
      </MemoryRouter>
    );

    expect(criteria.getByTestId('ratingsCriteria')).toBeInTheDocument();
  });
});
