import React from 'react';
import { createInteraction } from '../services/api';
import moment from 'moment-timezone';
import { Interaction } from '../types/interaction';
import { ContentType, InteractionRequestPayload } from '../types/api';
import { Accordion, AccordionItem, Divider } from '@spglobal/react-components';
import { Size } from '@spglobal/koi-helpers';
import { ContextView } from '../components/_common/ContextView/ContextView';
import { SyntaxHighlighterStyle } from '../components/_common/ContextView/ContextView.styles';
import { useUserTraits } from '@spglobal/userprofileservice';
import { ResponseView } from '../components/_common/ResponseView/ResponseView';
import { DivformattedContent } from '../components/_common/Content';


interface IChatRDContextValue {
  session?: string;
  interactions: Interaction[];
  newSession: () => void;
  newInteraction: (request: string) => void;
  updateInteraction: (id: string, updates: Partial<Interaction>) => void;
  isLoading?: boolean;
  scrollBottomMaxValue?: number;
}

const context = React.createContext<IChatRDContextValue>({} as IChatRDContextValue);

const noResponse = (
  <DivformattedContent> Something went wrong. Please try another question.</DivformattedContent>
);
const desclaimer = (
  <>
    <DivformattedContent className="spg-mb-sm">
      ChatRD is for experimental and demonstration purposes only and it may provide inaccurate
      and/or incomplete responses. By providing feedback, you can help ChatRD to provide better,
      more accurate, and complete responses.
    </DivformattedContent>
    <DivformattedContent className="spg-mb-sm">
      If you do anything based on a particular response that ChatRD provides you, it&apos;s solely
      at your own risk and ChatRD is not responsible for any losses or damages that may be incurred
      as a result of your use of ChatRD.
    </DivformattedContent>
  </>
);
const faq = (
  <Accordion accordionSize={Size.MEDIUM} removeItemSpacing>
    <AccordionItem isDefaultOpen header="What is this?">
      <p className="spg-mb-sm">
        ChatRD aims to be an easy-to-use AI-driven chat interface that specializes in business and
        finance question-answering. This tool is not meant to provide financial advice.
      </p>
      <p className="spg-mb-sm">
        We are looking to test, get feedback, and understand real client use to improve upon our
        model.
      </p>
      <p className="spg-mb-sm">
        Interact with ChatRD. Ask questions in natural language. The model can answer questions
        about a single to multi-company information, including but not limited to company
        organization, professionals, financials, news, acquisitions, etc.
      </p>
    </AccordionItem>
    <AccordionItem header="What we need">
      <p className="spg-mb-sm">
        Ask ChatRD some business and finance specific questions. Thumbs up the “reasonable” answer
        or Thumbs down the “unreasonable” answer. Add additional information in the feedback box if
        you have any.
      </p>
      <p className="spg-mb-sm">
        Note: The model is still a work in progress, so do not be surprised if you find that it
        struggles with questions that you ask. Finding out the useful things that it cannot do is
        very valuable for us on its own. Currently ChatRD does not support conversational
        back-and-forth chat.
      </p>
    </AccordionItem>
    <AccordionItem header="Examples">
      <p className="spg-mb-sm">What was Apple&apos;s stock price on April 1st 2023?</p>
      <p className="spg-mb-sm">What are some recent developments at Apple?</p>
      <p className="spg-mb-sm">What is the total revenue of Apple YTD?</p>
      <p className="spg-mb-sm">Let all CEOs that attended Harvard</p>
      <p className="spg-mb-sm">Who are some of Apple&apos;s competitors?</p>
      <p className="spg-mb-sm">Who is on the board of Apple?</p>
      <p className="spg-mb-sm">Give me an example of 5 private companies operating in Germany.</p>
      <p className="spg-mb-sm">How many acquisitions has S&P Global made in the last five years?</p>
    </AccordionItem>
    <AccordionItem header="Model details ">
      <p className="spg-mb-sm">
        The model currently has access to the following data sets. Though the model has access, it
        may not know yet how to query for a specific table, but don&apos;t let the current list of
        data sets or functionality limit your questions. If there is a question, dataset or API
        service you think would be particularly valuable, let us know.
      </p>
      <p className="spg-mb-sm">
        BMI Index Data, Business Entity Cross Reference Service (BECRS), Business Relationships,
        Company Intelligence, Company Relationships, Competitors, Compustat Snapshot, Corporate
        Tracker, Document Reference, Foundation Company SME, Future Events, Global Events, Global
        Instruments Cross Reference Service (GICRS), Industry Sector Cross Reference Service
        (ISCRS), Key Developments, Key Documents, MI Integrated Market Data, Machine Readable Broker
        Research, Machine Readable Filings, Machine Readable Transcripts, Market Intelligence News,
        Products, Professionals, S&P Capital IQ Base Files, S&P Capital IQ Company Industry GICS,
        S&P Capital IQ Latest Financials, S&P Capital IQ Market Data, S&P Capital IQ Premium
        Financials, S&P Capital IQ Private Company Financials, SNL Branch Data, SNL Corporate Data,
        SNL Real Estate, SNL Reference, SNL Regulatory Data, SNL Sector Financials, Transactions,
        Transactions M&A, Transactions Offerings, Transactions Rounds of Funding
      </p>
    </AccordionItem>
  </Accordion>
);

export const ChatRDProvider: React.FC = ({ children }) => {
  const [session, setSession] = React.useState<string>();
  const [interactions, setInteractions] = React.useState<Interaction[]>([]);
  const { internalUser } = useUserTraits(['internalUser']) || { internalUser: false };
  
  //const [messages, setMessages] = useState([]);

  const isContextEnabled = internalUser && window.location.search.match(/context=1/);
  const isLoading =
    interactions.filter((data: Interaction) => data.loading).length > 0 ? true : false;

  const updateInteraction = (id: string, updates: Partial<Interaction>) => {
    setInteractions((pre) =>
      pre.map((t) => {
        if (t.id == id) {
          return { ...t, ...updates };
        } else {
          return t;
        }
      })
    );
  };

  const getLastInteractionId = () => {
    const respondedInteraction = interactions.filter(
      (data: Partial<Interaction>) => data.feedbackEnabled === true
    );
    const lastInteraction = respondedInteraction[respondedInteraction.length - 1];
    return lastInteraction ? lastInteraction.id : undefined;
  };

  const value: IChatRDContextValue = React.useMemo(() => {
    return {
      session,
      interactions,
      isLoading,
      newSession: () => {
        setSession(undefined);
        setInteractions([]);
      },
      newInteraction: async (request: string) => {
        const interaction: Interaction = {
          id: new Date().valueOf().toString(),
          date:moment().format("Do MMMM YYYY, h:mm:ss A"),
          req: request,
          loading: true,
        };
        setInteractions([...interactions, interaction]);
        try {
          if (request.toLowerCase() == 'chatrd legal disclaimer') {
            updateInteraction(interaction.id, {
              ...interaction,
              loading: false,
              res: desclaimer,
              feedbackEnabled: false,
            });
          } else if (request.toLowerCase() == 'how to use chatrd') {
            updateInteraction(interaction.id, {
              ...interaction,
              loading: false,
              res: faq,
              feedbackEnabled: false,
            });
          } else {
            const args: InteractionRequestPayload = {
              sessionId: session,
              keyonlineuser:0,
              userInput: [
                {
                  type: ContentType.Text,
                  value: request,
                },
              ],
              previousInteractionId: getLastInteractionId(),
              supportedNodeTypes: [
                ContentType.Text,
                ContentType.Code,
                ContentType.Table,
                ContentType.KnowledgeDiscovery,
              ],
            };
            const response = await createInteraction(args);
            setSession(response?.sessionId);
            updateInteraction(interaction.id, {
              ...interaction,
              id: response.interactionId,
              date:moment().format("Do MMMM YYYY, h:mm:ss A"),
              loading: false,
              res: (
                <>
                  <ResponseView data={response?.responseBody || null} />
                  <div style={{display:'flex',right:'12px',position:'absolute',bottom:'0' }}>
                    <span>{moment(response?.responseTimestamp).format("Do MMMM YYYY, h:mm:ss A")}</span>
                  </div>
                  {isContextEnabled && (
                    <ContextView>
                      {response?.responseContext?.map((data, id) => (
                        <>
                          {id !== 0 && <Divider />}
                          <SyntaxHighlighterStyle
                            key={id}
                            language={data.metadata.language}
                            useInlineStyles={false}
                            wrapLines={true}
                          >
                            {data.content}
                          </SyntaxHighlighterStyle>
                        </>
                      ))}
                    </ContextView>
                  )}
                </>
              ),
              feedbackEnabled: true,
            });
          }
        } catch (e) {
          updateInteraction(interaction.id, {
            ...interaction,
            loading: false,
            res: noResponse,
            feedbackEnabled: false,
          });
        }
      },
      updateInteraction,
      scrollBottomMaxValue: document.getElementById('scrollToBottomLI')?.offsetTop || Infinity,
    };
  }, [session, interactions]);

  return <context.Provider value={value}>{children}</context.Provider>;
};

export const useChatRD = () => React.useContext(context);
