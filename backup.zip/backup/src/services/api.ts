import axios from 'axios';
import { config } from '@spglobal/spa';

import {
  InteractionRequestResponse,
  SessionFeedbackRequestPayload,
  InteractionRequestPayload,
  InteractionFeedbackRequestPayload,
} from '../types/api';
import { Feedback, Sentiment } from '../types/interaction';
import { ChatHistory } from '@root/types/chatHistory';

async function makeApiRequest<P, R>(endpoint: string, payload: P): Promise<R> {
  const apiRootPath = config('onCloudRootPath');
  //const apiRootPath = 'http://localhost:5000/v1/chat/';

  //const apiRootPath = 'https://cors-anywhere.herokuapp.com/https://www.capitaliqdev.spglobal.com/';
  //TODO: Extract the config to @spglobal/spa
  //const chatRDApiRoot = `${apiRootPath}`;
  const chatRDApiRoot = `${apiRootPath}apisv3/chatrd-service/v1`;
  const response = await axios.post<R>(`${chatRDApiRoot}/${endpoint}/`, payload, {
    timeout: 120000, // 120s
  });

  return response.data;
}

export async function createInteraction(
  request: InteractionRequestPayload
): Promise<InteractionRequestResponse> {
  return makeApiRequest('chat/prompt', request);
}

export async function getChatHistory(
): Promise<ChatHistory[]> {

  var chatHistoryList: ChatHistory[] = [
    { 
      header: 'Yesterday',
      message: ["What's the rating of Volkswagon", "How has the rating of IBM changed?", "What is S&P's industry outlook"]
    },
    {
      header:'Last 7 days',
      message: ["What is S&P's Rating criteria", "Who is the Obligor for this CUSIP"]
    }
  ];
  return chatHistoryList;

  //return makeApiRequest('chat_history', request);
}

export async function sessionFeedback(sessionId: string, feedback: Feedback): Promise<void> {
  const payload: SessionFeedbackRequestPayload = {
    session: sessionId,
    feedback_sentiment: Sentiment.None,
    text_feedback: feedback.text,
    tags: feedback.tags,
  };
  await makeApiRequest('feedback', payload);
}

export async function interactionFeedback(
  interactionId: string,
  feedback: Feedback
): Promise<void> {
  const payload: InteractionFeedbackRequestPayload = {
    interaction: interactionId,
    feedback_sentiment: feedback.sentiment,
    text_feedback: feedback.text,
    tags: feedback.tags,
  };

  await makeApiRequest('interaction_feedbacks', payload);
}
