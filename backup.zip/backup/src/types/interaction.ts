import React from 'react';

export enum Sentiment {
  Positive = 'positive',
  Negative = 'negative',
  None = '',
}

export enum Tag {
  Accuracy = 'accuracy',
  Completeness = 'completeness',
}

export interface Feedback {
  sentiment: Sentiment;
  text?: string;
  tags?: Tag[];
}

export interface Interaction {
  id: string;
  date?:string;
  req: React.ReactNode;
  res?: React.ReactNode | React.ReactElement;
  feedback?: Feedback;
  loading: boolean;
  feedbackEnabled?: boolean;
}
