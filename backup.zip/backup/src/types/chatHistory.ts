
export interface ChatHistory {
  header:string,
  message:string[]
}
