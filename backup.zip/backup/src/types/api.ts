import { Feedback } from './interaction';

export enum ContentType {
  Text = 'Text',
  Code = 'Code',
  Table = 'Table',
  KnowledgeDiscovery = 'knowledge-discovery',
}

export interface TextResponseNode {
  type: ContentType.Text;
  content: string;
}

export interface TableColumnNode {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'datetime';
}

export interface TableResponseNode {
  type: ContentType.Table;
  columns: Array<TableColumnNode>;
  rows: Array<{ [nameKey: string]: string }>;
}
export interface Snippet {
  text: string;
}
export interface KnowledgeDiscoveryDocuments {
  id: string;
  title: string;
  date: string | null;
  snippets: Array<Snippet>;
}

export interface KnowledgeDiscoveryResponseNode {
  type: ContentType.KnowledgeDiscovery;
  answer: string;
  documents: Array<KnowledgeDiscoveryDocuments>;
}

export interface CodeResponseNode {
  type: ContentType.Code;
  metadata: ContextMetaData;
  content: string;
}

interface ContextMetaData {
  language: string;
  origin: string;
}

interface TextUserInput {
  type: ContentType.Text;
  value: string;
}

interface ContextResponseBody {
  type: ContentType.Code;
  metadata: ContextMetaData;
  content: string;
}

export interface TextResponseBody {
  type: ContentType.Text;
  content: string;
}

export interface InteractionRequestPayload {
  userInput: TextUserInput[];
  sessionId?: string;
  keyonlineuser?: number;
  previousInteractionId?: string;

  supportedNodeTypes?: Array<
    ContentType.Text | ContentType.Table | ContentType.Code | ContentType.KnowledgeDiscovery
  >;
}

export interface InteractionRequestResponse {
  sessionId: string;
  interactionId: string;
  responseBody:
    | Array<TextResponseNode | TableResponseNode | KnowledgeDiscoveryResponseNode>
    | TextResponseBody[];
  responseContext: CodeResponseNode[] | ContextResponseBody[];
  responseTimestamp:string;
}

export interface SessionFeedbackRequestPayload {
  session: string;
  feedback_sentiment: Feedback['sentiment'];
  text_feedback?: Feedback['text'];
  tags?: Feedback['tags'];
}

export interface InteractionFeedbackRequestPayload {
  interaction: string;
  feedback_sentiment: Feedback['sentiment'];
  text_feedback?: Feedback['text'];
  tags?: Feedback['tags'];
}
