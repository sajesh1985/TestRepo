/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-empty-function */

import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';
import HttpAPi from 'i18next-http-backend';

i18next
  .use(HttpAPi)
  .use(initReactI18next)
  .init({
    //request for output text to be the key: https://www.i18next.com/overview/configuration-options
    lng: 'cimode',
    //ignore the rest of these settings, they won't actually apply because we are doing lng = cimode
    debug: false,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
    defaultNS: 'news',
    ns: ['news'],
    react: {
      // we want to enable useSuspense, except when running unit tests (see bootstrapper.tsx)
      useSuspense: false,
    },
  });

//not sure why we need to do this here as well, but tests are complaining if we don't
i18next.changeLanguage('cimode');

process.env.NODE_ENV = 'test';

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation((query) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(),
    removeListener: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});

(window as any).ResizeObserver =
  window.ResizeObserver ||
  function () {
    return {
      observe: function () {},
      unobserve: function () {},
      disconnect: function () {},
    };
  };

global.beforeAll(() => {
  window.sessionStorage.setItem(
    `security/session.accessToken`,
    JSON.stringify({
      value:
        '<jwt0 xmlns="http://www.snl.com/security/tokens">eyJ0eXAiOiJKV0UiLCJhbGciOiJSU0ExXzUiLCJ4NXQiOiI0ODI4OUQzRkY2QjcyOENGRTlENjZDOTc2RTk5ODY5RUE1QzZGMTlGIiwiZW5jIjoiQTI1NkNCQyIsIml2IjoidC1UV3ZxeldncG5rN2hHay02VzgxdyIsInppcCI6IlpJUCJ9.DNCUqrnq-kmTPzgi119CqMG6VgGqo4f43MoOBCAFFNsR8MkwVFhmjzLiARvyquAy7FzNibT1uaRUmZBg3GfxID2r3VnXYM9C-tZ0QzjDmGpD6JOL-WHb9Rqk_J1zCukUZDuIIRynKUwxnL4YkMUGRT_ubAo190nwyUoNP1SEwfw.KS89PpfMde5L5rlfkaS31I_LiZnF8026Y6341ohwxbK1c4pt5XDXdjiWPNp-tQ_3BVDw1K8cqOFfFDwfWJi50XS02xXvgMbx9tjRm6p_8BK5FyAL2XSgh2VC1UqpjBXjH9HLOyTkc9JSWnwAhg_g7KVAHUCK8czB-zlsKJr8ZvXxsbq9yx2Iuy_qIo6c72vuHiQuaqk0qurWA_y_-lI2tue30UmaARLZ_0U-DA_t_9CsmWRW17NP-gddk-0Eq-7llm2MmEAyKNPH875CCgP4_E7hHixzVdO-LO9RZuVpdY77NlDrjWUJogrJpff377gmA37T7RfcMQq9TToDACvARpZpxqKweWFvXFtAVS_lT-45lscf16KyK2XDsqSWhmqN_zaP1Rd66gWnWFj8MzjBv1AqElAABm_pB4jyguJikjb-iuhsseH-geR2fi_dVmUtfHvQShU4NgxrAaIHgDekMsr18u6gbgZUJ5fMeSZsWp6p12kufinElrgI1c-Oci1WvFM9TYumJIJcwjXbDeL_lcT7tpcDhZVThsm0I_6FYv6rnAY_E-SH-1LDJVFYE4oOGNvegnuIYRuuReav66hqQRRTUfq2VD7gxJUOCsfF-uU_XkxEp_BEwraEJ6t4wp60xTXogiGPTxvVVk-FosAzSnqn8ZfROo7XJxYVxDpRymPhMMcdkBZ2zD2IYkldYdh6U_5BXTQkoSn21Qq7C8gE9zdSjbljD2bEW50tgr20JcxxbBYIPZ8ur8yTkQ8vXbr0n9WIwCfGIl-jIX2csk8DI3B3LDPwVLg089UVgmQ-DBdNXffdYGllwl2zkW--rSZkZheGs8N3iBdo_TapFULWH-CYbU-LOCFCLhFuK4Tm3nQ</jwt0>',
    })
  );
});

global.afterAll(() => {
  window.sessionStorage.removeItem(`security/session.accessToken`);
});
