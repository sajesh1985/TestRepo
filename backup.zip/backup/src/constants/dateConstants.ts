export const timeZone = {
  'Dateline Standard Time': 'Etc/GMT+12', //(UTC - 12:00) International Date Line West
  'UTC-11': 'Etc/GMT+11', //(UTC-11:00) Coordinated Universal Time-11
  'Aleutian Standard Time': 'America/Adak', //(UTC-10:00) Aleutian Islands
  'Hawaiian Standard Time': 'Pacific/Honolulu', //(UTC-10:00) Hawaii
  'Marquesas Standard Time': 'Pacific/Marquesas', //(UTC-09:30) Marquesas Islands
  'Alaskan Standard Time': 'America/Anchorage', //(UTC-09:00) Alaska
  'UTC-09': 'Etc/GMT+9', // (UTC-09:00) Coordinated Universal Time-09
  'Pacific Standard Time (Mexico)': 'America/Tijuana', // (UTC-08:00) Baja California
  'UTC-08': 'Etc/GMT+8', //(UTC-08:00) Coordinated Universal Time-08
  'Pacific Standard Time': 'America/Los_Angeles', //(UTC-08:00) Pacific Time (US & Canada)
  'US Mountain Standard Time': 'America/Phoenix', //(UTC-07:00) Arizona
  'Mountain Standard Time (Mexico)': 'America/Chihuahua', //(UTC-07:00) Chihuahua, La Paz, Mazatlan
  'Mountain Standard Time': 'America/Denver', //(UTC-07:00) Mountain Time (US & Canada)
  'Central America Standard Time': 'America/Guatemala', //(UTC-06:00) Central America
  'Central Standard Time': 'America/Chicago', //(UTC-06:00) Central Time (US & Canada)
  'Easter Island Standard Time': 'Pacific/Easter', //(UTC-06:00) Easter Island
  'Central Standard Time (Mexico)': 'America/Mexico_City', //(UTC - 06: 00) Guadalajara, Mexico City, Monterrey
  'Canada Central Standard Time': 'America/Regina', //(UTC-06:00) Saskatchewan
  'SA Pacific Standard Time': 'America/Bogota', //(UTC-05:00) Bogota, Lima, Quito, Rio Branco
  'Eastern Standard Time (Mexico)': 'America/Cancun', //(UTC-05:00) Chetumal
  'Eastern Standard Time': 'America/New_York', //(UTC-05:00) Eastern Time (US & Canada)
  'Haiti Standard Time': 'America/Port-au-Prince', //(UTC-05:00) Haiti
  'Cuba Standard Time': 'America/Havana', //(UTC-05:00) Havana
  'US Eastern Standard Time': 'America/Indianapolis', //(UTC-05:00) Indiana (East)
  'Paraguay Standard Time': 'America/Asuncion', // (UTC-04:00) Asuncion
  'Atlantic Standard Time': 'America/Halifax', //(UTC-04:00) Atlantic Time (Canada)
  'Venezuela Standard Time': 'America/Caracas', //(UTC-04:00) Caracas
  'Central Brazilian Standard Time': 'America/Cuiaba', //(UTC-04:00) Cuiaba
  'SA Western Standard Time': 'America/La_Paz', //(UTC-04:00) Georgetown, La Paz, Manaus, San Juan
  'Pacific SA Standard Time': 'America/Santiago', //(UTC-04:00) Santiago
  'Turks And Caicos Standard Time': 'America/Grand_Turk', //(UTC-04:00) Turks and Caicos
  'Newfoundland Standard Time': 'America/St_Johns', //(UTC-03:30) Newfoundland
  'Tocantins Standard Time': 'America/Araguaina', //(UTC - 03: 00) Araguaina
  'E. South America Standard Time': 'America/Sao_Paulo', //(UTC-03:00) Brasilia
  'SA Eastern Standard Time': 'America/Cayenne', //(UTC - 03: 00) Cayenne, Fortaleza
  'Argentina Standard Time': 'America/Buenos_Aires', //(UTC-03:00) City of Buenos Aires
  'Greenland Standard Time': 'America/Godthab', //(UTC - 03: 00) Greenland
  'Montevideo Standard Time': 'America/Montevideo', //(UTC-03:00) Montevideo
  'Magallanes Standard Time': 'America/Punta_Arenas', //(UTC-03:00) Punta Arenas
  'Saint Pierre Standard Time': 'America/Miquelon', //(UTC-03:00) Saint Pierre and Miquelon
  'Bahia Standard Time': 'America/Bahia', //(UTC-03:00) Salvador
  'UTC-02': 'Etc/GMT+2', //(UTC-02:00) Coordinated Universal Time-02
  'Azores Standard Time': 'Atlantic/Azores', //(UTC-01:00) Azores
  'Cape Verde Standard Time': 'Atlantic/Cape_Verde', //(UTC-01:00) Cabo Verde Is.
  UTC: 'Etc/GMT', //(UTC) Coordinated Universal Time
  'Morocco Standard Time': 'Africa/Casablanca', //(UTC+00:00) Casablanca
  'GMT Standard Time': 'Europe/London', //(UTC+00:00) Dublin, Edinburgh, Lisbon, London
  'Greenwich Standard Time': 'Atlantic/Reykjavik', //(UTC+00:00) Monrovia, Reykjavik
  'W. Europe Standard Time': 'Europe/Berlin', // (UTC + 01: 00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna
  'Central Europe Standard Time': 'Europe/Budapest', //(UTC+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague
  'Romance Standard Time': 'Europe/Paris', //(UTC+01:00) Brussels, Copenhagen, Madrid, Paris
  'Central European Standard Time': 'Europe/Warsaw', //(UTC+01:00) Sarajevo, Skopje, Warsaw, Zagreb
  'W. Central Africa Standard Time': 'Africa/Lagos', //(UTC+01:00) West Central Africa
  'Jordan Standard Time': 'Asia/Amman', //(UTC+02:00) Amman
  'GTB Standard Time': 'Europe/Bucharest', //(UTC+02:00) Athens, Bucharest
  'Middle East Standard Time': 'Asia/Beirut', //(UTC+02:00) Beirut
  'Egypt Standard Time': 'Africa/Cairo', //(UTC+02:00) Cairo
  'E. Europe Standard Time': 'Europe/Chisinau', //(UTC+02:00) Chisinau
  'Syria Standard Time': 'Asia/Damascus', //(UTC+02:00) Damascus
  'West Bank Standard Time': 'Asia/Hebron', //(UTC+02:00) Gaza, Hebron
  'South Africa Standard Time': 'Africa/Johannesburg', //(UTC+02:00) Harare, Pretoria
  'FLE Standard Time': 'Europe/Kiev', //(UTC+02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius
  'Israel Standard Time': 'Asia/Jerusalem', //(UTC+02:00) Jerusalem
  'Kaliningrad Standard Time': 'Europe/Kaliningrad', //(UTC+02:00) Kaliningrad
  'Sudan Standard Time': 'Africa/Khartoum', //(UTC+02:00) Khartoum
  'Libya Standard Time': 'Africa/Tripoli', //(UTC+02:00) Tripoli
  'Namibia Standard Time': 'Africa/Windhoek', //(UTC+02:00) Windhoek
  'Arabic Standard Time': 'Asia/Baghdad', //(UTC+03:00) Baghdad
  'Turkey Standard Time': 'Europe/Istanbul', //(UTC+03:00) Istanbul
  'Arab Standard Time': 'Asia/Riyadh', //(UTC+03:00) Kuwait, Riyadh
  'Belarus Standard Time': 'Europe/Minsk', // (UTC+03:00) Minsk
  'Russian Standard Time': 'Europe/Moscow', //(UTC+03:00) Moscow, St. Petersburg, Volgograd
  'E. Africa Standard Time': 'Africa/Nairobi', //(UTC+03:00) Nairobi
  'Iran Standard Time': 'Asia/Tehran', //(UTC+03:30) Tehran
  'Arabian Standard Time': 'Asia/Dubai', //(UTC+04:00) Abu Dhabi, Muscat
  'Astrakhan Standard Time': 'Europe/Astrakhan', //(UTC+04:00) Astrakhan, Ulyanovsk
  'Azerbaijan Standard Time': 'Asia/Baku', //(UTC+04:00) Baku
  'Russia Time Zone 3': 'Europe/Samara', //(UTC+04:00) Izhevsk, Samara
  'Mauritius Standard Time': 'Indian/Mauritius', //(UTC+04:00) Port Louis
  'Saratov Standard Time': 'Europe/Saratov', //(UTC+04:00) Saratov
  'Georgian Standard Time': 'Asia/Tbilisi', //(UTC+04:00) Tbilisi
  'Caucasus Standard Time': 'Asia/Yerevan', //(UTC+04:00) Yerevan
  'Afghanistan Standard Time': 'Asia/Kabul', //(UTC+04:30) Kabul
  'West Asia Standard Time': 'Asia/Tashkent', //(UTC+05:00) Ashgabat, Tashkent
  'Ekaterinburg Standard Time': 'Asia/Yekaterinburg', //(UTC+05:00) Ekaterinburg
  'Pakistan Standard Time': 'Asia/Karachi', //(UTC+05:00) Islamabad, Karachi
  'India Standard Time': 'Asia/Calcutta', //(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi
  'Sri Lanka Standard Time': 'Asia/Colombo', // (UTC+05:30) Sri Jayawardenepura
  'Nepal Standard Time': 'Asia/Katmandu', //(UTC+05:45) Kathmandu
  'Central Asia Standard Time': 'Asia/Almaty', // (UTC+06:00) Astana
  'Bangladesh Standard Time': 'Asia/Dhaka', //(UTC+06:00) Dhaka
  'Omsk Standard Time': 'Asia/Omsk', //(UTC+06:00) Omsk
  'Myanmar Standard Time': 'Asia/Rangoon', //(UTC+06:30) Yangon (Rangoon)
  'SE Asia Standard Time': 'Asia/Bangkok', //(UTC+07:00) Bangkok, Hanoi, Jakarta
  'Altai Standard Time': 'Asia/Barnaul', //(UTC+07:00) Barnaul, Gorno-Altaysk
  'W. Mongolia Standard Time': 'Asia/Hovd', //(UTC+07:00) Hovd
  'North Asia Standard Time': 'Asia/Krasnoyarsk', // (UTC+07:00) Krasnoyarsk
  'N. Central Asia Standard Time': 'Asia/Novosibirsk', //(UTC+07:00) Novosibirsk
  'Tomsk Standard Time': 'Asia/Tomsk', //(UTC+07:00) Tomsk
  'China Standard Time': 'Asia/Shanghai', //(UTC+08:00) Beijing, Chongqing, Hong Kong, Urumqi
  'North Asia East Standard Time': 'Asia/Irkutsk', //(UTC+08:00) Irkutsk
  'Singapore Standard Time': 'Asia/Singapore', //(UTC+08:00) Kuala Lumpur, Singapore
  'W. Australia Standard Time': 'Australia/Perth', // (UTC+08:00) Perth
  'Taipei Standard Time': 'Asia/Taipei', //(UTC+08:00) Taipei
  'Ulaanbaatar Standard Time': 'Asia/Ulaanbaatar', //(UTC+08:00) Ulaanbaatar
  'Aus Central W. Standard Time': 'Australia/Eucla', // (UTC+08:45) Eucla
  'Transbaikal Standard Time': 'Asia/Chita', //(UTC+09:00) Chita
  'Tokyo Standard Time': 'Asia/Tokyo', //(UTC+09:00) Osaka, Sapporo, Tokyo
  'North Korea Standard Time': 'Asia/Pyongyang', //(UTC+09:00) Pyongyang
  'Korea Standard Time': 'Asia/Seoul', //(UTC+09:00) Seoul
  'Yakutsk Standard Time': 'Asia/Yakutsk', // (UTC+09:00) Yakutsk
  'Cen. Australia Standard Time': 'Australia/Adelaide', //(UTC+09:30) Adelaide
  'AUS Central Standard Time': 'Australia/Darwin', //(UTC+09:30) Darwin
  'E. Australia Standard Time': 'Australia/Brisbane', //(UTC+10:00) Brisbane
  'AUS Eastern Standard Time': 'Australia/Sydney', //(UTC+10:00) Canberra, Melbourne, Sydney
  'West Pacific Standard Time': 'Pacific/Port_Moresby', //(UTC+10:00) Guam, Port Moresby
  'Tasmania Standard Time': 'Australia/Hobart', //(UTC+10:00) Hobart
  'Vladivostok Standard Time': 'Asia/Vladivostok', //(UTC+10:00) Vladivostok
  'Lord Howe Standard Time': 'Australia/Lord_Howe', // (UTC+10:30) Lord Howe Island
  'Bougainville Standard Time': 'Pacific/Bougainville', //(UTC+11:00) Bougainville Island
  'Russia Time Zone 10': 'Asia/Srednekolymsk', // (UTC+11:00) Chokurdakh
  'Magadan Standard Time': 'Asia/Magadan', //(UTC+11:00) Magadan
  'Norfolk Standard Time': 'Pacific/Norfolk', // (UTC+11:00) Norfolk Island
  'Sakhalin Standard Time': 'Asia/Sakhalin', //(UTC+11:00) Sakhalin
  'Central Pacific Standard Time': 'Pacific/Guadalcanal', //(UTC+11:00) Solomon Is., New Caledonia
  'Russia Time Zone 11': 'Asia/Kamchatka', //(UTC+12:00) Anadyr, Petropavlovsk-Kamchatsky
  'New Zealand Standard Time': 'Pacific/Auckland', //(UTC+12:00) Auckland, Wellington
  'UTC+12': 'Etc/GMT-12', //(UTC+12:00) Coordinated Universal Time+12
  'Fiji Standard Time': 'Pacific/Fiji', //(UTC+12:00) Fiji
  'Chatham Islands Standard Time': 'Pacific/Chatham', //(UTC+12:45) Chatham Islands
  'UTC+13': 'Etc/GMT-13', //(UTC+13:00) Coordinated Universal Time+13
  'Tonga Standard Time': 'Pacific/Tongatapu', // (UTC+13:00) Nuku'alofa
  'Samoa Standard Time': 'Pacific/Apia', //(UTC+13:00) Samoa
  'Line Islands Standard Time': 'Pacific/Kiritimati', //(UTC+14:00) Kiritimati Island
};
