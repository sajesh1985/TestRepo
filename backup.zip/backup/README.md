# Introduction

This is the MFE template project which includes Ratings Direct page
# Initial Setup

## App Structure
Folders would follow camelCase naming convention, React components and their unit testing files (*.tsx) would follow Pascal naming convention, any other types of files would still be camelCase. For more details check this link:
https://confluence.marketintelligence.spglobal.com/display/SPP/Recommended+MFE+Folder+Structure
```
template
├── .husky
│       ├── pre-commit - script for running activities like unit testing, auto fixing etc. before each commit to ensure code quality
│
├── public
│       ├── index.html - template for working in standalone mode.
├── src
│   ├── components - contains React components for this MFE
│   │   ├── component1 - group assets (types, component, model, styles, unit testing) associated with this component under the same folder
│   │   │       ├── Component1.tsx - React component
│   │   │       ├── Component1.test.tsx - Unit testing file for the React component
│   │   │       ├── component1.types.ts - TypeScript types or interfaces used by the component
│   │   │       ├── component1.model.ts - model functions, API calls for the component
│   │   │       ├── component1.styles.ts - emotion CSS styles for the component
│   │   ├── component2
│   │   ├── ...
│   │   ├── ...
│   │   ├── otherComponents
│   ├── entry - entry point folder for this MFE
│   │   ├── entry.tsx - component (e.g. RatingsCriteria) specified in this file will be exposed as an entry point for this MFE through webpack.config
│   │
│   │
│   ├── locales - contains folders with resource files
│   ├── utils - shared utility modules
│   ├── standalone.tsx - the entry point for standalone mode (it needs for a local development)
├── .eslintignore
├── .eslintrc.js
├── .gitignore
├── .npmrc
├── .prettierrc
├── jest.config.ts - configuration file for jest unit testing, update collectCoverageFrom after adding new component and its unit testing file
├── jest.setup.ts - common setup steps for unit tests
├── react-spa-mfe.yml - yml file for build and roll out to DEV, Staging and Production (need approval).
├── package.json - contains npm package info and also list of available npm shortcuts
├── README.md
├── tsconfig.json - typescript config for items under the src folder
├── webpack.config.js - contains config for bundling the application and for running locally
└── webpack.config.standalone.js - contains config for bundling the application and for running in standalone mode
```

## building the artifacts

```cmd
npm install (NPM packages are installed already so only if you are making any changes with package.json file)
npm run build:dev
```

or standalone mode

```cmd
npm install (NPM packages are installed already so only if you are making any changes with package.json file)
npm run start
```

## create web.config in the dist directory with the following contents copied into it

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <httpProtocol>
            <customHeaders>
                <add name="Access-Control-Allow-Origin" value="*" />
            </customHeaders>
        </httpProtocol>
        <staticContent>
            <remove fileExtension=".tsx" />
            <mimeMap fileExtension=".tsx" mimeType="application/javascript" />
            <remove fileExtension=".ts" />
            <mimeMap fileExtension=".ts" mimeType="application/javascript" />
            <remove fileExtension=".map" />
            <mimeMap fileExtension=".map" mimeType="text/plain" />
        </staticContent>
    </system.webServer>
</configuration>
```

## create virtual directory in iis

- Open IIS
- Expand folder to Sites/Default Web Site
- Right click on Default Web Site and select 'Add Virtual Directory...'
- Specify '{YourProjectName}' for the Alias
- Specify 'C:\Repos\{YourProjectName}\dist' for the Physical Path (assumes you have created project at C:\Repos)

##Using an internal dev server for development (serve mode)

```cmd
npm run serve
```

- MFE will be available at http://localhost:8888/remoteEntry.js
- You will be able to use your mfe without IIS

## executing from local SSACS MFE (Durandal)

- Setup spg-webplatform using the instructions in https://spglobal.visualstudio.com/SNLServiceModules/_git/spg-webplatform?path=/README.md
- Go to spg-webplatform project
- Add new section into src/spg-webplatform/federated/entry.ts
  ```js
  case "myNewMFE":
    let mfeUrl = 'http://localhost:8888/remoteEntry.js';
    loadComponent("mfeRatingsDirect", "default", "./RatingsCriteria", mfeUrl).then((module) => {
      onload(module);
    });
  break;
  ```
  - Entry url: 'https://[machine name]/{YourIISVirtualDirectoryName}/remoteEntry.js' or 'http://localhost:8888/remoteEntry.js' in serve mode
    Example: 'https://co01-pf1a7e5b.mhf.mhc/{YourIISVirtualDirectoryName}/remoteEntry.js'

  - Scope: 'mfeRatingsDirect'
    Note: values for this can be found in C:\Repos\{YourProjectName}\webpack.config.js (ModuleFederationPlugin.name property) so change as per your project name

  - Module: './RatingsCriteria'
    Note: values for this can be found in C:\Repos\{YourProjectName}\webpack.config.js (ModuleFederationPlugin.exposes property) so change as per your component name

- Go to the file inside the spg-webplatform project where you plan to use the new mfe. it should be a react file (ts/x).
- Add mfe loader call
```js
import React from "react";
import { Provider } from "react-redux";
import { configureReduxStore } from "./store";

const MyNewMFE = React.lazy(() => import('mfe-loader!myNewMFE'));

const MyNewMFEComponent: React.FC = () => {
  //configure your store here if needed
  const store = configureReduxStore({});
  return (
    <Provider store={store}>
      {/*you can use a loader a fallback*/}
      <React.Suspense fallback={null}>
        <MyNewMFE />
      </React.Suspense>
    </Provider>
  );
}

MyNewMFEComponent.displayName = 'MyNewMFEComponent';

export default MyNewMFEComponent;
```
- Build and run the web platform locally as described in the instructions https://spglobal.visualstudio.com/SNLServiceModules/_git/spg-webplatform?path=/README.md
- Open the page where your mfe is used.

## executing from local spa using workbench

- Setup spg-webplatform-core using the instructions in https://spglobal.visualstudio.com/SNLServiceModules/_wiki/wikis/spg-webplatform-core%20(React%20SPA)/5445/README
- Start the core app using npm start
- Open the core app in chrome with developer=1 in query string to display workbench menu on the top right corner of the page (e.g. http://localhost:9090/news/article?id=66811844&developer=1 )
- Click on workbench in menu, wait for the page to render (will take about 30 seconds to fail)
- Click on the gear icon and fill in the popup with appropriate values (replace machine name with yours)

  - Entry url: 'https://[machine name]/{YourIISVirtualDirectoryName}/remoteEntry.js'  or 'http://localhost:8888/remoteEntry.js' in serve mode
    Example: 'https://co01-pf1a7e5b.mhf.mhc/{YourIISVirtualDirectoryName}/remoteEntry.js'

  - Scope: 'mfeRatingsDirect'
    Note: values for this can be found in C:\Repos\{YourProjectName}\webpack.config.js (ModuleFederationPlugin.name property) so change as per your project name

  - Module: './RatingsCriteria'
    Note: values for this can be found in C:\Repos\{YourProjectName}\webpack.config.js (ModuleFederationPlugin.exposes property) so change as per your component name

- Click Apply
- Refresh the page and it should load the news article mfe from this repository on your machine

## executing from dev spa using workbench

- Open chrome and navigate to [capitaliqdev](https://www.capitaliqdev.spglobal.com/SNL.Services.Application.Common.Service/v1/client?auth=inherit#security/login) and then login
- Open the dev core app (with developer=1 in query string) in another tab https://www.capitaliqdev.spglobal.com/apisv3/spg-webplatform-core/news/article?id=66811844&developer=1
- Click on the Workbench button in menu, wait for the page to render
  Note: this will take about 30 seconds and when complete will render an empty rectangle
- Click on the gear icon and fill in the popup with appropriate values (replace machine name with yours)

  - Entry url: 'https://[machine name]]/{YourIISVirtualDirectoryName}/remoteEntry.js'
    Example: 'https://co01-pf1a7e5b.mhf.mhc/{YourIISVirtualDirectoryName}/remoteEntry.js'

  - Scope: 'mfeRatingsDirect'
    Note: values for this can be found in C:\Repos\{YourProjectName}\webpack.config.js (ModuleFederationPlugin.name property) so change as per your project name

  - Module: './RatingsCriteria'
    Note: values for this can be found in C:\Repos\{YourProjectName}\webpack.config.js (ModuleFederationPlugin.exposes property) so change as per your component name

- Click Apply
- Refresh the page and it should load the news article mfe from this repository on your machine

## the list of core's packages available to use
- @spglobal/featureflags - the library that simplifies the reading of LaunchDarkly feature flags via useFlag/useFlags hooks
  Note: if you need access to All feature flags, use useFlag() to return All feature flags in the shape of `{ [feature_flag_name]: [feature_flag_value] }`
- @spglobal/userprofileservice - the library that simplifies the working with User Profile
  Note: it is recommended to use hook useUserTraits(), To get the properties of a user profile, you need to pass an array of the necessary properties to the hook `['title', 'email', 'lastName', 'firstName']`
- @spglobal/spa - the library that simplifies the reading of core's configs and provides `useMessageBus` hook that implements Observer pattern
  Note: `useMessageBus` hook returns object that provides following functions for events' creation, subscription and unsubscription: `next`, `subscribe`, `unsubscribe`
- @spglobal/loggingservice - the library provides `logMostPopular`, `logUsag` functions to log useful metrics
- @spglobal/error - the library provides `SpgError`, `toError`, `toDetailedError`, `AccessDeniedError`, `NotImplementedError`, `TimeoutError` to work with errors;
  A full set of usage examples can be found in the unit testing file spgError.test.ts

## troubleshoot

In case you run into IIS permission or invalid configuration errors when you browse to the entry url then try the following:

- Update App Pool user - Open IIS > Application Pools > Advanced Settings > Change Identity to 'Local System'
- Update 'dist' folder permissions - Right click on 'mfe-news\news\dist' folder. Security tab > Edit > Add > type 'IUSR' (without quotes) > OK
