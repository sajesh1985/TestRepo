// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EmployabilityPlanOverviewComponent } from './employability-plan-overview.component';

// describe('EmployabilityPlanOverviewComponent', () => {
//   let component: EmployabilityPlanOverviewComponent;
//   let fixture: ComponentFixture<EmployabilityPlanOverviewComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EmployabilityPlanOverviewComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EmployabilityPlanOverviewComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
