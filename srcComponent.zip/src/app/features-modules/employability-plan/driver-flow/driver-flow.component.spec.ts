// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DriverFlowComponent } from './driver-flow.component';

// describe('DriverFlowComponent', () => {
//   let component: DriverFlowComponent;
//   let fixture: ComponentFixture<DriverFlowComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DriverFlowComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DriverFlowComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
