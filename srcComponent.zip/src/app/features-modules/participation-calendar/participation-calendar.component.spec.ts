import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipationCalendarComponent } from './participation-calendar.component';

describe('ParticipationCalendarComponent', () => {
  let component: ParticipationCalendarComponent;
  let fixture: ComponentFixture<ParticipationCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipationCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipationCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
