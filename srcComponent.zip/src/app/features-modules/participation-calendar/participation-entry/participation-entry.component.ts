import { ParticipationTrackingService } from './../services/participation-tracking.service';
import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'lodash';
@Component({
  selector: 'app-participation-entry',
  templateUrl: './participation-entry.component.html',
  styleUrls: ['./participation-entry.component.scss']
})
export class ParticipationEntryComponent implements OnInit {
  public isLoaded = false;
  @Input() singlePTEvent: any;
  public model: any;

  public nonParticipationHours: number;
  constructor(private ptService: ParticipationTrackingService) {}

  ngOnInit() {
    this.isLoaded = true;
    this.model = _.cloneDeep(this.singlePTEvent);
  }
  calculate() {
    this.model.nonParticipationHours = this.model.scheduledHours - this.model.reportedHours;
  }
  exit() {
    this.ptService.modeForParticipationEntry.next({ readOnly: false, inEditView: false });
  }
  saveAndExit() {}
}
