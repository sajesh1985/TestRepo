// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { HelpNavComponent } from './help-nav.component';

// describe('HelpNavComponent', () => {
//   let component: HelpNavComponent;
//   let fixture: ComponentFixture<HelpNavComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ HelpNavComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(HelpNavComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
