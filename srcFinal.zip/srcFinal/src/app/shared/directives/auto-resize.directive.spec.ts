/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { AutoResizeDirective } from './auto-resize.directive';

// describe('Directive: AutoResize', () => {
//   it('should create an instance', () => {
//     let directive = new AutoResizeDirective();
//     expect(directive).toBeTruthy();
//   });
// });
