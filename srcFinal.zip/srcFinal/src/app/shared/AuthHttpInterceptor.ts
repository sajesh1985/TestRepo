import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError as observableThrowError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AppService } from './services/app.service';

@Injectable(
{
  providedIn:'root'
})
export class AuthHttpInterceptor implements HttpInterceptor {
  constructor(private authService: AppService, private router: Router) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    //const jwt = this.authService.getAuthToken();

    const jwt = localStorage.getItem('jwt');
    if ( jwt ) {
      request = request.clone({ 
        setHeaders: { 
          Authorization: `Bearer ${jwt}`
        },
        withCredentials: false 
      });
    }

    return next.handle(request);
  }
}
