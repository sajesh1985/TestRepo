// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { LoginSimulationDialogComponent } from './login-simulation-dialog.component';

// describe('LoginSimulationDialogComponent', () => {
//   let component: LoginSimulationDialogComponent;
//   let fixture: ComponentFixture<LoginSimulationDialogComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ LoginSimulationDialogComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LoginSimulationDialogComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
