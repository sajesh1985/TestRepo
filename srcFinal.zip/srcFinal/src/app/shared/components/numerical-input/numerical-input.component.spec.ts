/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { NumericalInputComponent } from './numerical-input.component';

// describe('Component: NumericalInput', () => {
//   it('should create an instance', () => {
//     let component = new NumericalInputComponent();
//     expect(component).toBeTruthy();
//   });
// });
