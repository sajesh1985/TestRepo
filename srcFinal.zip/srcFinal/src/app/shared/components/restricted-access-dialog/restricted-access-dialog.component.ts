import { Component, trigger, state, style, transition, animate, OnInit, Output, EventEmitter } from '@angular/core';
import { Modal, DestroyableComponent } from '../../../shared/modal';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-restricted-access-dialog',
  templateUrl: './restricted-access-dialog.component.html',
  styleUrls: ['./restricted-access-dialog.component.css']
})
@Modal()
export class RestrictedAccessDialogComponent implements DestroyableComponent, OnInit {
  public actionSubmitted = new Subject<{ canAccess: boolean }>();
  public destroy: Function = () => {};
  public closeDialog: Function = () => {};

  constructor() {}

  ngOnInit() {}

  onCancel(): void {
    this.actionSubmitted.next({ canAccess: false });
    this.closeDialog();
    this.destroy();
  }
}
