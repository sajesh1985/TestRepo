import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription, Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AppService } from '../shared/services/app.service';
// import { LogService } from '../shared/services/log.service';
import { AuthHttpClient } from '../shared/AuthHttpClient';

import { Login } from '../shared/models/events/login';
import { environment } from '../../environments/environment';
import { HttpHeaders, HttpClient } from '@angular/common/http';

declare var ga: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  @Input()
  modal: Boolean = false;
  @Output()
  submitted = new EventEmitter<{ authorized: boolean; username: string }>();
  private loginSub: Subscription;
  isLoggingIn = false;
  isUserAuthenticated = false;
  username: string;
  password: string;
  loginMessage = '';
  lostPasswordURL: string = environment.lostPasswordURL;
  requestIDURL: string = environment.requestIDURL;

  constructor(private router: Router, private appService: AppService, private authHttpClient: AuthHttpClient, private http: HttpClient) {}

  ngOnInit() {}

  submitLogin() {
    console.log('login success');
    //this.router.navigate(['/home']);
    //this.logService.timerStart('login');
    this.isLoggingIn = true;
    this.loginSub = this.appService
      .authenticateUser(this.username, this.password)
      .pipe(catchError((err, result) => {
        this.loginMessage = err && err.message ? err.message : 'Unknown Login error';
        //this.logService.timerEndEvent('login', err);
        return of(false);
      }))
      .subscribe(isAuth => {
        this.submitted.emit({ authorized: isAuth, username: this.username });

        const l = new Login();
        l.success = isAuth;
        l.user = this.username;

        if (isAuth) {
          //this.logService.sessionUser(this.username);
          this.authHttpClient.markUserAsActive();
          if (!this.modal) {
            const redirect = this.appService.redirectUrl ? this.appService.redirectUrl : '/home';
            // Seems like the appService.redirectUrl should be cleared out?? Maybe not
            // needed, but we'll be safe.
            this.appService.redirectUrl = null;
            this.router.navigate([redirect]);
          }
        } else {
          this.loginMessage = this.appService.authStatus;
          l.err = this.loginMessage;
          this.password = '';
        }
        this.isLoggingIn = false;
        //this.logService.timerEndEvent('login', l);
      });
  }

  ngOnDestroy() {
    if (this.loginSub != null) {
      this.loginSub.unsubscribe();
    }
  }
}
