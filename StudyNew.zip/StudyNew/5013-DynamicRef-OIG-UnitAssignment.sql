SET QUOTED_IDENTIFIER ON
GO

DECLARE @i int = 0
DECLARE @refnum decimal(10,0)
DECLare @casenum decimal(10,0) = 8002740882
DECLare @pinnum decimal(10,0) =8007959238
declare @caseoffNum smallint = 5013
declare @caseofDesc varchar(40) = 'DANE CO HSD'
declare @pFirstName varchar(30) = 'JAMES'
declare @pLastName varchar(30) = 'PP1'
declare @primOffice smallint = 5013
declare @workerUserID varchar(6) = 'XCTA3N'
declare @workerName varchar(36) = 'KARTHIKEYAN CHAKRAVARTHY'
declare @caseStatus varchar(1) ='O'
declare @countyOfResidence smallint =72
declare @statuscode varchar(25) = 'REF_STS_ASG_INV_OIG_PAR'
declare @sourceCode varchar(25) = 'REF_SRC_SWC'
declare @typeCode varchar(25) = 'REF_TYP_CLAIM'
declare @claimneeded varchar(25) = 'DET_Y'
declare @agencyCode varchar(25) = 'PAR'
declare @agency_Code varchar(25) = 'PAR'
declare @investigationProgram varchar(25) = 'FS'
declare @assignmentType varchar(25) = 'OIG'
declare @assignment_Type varchar(25) = ''
declare @fromDate date = null
declare @toDate date = null
declare @closureDate date = null
declare @claimAssignmentTypeDate date = null
declare @startDate date=null
declare @completionDate date=null
declare @claimNeededDate date=null
declare @isMigrated bit = 0
declare @createdBy int = 25
declare @claimNeededBy int = 358
declare @claimAssignmentTypeBy int = 358
declare @claimAssignmentType_By int = 0
declare @typeAssignedBy int = 358
declare @createdDate datetime = getDate()
declare @updateBy int = 25
declare @updatedDate datetime = getDate()
DECLARE @i_ReferralId	INT;
DECLARE @i_CCProgramId	INT;
DECLARE @i_WWProgramId	INT;
DECLARE @i_FSProgramId	INT;
DECLARE @i_MAProgramId	INT;
DECLARE @i_InvestigationId	INT;
DECLARE @i_Investigator_ID INT = 358;
DECLARE @i_InvestigatorID INT = 358;
DECLARE @claimAssignmentTo INT = 358;
DECLARE @claimAssignmentToDate datetime = getDate();
DECLARE @claimAssignmentToBy INT = 358;
DECLARE @i_invCount INT = 1;
DECLARE @i_totRefCount INT = 3;
DECLARE @isPIAssignmentCompleted bit = 1

WHILE @i < @i_totRefCount 
BEGIN
BEGIN TRY
		BEGIN TRAN;
    SET @i = @i + 1
    EXEC @refnum = [brs].[RetrieveNextAvailableControlNumber] 'Referral'

	CREATE TABLE #Referrals (ReferralNum decimal(10,0))
	insert into #Referrals exec [brs].[RetrieveNextAvailableControlNumber] 'Referral'
	set @refnum = (select * from #Referrals)
	drop table #Referrals 

	IF @i > @i_invCount
		BEGIN
		   IF @i <= @i_invCount + (@i_totRefCount - @i_invCount)/2
			BEGIN
		    SET @statuscode = 'REF_STS_NOTASSIGNED_OIG'
			SET @startDate = null
			SET @completionDate = null
			SET @claimAssignmentTypeDate = null
			SET @claimneeded = null
			SET @claimNeededDate = null
			SET @assignment_Type = @assignmentType
			SET @claimNeededBy = null
			SET @claimAssignmentType_By = null
			SET @claimAssignmentTo = null
			SET @claimAssignmentToDate = null
			SET @claimAssignmentToBy = null
			SET @typeAssignedBy=@typeAssignedBy
			SET @i_Investigator_ID = null
			SET @agency_Code = @agencyCode
			END
           ELSE
		    BEGIN
		     SET @statuscode = 'REF_STS_POSTINVINPROG'
			SET @startDate = @createdDate
			SET @claimAssignmentTypeDate = @createdDate
			SET @completionDate = @createdDate
			SET @claimneeded = 'DET_Y'
			SET @claimNeededDate = @createdDate
			SET @claimNeededBy = 25
			SET @assignment_Type = @assignmentType
			SET @claimAssignmentType_By = @claimAssignmentTypeBy
			SET @typeAssignedBy=@claimNeededBy
			SET @i_Investigator_ID = @i_InvestigatorID
			SET @agency_Code = @agencyCode
			IF @isPIAssignmentCompleted = 1
			BEGIN
		         SET @claimAssignmentTo = @i_Investigator_ID
				SET @claimAssignmentToDate = @createdDate
				SET @claimAssignmentToBy = @claimAssignmentTypeBy
			END
			ELSE
			BEGIN
		         SET @claimAssignmentTo = NULL
			    SET @claimAssignmentToDate = NULL
				SET @claimAssignmentToBy = NULL
			END
		    END
		
	    END
	ELSE
		 BEGIN
		   SET @claimneeded = null
		   SET @claimNeededDate = null
		   SET @claimNeededBy = null
		   SET @claimAssignmentTypeDate = null
		   SET @assignment_Type = @assignmentType
		   SET @claimAssignmentType_By = null
		   SET @i_Investigator_ID = @i_InvestigatorID
		   SET @agency_Code = @agencyCode
		 END
     

	insert into [brs].[Referral]([ReferralNumber],
	[CaseNumber],[PrimaryPIN],CaseOfficeNumber,PrimaryFirstName,PrimaryLastName,PrimaryUserOffice,CaseWorkerID,CaseWorkerName,
	CaseStatus,CountyOfResidence,StatusCode,SourceCode,TypeCode,FromDate,ToDate,ClosureDate,IsMigrated,CreatedBy,CreatedDate,UpdatedBy,UpdatedDate) values (@refnum,@casenum,@pinnum,@caseoffNum,@pFirstName,@pLastName,@primOffice,@workerUserID,@workerName,@caseStatus,@countyOfResidence,
	@statuscode,@sourceCode,@typeCode,@fromDate,@toDate,@closureDate,@isMigrated,@createdBy,@createdDate,@updateBy,@updatedDate)
	SET @i_ReferralId = SCOPE_IDENTITY();

	insert into [brs].[Program]([ReferralID]
      ,[ProgramAreaCode]
      ,[IsValid]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
      ,[OfficeNumber]
      ,[OfficeDescription]) values (@i_ReferralId,'CC',1,@createdBy,@createdDate,@updateBy,@updatedDate,@caseoffNum,@caseofDesc)
	  SET @i_CCProgramId = SCOPE_IDENTITY();

	  insert into [brs].[Program]([ReferralID]
      ,[ProgramAreaCode]
      ,[IsValid]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
      ,[OfficeNumber]
      ,[OfficeDescription]) values (@i_ReferralId,'FS',1,@createdBy,@createdDate,@updateBy,@updatedDate,@caseoffNum,@caseofDesc)
	  SET @i_FSProgramId = SCOPE_IDENTITY();

	  insert into [brs].[Program]([ReferralID]
      ,[ProgramAreaCode]
      ,[IsValid]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
      ,[OfficeNumber]
      ,[OfficeDescription]) values (@i_ReferralId,'MA',1,@createdBy,@createdDate,@updateBy,@updatedDate,@caseoffNum,@caseofDesc)
	  SET @i_MAProgramId = SCOPE_IDENTITY();

	  insert into [brs].[Program]([ReferralID]
      ,[ProgramAreaCode]
      ,[IsValid]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
      ,[OfficeNumber]
      ,[OfficeDescription]) values (@i_ReferralId,'WW',1,@createdBy,@createdDate,@updateBy,@updatedDate,@caseoffNum,@caseofDesc)
	  SET @i_WWProgramId = SCOPE_IDENTITY();

	  insert into [brs].[Investigation]([ReferralID]
		  ,[ProgramAreaCode]
		  ,[Type]
		  ,[TypeAssignedBy]
		  ,[TypeAssignedDate]
		  ,[AgencyCode]
		  ,[AgencyAssignedDate]
		  ,[AgencyAssignedBy]
		  ,[Investigator]
		  ,[InvestigatorAssignedDate]
		  ,[InvestigatorAssignedBy]
		  ,[ReassignedDate]
		  ,[StartDate]
		  ,[CompletionDate]
		  ,[CreatedBy]
		  ,[CreatedDate]
		  ,[UpdatedBy]
		  ,[UpdatedDate]) values (@i_ReferralId,@investigationProgram,@assignment_Type,@typeAssignedBy,@createdDate,@agency_Code,@createdDate,@typeAssignedBy,@i_Investigator_ID,@startDate,@typeAssignedBy,null,@startDate,@completionDate,@createdBy,@createdDate,@updateBy,@updatedDate)
	  SET @i_InvestigationId = SCOPE_IDENTITY();

	  insert into [brs].[InvestigationReasonCode](InvestigationId,InvestigationReasonCode,ErrorFound,ErrorFrom,ErrorTo,IsInvestigationReason,IsAdditionalFinding
	  ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]) values(@i_InvestigationId,'INV_CNC',1,NULL,NULL,1,0,@createdBy,@createdDate,@updateBy,@updatedDate)

	  insert into [brs].[PostInvestigationFollowup]([ProgramID]
      ,[ClaimNeeded]
      ,[ClaimNeededBy]
	  ,[ClaimNeededDate]
	  ,[ClaimAssignmentType]
	  ,[ClaimAssignmentTypeBy]
	  ,[ClaimAssignmentTypeDate]
	  ,[ClaimAssignedAgency]
	  ,[ClaimAssignedAgencyBy]
	  ,[ClaimAssignedAgencyDate]
	  ,[ClaimAssignedAgencyDescription]
	  ,[ClaimAssignedTo]
	  ,[ClaimAssignedToBy]
	  ,[ClaimAssignedToDate]
	  ,[ClaimDateOfDiscovery]
	  ,[ClaimCreated]
	  ,[ClaimCreatedBy]
	  ,[ClaimCreatedDate]
	  ,[PursueFraud]
	  ,[PursueFraudDate]
	  ,[PursueFraudBy]
	  ,[FraudAssignmentType]
	  ,[FraudAssignmentTypeBy]
	  ,[FraudAssignmentTypeDate]
	  ,[FraudAssignedAgency]
	  ,[FraudAssignedAgencyBy]
	  ,[FraudAssignedAgencyDate]
	  ,[FraudAssignedAgencyDescription]
	  ,[FraudAssignedTo]
	  ,[FraudAssignedToBy]
	  ,[FraudAssignedToDate]
	  ,[FraudMethodCode]
	  ,[FraudCommitted]
	  ,[FraudCommittedBy]
	  ,[FraudCommittedDate]
	  ,[FutureCostSavings]
	  ,[Completed]
	  ,[CompletedBy]
	  ,[CompletedDate]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate],[IPVAddition]) values (@i_CCProgramId,@claimneeded,@claimNeededBy,@claimNeededDate,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,@agency_Code,@typeAssignedBy,@createdDate,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,
	  null,null,null,null,@claimneeded,@claimAssignmentTypeDate,@claimNeededBy,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,null,null,null,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,null,null,null,null,null,0,460,@createdDate,@createdBy,@createdDate,@updateBy,@updatedDate,null)
	
	insert into [brs].[PostInvestigationFollowup]([ProgramID]
      ,[ClaimNeeded]
      ,[ClaimNeededBy]
	  ,[ClaimNeededDate]
	  ,[ClaimAssignmentType]
	  ,[ClaimAssignmentTypeBy]
	  ,[ClaimAssignmentTypeDate]
	  ,[ClaimAssignedAgency]
	  ,[ClaimAssignedAgencyBy]
	  ,[ClaimAssignedAgencyDate]
	  ,[ClaimAssignedAgencyDescription]
	  ,[ClaimAssignedTo]
	  ,[ClaimAssignedToBy]
	  ,[ClaimAssignedToDate]
	  ,[ClaimDateOfDiscovery]
	  ,[ClaimCreated]
	  ,[ClaimCreatedBy]
	  ,[ClaimCreatedDate]
	  ,[PursueFraud]
	  ,[PursueFraudDate]
	  ,[PursueFraudBy]
	  ,[FraudAssignmentType]
	  ,[FraudAssignmentTypeBy]
	  ,[FraudAssignmentTypeDate]
	  ,[FraudAssignedAgency]
	  ,[FraudAssignedAgencyBy]
	  ,[FraudAssignedAgencyDate]
	  ,[FraudAssignedAgencyDescription]
	  ,[FraudAssignedTo]
	  ,[FraudAssignedToBy]
	  ,[FraudAssignedToDate]
	  ,[FraudMethodCode]
	  ,[FraudCommitted]
	  ,[FraudCommittedBy]
	  ,[FraudCommittedDate]
	  ,[FutureCostSavings]
	  ,[Completed]
	  ,[CompletedBy]
	  ,[CompletedDate]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate],[IPVAddition]) values (@i_WWProgramId,@claimneeded,@claimNeededBy,@claimNeededDate,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,@agency_Code,@typeAssignedBy,@createdDate,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,
	  null,null,null,null,@claimneeded,@claimAssignmentTypeDate,@claimNeededBy,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,null,null,null,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,null,null,null,null,null,0,460,@createdDate,@createdBy,@createdDate,@updateBy,@updatedDate,null)
	
	insert into [brs].[PostInvestigationFollowup]([ProgramID]
      ,[ClaimNeeded]
      ,[ClaimNeededBy]
	  ,[ClaimNeededDate]
	  ,[ClaimAssignmentType]
	  ,[ClaimAssignmentTypeBy]
	  ,[ClaimAssignmentTypeDate]
	  ,[ClaimAssignedAgency]
	  ,[ClaimAssignedAgencyBy]
	  ,[ClaimAssignedAgencyDate]
	  ,[ClaimAssignedAgencyDescription]
	  ,[ClaimAssignedTo]
	  ,[ClaimAssignedToBy]
	  ,[ClaimAssignedToDate]
	  ,[ClaimDateOfDiscovery]
	  ,[ClaimCreated]
	  ,[ClaimCreatedBy]
	  ,[ClaimCreatedDate]
	  ,[PursueFraud]
	  ,[PursueFraudDate]
	  ,[PursueFraudBy]
	  ,[FraudAssignmentType]
	  ,[FraudAssignmentTypeBy]
	  ,[FraudAssignmentTypeDate]
	  ,[FraudAssignedAgency]
	  ,[FraudAssignedAgencyBy]
	  ,[FraudAssignedAgencyDate]
	  ,[FraudAssignedAgencyDescription]
	  ,[FraudAssignedTo]
	  ,[FraudAssignedToBy]
	  ,[FraudAssignedToDate]
	  ,[FraudMethodCode]
	  ,[FraudCommitted]
	  ,[FraudCommittedBy]
	  ,[FraudCommittedDate]
	  ,[FutureCostSavings]
	  ,[Completed]
	  ,[CompletedBy]
	  ,[CompletedDate]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate],[IPVAddition]) values (@i_FSProgramId,@claimneeded,@claimNeededBy,@claimNeededDate,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,@agency_Code,@typeAssignedBy,@createdDate,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,
	  null,null,null,null,@claimneeded,@claimAssignmentTypeDate,@claimNeededBy,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,null,null,null,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,null,null,null,null,null,0,460,@createdDate,@createdBy,@createdDate,@updateBy,@updatedDate,null)
	
	insert into [brs].[PostInvestigationFollowup]([ProgramID]
      ,[ClaimNeeded]
      ,[ClaimNeededBy]
	  ,[ClaimNeededDate]
	  ,[ClaimAssignmentType]
	  ,[ClaimAssignmentTypeBy]
	  ,[ClaimAssignmentTypeDate]
	  ,[ClaimAssignedAgency]
	  ,[ClaimAssignedAgencyBy]
	  ,[ClaimAssignedAgencyDate]
	  ,[ClaimAssignedAgencyDescription]
	  ,[ClaimAssignedTo]
	  ,[ClaimAssignedToBy]
	  ,[ClaimAssignedToDate]
	  ,[ClaimDateOfDiscovery]
	  ,[ClaimCreated]
	  ,[ClaimCreatedBy]
	  ,[ClaimCreatedDate]
	  ,[PursueFraud]
	  ,[PursueFraudDate]
	  ,[PursueFraudBy]
	  ,[FraudAssignmentType]
	  ,[FraudAssignmentTypeBy]
	  ,[FraudAssignmentTypeDate]
	  ,[FraudAssignedAgency]
	  ,[FraudAssignedAgencyBy]
	  ,[FraudAssignedAgencyDate]
	  ,[FraudAssignedAgencyDescription]
	  ,[FraudAssignedTo]
	  ,[FraudAssignedToBy]
	  ,[FraudAssignedToDate]
	  ,[FraudMethodCode]
	  ,[FraudCommitted]
	  ,[FraudCommittedBy]
	  ,[FraudCommittedDate]
	  ,[FutureCostSavings]
	  ,[Completed]
	  ,[CompletedBy]
	  ,[CompletedDate]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate],[IPVAddition]) values (@i_MAProgramId,@claimneeded,@claimNeededBy,@claimNeededDate,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,@agency_Code,@typeAssignedBy,@createdDate,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,
	  null,null,null,null,@claimneeded,@claimAssignmentTypeDate,@claimNeededBy,@assignment_Type,@claimAssignmentType_By,@claimAssignmentTypeDate,null,null,null,null,@claimAssignmentTo,@claimAssignmentToBy,@claimAssignmentToDate,null,null,null,null,null,0,460,@createdDate,@createdBy,@createdDate,@updateBy,@updatedDate,null)
	
	insert into [brs].[Comment]
	 ([PrimaryIDNumber]
      ,[PrimaryIDTypeCode]
      ,[CommentValue]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
      ,[IsCommentAutoGenerated]) values (@i_ReferralId,'PRM_TYP_REF','Test',@createdBy,@createdDate,@updateBy,@updatedDate,0)
	 
	COMMIT TRAN;
	END TRY
	BEGIN CATCH
		-- Execute error retrieval routine.
		EXECUTE brs.GET_ERROR_INFO
		-- Rollback uncommited transactions
		IF @@TRANCOUNT > 0
			ROLLBACK TRAN
	END CATCH;
END