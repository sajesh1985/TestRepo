// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { RfaChildrenRepeaterComponent } from './rfa-children-repeater.component';

// describe('RfaChildrenRepeaterComponent', () => {
//   let component: RfaChildrenRepeaterComponent;
//   let fixture: ComponentFixture<RfaChildrenRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ RfaChildrenRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(RfaChildrenRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
