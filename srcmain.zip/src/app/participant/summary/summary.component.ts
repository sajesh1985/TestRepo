import { Component, OnInit, OnDestroy, ComponentRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { Participant, ParticipantDetails } from '../../shared/models/participant';
import { ParticipantService } from '../../shared/services/participant.service';
import { AppService } from '../../shared/services/app.service';
import { Authorization } from '../../shared/models/authorization';
import { Utilities } from '../../shared/utilities';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit, OnDestroy {
  public participant: Participant;
  public participantDetails: ParticipantDetails;
  private partSub: Subscription;
  private partDetailsSub: Subscription;

  pin: string;
  isLoadingCWW: boolean = false;
  isTjCollapsed = false;
  isTmjCollapsed = false;
  isCfCollapsed = false;
  isLfCollapsed = false;
  isW2Collapsed = false;
  isOverviewCollapsed = false;
  canViewLF = false;
  canViewWW = false;
  canViewCfTmjTjOverview = false;
  canViewLimitedLF = true;
  canViewLimitedWW = true;
  canViewOtherPrograms = true;
  get isStateStaff(): boolean {
    return this.appService.isUserAuthorized(Authorization.isStateStaff, null);
  }

  constructor(private route: ActivatedRoute, private router: Router, private partService: ParticipantService, private appService: AppService) {}

  ngOnInit() {
    // We want to call details last.

    this.route.params.subscribe(params => {
      this.pin = params['pin'];
      this.loadParticipant();
    });
    // this.partDetailsSub = this.route.params.subscribe(params => {
    //   this.pin = params['pin'];
    //   this.partService.getParticipantSummaryDetails(this.pin)
    //     .subscribe(partD => {
    //       this.initDetailsParticipant(partD);
    //       this.partSub = this.route.params.subscribe(params => {
    //         this.pin = params['pin'];
    //         this.partService.getParticipant(this.pin, true)
    //           .subscribe(part => this.initParticipant(part));
    //       });
    //     });
    // });
    this.scrollToTop();
  }

  scrollToTop() {
    window.scroll(0, 0);
  }

  ngOnDestroy() {
    if (this.partSub) {
      this.partSub.unsubscribe();
    }
    if (this.partDetailsSub != null) {
      this.partDetailsSub.unsubscribe();
    }
  }

  loadParticipant() {
    this.partDetailsSub = this.partService.getParticipantSummaryDetails(this.pin).subscribe(partD => {
      this.initDetailsParticipant(partD);
      this.partSub = this.partService.getParticipant(this.pin, true).subscribe(part => this.initParticipant(part));
    });

    // this.partSub = this.partService.getParticipant(this.pin, true).subscribe(part => {
    //   this.initParticipant(part);
    //   this.partDetailsSub = this.partService.getParticipantSummaryDetails(this.pin).subscribe(partD => this.initDetailsParticipant(partD));
    // });
  }

  private initParticipant(part: Participant) {
    this.participant = part;
    this.getAccessToPsSections(this.participant);
  }

  private initDetailsParticipant(partDetails: ParticipantDetails) {
    this.participantDetails = partDetails;
    this.isLoadingCWW = false;
  }

  // onDashboard() {
  //   this.router.navigateByUrl('home');
  // }

  loadCWW() {
    this.isLoadingCWW = true;
    // this.partSub = this.partService.getParticipant(this.pin, true)
    //   .delay(1000)
    //   .catch(this.handleError)
    //   .finally(() => { this.isLoadingCWW = false; })
    //   .subscribe(part => {
    //     this.initParticipant(part);
    //   });

    this.loadParticipant();
  }

  get isOutOfSyncWarningDisplayed(): boolean {
    return this.participantDetails != null && this.participantDetails.officeTransferId != null && this.participantDetails.officeTransferId > 0;
  }
  toggleCollapse(e: string) {
    switch (e) {
      case 'Tmj':
        this.isTmjCollapsed = !this.isTmjCollapsed;
        break;
      case 'Tj':
        this.isTjCollapsed = !this.isTjCollapsed;
        break;
      case 'Cf':
        this.isCfCollapsed = !this.isCfCollapsed;
        break;
      case 'Lf':
        this.isLfCollapsed = !this.isLfCollapsed;
        break;
      case 'W2':
        this.isW2Collapsed = !this.isW2Collapsed;
        break;
      case 'Overview':
        this.isOverviewCollapsed = !this.isOverviewCollapsed;
        break;
    }
  }
  public isStringEmptyOrNull(str: string) {
    return Utilities.isStringEmptyOrNull(str);
  }
  public showEndDate(participant): boolean {
    if (this.participantDetails) {
      if (
        this.isStringEmptyOrNull(this.participantDetails.w2EligibilityInfo.agFailureReasonCode1) &&
        this.isStringEmptyOrNull(this.participantDetails.w2EligibilityInfo.agFailureReasonCode2) &&
        this.isStringEmptyOrNull(this.participantDetails.w2EligibilityInfo.agFailureReasonCode3)
      ) {
        return false;
      } else {
        return true;
      }
    }
  }
  // todo rethink this logic as this includes a lot of if statements
  public getAccessToPsSections(participant: Participant) {
    let programs = participant.programs;
    let programsUserHasAccessTo = participant.getMostRecentProgramsByAgency(this.appService.user.agencyCode);
    if (programsUserHasAccessTo.length > 0) {
      for (const prog of programsUserHasAccessTo) {
        if ((prog.isLF || prog.isWW) && this.appService.isUserAuthorized(Authorization.canAccessProgram_WW)) {
          this.canViewLF = true;
          this.canViewWW = true;
        } else {
          this.canViewLimitedWW = true;
          this.canViewLimitedLF = true;
        }
        if (prog.isTj || prog.isTmj || prog.isCF) {
          this.canViewCfTmjTjOverview = true;
        }
      }
    } else {
      this.canViewLimitedWW = true;
      this.canViewLimitedLF = true;
      this.canViewOtherPrograms = false;
    }
    if (this.appService.isMostRecentProgramInSisterOrg(programs)) {
      this.canViewOtherPrograms = true;
      if (this.appService.isUserAuthorized(Authorization.canAccessProgram_WW, null)) {
        this.canViewWW = true;
      } else {
        this.canViewLimitedWW = true;
      }
      if (this.appService.isUserAuthorized(Authorization.canAccessProgram_LF, null)) {
        this.canViewLF = true;
      } else {
        this.canViewLimitedLF = true;
      }
      if (this.appService.isUserAuthorized(Authorization.canAccessProgram_CF, null) || this.appService.isUserAuthorized(Authorization.canAccessProgram_TMJ, null)) {
        this.canViewCfTmjTjOverview = true;
      }
    }
    if (programs.length > 0 && !this.canViewCfTmjTjOverview) {
      if (
        this.appService.isUserAuthorized(Authorization.canAccessProgram_CF, null) ||
        this.appService.isUserAuthorized(Authorization.canAccessProgram_TMJ, null) ||
        this.appService.isUserAuthorized(Authorization.canAccessProgram_TJ, null)
      ) {
        this.canViewCfTmjTjOverview = true;
      }
    }
    if (programs.length > 1) {
      programs.forEach(program => {
        if (program.isCF || program.isW2) {
          // If CFMGR trying to access the PS when coenrolled in W2
          if (this.appService.isUserAuthorized(Authorization.canAccessProgram_CF, null)) {
            this.canViewWW = true;
          } else {
            this.canViewLimitedWW = true;
          }
          // if w2 roles trying to access the PS when co-enrolled in CF
          if (this.appService.isUserAuthorized(Authorization.canAccessProgram_WW, null) && program.isW2) {
            this.canViewCfTmjTjOverview = true;
          }
        }
      });
    }
  }

  private handleError(error: any, caughtObs: Observable<any>) {
    // TODO: Display message telling them we could refresh.
    return Observable.throw(error);
  }
}
