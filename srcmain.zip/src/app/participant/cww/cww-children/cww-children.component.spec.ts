// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { CwwChildrenComponent } from './cww-children.component';

// describe('CwwChildrenComponent', () => {
//   let component: CwwChildrenComponent;
//   let fixture: ComponentFixture<CwwChildrenComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ CwwChildrenComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CwwChildrenComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
