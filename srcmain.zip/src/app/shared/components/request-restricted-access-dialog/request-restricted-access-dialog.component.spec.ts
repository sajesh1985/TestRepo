import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestRestrictedAccessDialogComponent } from './request-restricted-access-dialog.component';

describe('RequestRestrictedAccessDialogComponent', () => {
  let component: RequestRestrictedAccessDialogComponent;
  let fixture: ComponentFixture<RequestRestrictedAccessDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestRestrictedAccessDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestRestrictedAccessDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
