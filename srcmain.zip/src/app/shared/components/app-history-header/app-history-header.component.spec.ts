// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AppHistoryHeaderComponent } from './app-history-header.component';

// describe('AppHistoryHeaderComponent', () => {
//   let component: AppHistoryHeaderComponent;
//   let fixture: ComponentFixture<AppHistoryHeaderComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AppHistoryHeaderComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AppHistoryHeaderComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
