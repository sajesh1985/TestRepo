import {Subject } from 'rxjs/Subject';
export function TakeUntilDestroy(){
    return function(constructor:Function){
        let original:Function = constructor.prototype.ngOnDestroy;
        let subject: Subject<string>;
        let dec:ClassDecorator;

        constructor.prototype.componentDestroy = function () {
            subject = new Subject();
            return subject.asObservable();
        };

        constructor.prototype.ngOnDestroy = function(){
            if(original && typeof original === 'function' ){
                original.apply(this,arguments);
            }
            subject.next('ngAutoOnDestroy');
            subject.unsubscribe();
        }
    }
}