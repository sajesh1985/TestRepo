/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { InputFocusDirective } from './input-focus.directive';

// describe('InputFocusDirective', () => {
//   it('should create an instance', () => {
//     let directive = new InputFocusDirective();
//     expect(directive).toBeTruthy();
//   });
// });
