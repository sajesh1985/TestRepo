/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { YesNoComponent } from './yes-no.component';

// describe('Component: YesNo', () => {
//   it('should create an instance', () => {
//     let component = new YesNoComponent();
//     expect(component).toBeTruthy();
//   });
// });
