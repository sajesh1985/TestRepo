import { coerceNumber } from '../../decorators/number-property';
import {
    AfterViewInit,
    Directive,
    ElementRef,
    EventEmitter,
    forwardRef,
    Inject,
    Input,
    NgZone,
    Output,
    Renderer,
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

import { Observable } from 'rxjs';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/skipWhile';
import 'rxjs/add/operator/take';
import 'rxjs/add/observable/interval';
import 'rxjs/add/observable/fromEvent';

import { TinyMceEvents } from './tinymce.events';

import * as TinyMce from 'tinymce';
import { TINYMCE_SETTINGS_TOKEN } from "app/shared/components/tinymce/tinymce.defaultSettings";
declare var tinymce: TinyMce.EditorManager;

@Directive({
    selector: '[tinymceditable]',
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TinyMCEinlineDirective),
            multi: true
        }
    ],
})
export class TinyMCEinlineDirective implements ControlValueAccessor, AfterViewInit {
    elem: ElementRef;
    writeValue(obj: any): void {
        const val = obj != null ? obj.toString() : '';
        if (this.editor) {
            this.fromWriteValue = true;
            this.editor.setContent(val);
        } else {
            this.beforeInitValue = val;
        }
    }

    registerOnChange(fn: any): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: any): void {
        this.onModelTouched = fn;
    }

    setDisabledState?(disabled: boolean): void {
        this.disabled = disabled;
        this.setEditorMode(disabled);
    }

    setEditorMode(disabled: boolean) {
        if (this.editor) {
            if (disabled) {
                this.editor.setMode('readonly');
            } else {
                this.editor.setMode('design');
            }
        }
    }

    onModelChange: Function = () => { };
    onModelTouched: Function = () => { };

    @Input() beforeInitValue: string;
    disabled: boolean;
    fromWriteValue: boolean;

    @Input() isDisabled: boolean;

    // Config Properties
    @Input() settings: TinyMce.Settings;
    @Input() selector: string;

    // Native events
    @Output() public click: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public dblclick: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public mousedown: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public mouseup: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public mousemove: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public mouseover: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public mouseout: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public mouseenter: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public mouseleave: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public keydown: EventEmitter<KeyboardEvent> = new EventEmitter();
    @Output() public keypress: EventEmitter<KeyboardEvent> = new EventEmitter();
    @Output() public keyup: EventEmitter<KeyboardEvent> = new EventEmitter();
    @Output() public contextmenu: EventEmitter<MouseEvent> = new EventEmitter();
    @Output() public paste: EventEmitter<ClipboardEvent> = new EventEmitter();

    // Core events
    @Output() public init: EventEmitter<TinyMce.Events.Event> = new EventEmitter();
    @Output() public focus: EventEmitter<TinyMce.Events.FocusBlurEvent> = new EventEmitter();
    @Output() public blur: EventEmitter<TinyMce.Events.FocusBlurEvent> = new EventEmitter();
    @Output() public beforesetcontent: EventEmitter<TinyMce.Events.ContentEvent> = new EventEmitter();
    @Output() public setcontent: EventEmitter<TinyMce.Events.ContentEvent> = new EventEmitter();
    @Output() public getcontent: EventEmitter<TinyMce.Events.ContentEvent> = new EventEmitter();
    @Output() public preprocess: EventEmitter<TinyMce.Events.ProcessEvent> = new EventEmitter();
    @Output() public postprocess: EventEmitter<TinyMce.Events.ProcessEvent> = new EventEmitter();
    @Output() public nodechange: EventEmitter<TinyMce.Events.NodeChangeEvent> = new EventEmitter();
    @Output() public undo: EventEmitter<TinyMce.Events.UndoRedoEvent> = new EventEmitter();
    @Output() public redo: EventEmitter<TinyMce.Events.UndoRedoEvent> = new EventEmitter();
    @Output() public change: EventEmitter<TinyMce.Events.ChangeEvent> = new EventEmitter();
    @Output() public dirty: EventEmitter<TinyMce.Events.Event> = new EventEmitter();
    @Output() public remove: EventEmitter<TinyMce.Events.Event> = new EventEmitter();
    @Output() public execcommand: EventEmitter<TinyMce.Events.CommandEvent> = new EventEmitter();
    @Output() public pastepreprocess: EventEmitter<TinyMce.Events.ContentEvent> = new EventEmitter();
    @Output() public pastepostprocess: EventEmitter<TinyMce.Events.ContentEvent> = new EventEmitter();
    editor: TinyMce.Editor;

    constructor( @Inject(TINYMCE_SETTINGS_TOKEN) private _settings: any, private ngZone: NgZone, elementRef: ElementRef) {
        this.elem = elementRef;
        const localSettings = this.settings || _settings || {};
        this.settings = Object.assign({}, localSettings);
    }

    public ngAfterViewInit(): void {
        this.settings.target = this.elem.nativeElement;
        this.initCallbacks(this.settings);

        Observable.interval(300)
        .skipWhile(() => !(window as any).tinymce)
        .take(1)
        .subscribe(() => {
          tinymce.init(this.settings);
        });
    }

    initCallbacks(settings: TinyMce.Settings): void {

        const origSetup = settings.setup;
        settings.setup = (editor: TinyMce.Editor) => {
            editor.on(TinyMceEvents.Init, (e: TinyMce.Events.Event) => this.init.emit(e));
            if (origSetup) {
                origSetup(editor);
            }
        };
       const origInstanceCallback = settings.init_instance_callback;
       settings.init_instance_callback = (editor: TinyMce.Editor) => {
        this.editor = editor;
        this.setEditorMode(this.disabled);
        if (this.beforeInitValue != null) {
          this.editor.setContent(this.beforeInitValue);
        }
        if (origInstanceCallback) {
          origInstanceCallback(editor);
        }
  
        editor.on(TinyMceEvents.Click, (e: MouseEvent) => this.click.emit(e));
        editor.on(TinyMceEvents.DblClick, (e: MouseEvent) => this.dblclick.emit(e));
        editor.on(TinyMceEvents.MouseDown, (e: MouseEvent) => this.mousedown.emit(e));
        editor.on(TinyMceEvents.MouseUp, (e: MouseEvent) => this.mouseup.emit(e));
        editor.on(TinyMceEvents.MouseMove, (e: MouseEvent) => this.mousemove.emit(e));
        editor.on(TinyMceEvents.MouseOver, (e: MouseEvent) => this.mouseover.emit(e));
        editor.on(TinyMceEvents.MouseOut, (e: MouseEvent) => this.mouseout.emit(e));
        editor.on(TinyMceEvents.MouseEnter, (e: MouseEvent) => this.mouseenter.emit(e));
        editor.on(TinyMceEvents.MouseLeave, (e: MouseEvent) => this.mouseleave.emit(e));
        editor.on(TinyMceEvents.KeyDown, (e: KeyboardEvent) => this.keydown.emit(e));
        editor.on(TinyMceEvents.KeyPress, (e: KeyboardEvent) => this.keypress.emit(e));
        editor.on(TinyMceEvents.KeyUp, (e: KeyboardEvent) => {
          this.ngZone.run(() => {
            this.triggerChange();
          });
          this.keyup.emit(e);
        });
        editor.on(TinyMceEvents.ContextMenu, (e: MouseEvent) => this.contextmenu.emit(e));
        editor.on(TinyMceEvents.Paste, (e: ClipboardEvent) => this.paste.emit(e));
  
        editor.on(TinyMceEvents.Focus, (e: TinyMce.Events.FocusBlurEvent) => this.focus.emit(e));
        editor.on(TinyMceEvents.Blur, (e: TinyMce.Events.FocusBlurEvent) => this.blur.emit(e));
        editor.on(TinyMceEvents.BeforeSetContent, (e: TinyMce.Events.ContentEvent) => this.beforesetcontent.emit(e));
        editor.on(TinyMceEvents.SetContent, (e: TinyMce.Events.ContentEvent) => {
          this.ngZone.run(() => {
            this.triggerChange();
          });
          this.setcontent.emit(e);
        });
        editor.on(TinyMceEvents.GetContent, (e: TinyMce.Events.ContentEvent) => this.getcontent.emit(e));
        editor.on(TinyMceEvents.PreProcess, (e: TinyMce.Events.ProcessEvent) => this.preprocess.emit(e));
        editor.on(TinyMceEvents.PostProcess, (e: TinyMce.Events.ProcessEvent) => this.postprocess.emit(e));
        editor.on(TinyMceEvents.NodeChange, (e: TinyMce.Events.NodeChangeEvent) => this.nodechange.emit(e));
        editor.on(TinyMceEvents.Undo, (e: TinyMce.Events.UndoRedoEvent) => this.undo.emit(e));
        editor.on(TinyMceEvents.Redo, (e: TinyMce.Events.UndoRedoEvent) => this.redo.emit(e));
        editor.on(TinyMceEvents.Change, (e: TinyMce.Events.ChangeEvent) => this.change.emit(e));
        editor.on(TinyMceEvents.Dirty, (e: TinyMce.Events.Event) => this.dirty.emit(e));
        editor.on(TinyMceEvents.Remove, (e: TinyMce.Events.Event) => this.remove.emit(e));
        editor.on(TinyMceEvents.ExecCommand, (e: TinyMce.Events.CommandEvent) => {
          this.ngZone.run(() => {
            this.triggerChange();
          });
          this.execcommand.emit(e);
        });
        editor.on(TinyMceEvents.PastePreProcess, (e: TinyMce.Events.ContentEvent) => this.pastepreprocess.emit(e));
        editor.on(TinyMceEvents.PastePostProcess, (e: TinyMce.Events.ContentEvent) => this.pastepostprocess.emit(e));
      };
    }

    triggerChange() {
        if (this.fromWriteValue) {
            this.fromWriteValue = false;
        } else {
            const content = this.editor.getContent();
            if (content != null && content.length > 0) {
                this.onModelChange(content);
                this.onModelTouched();
            }
        }
    }

    ngOnDestroy(): void {
        if (this.editor) {
            (tinymce as any).remove(this.editor);
        }
    }
}