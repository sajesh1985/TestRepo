/* tslint:disable:no-unused-variable */
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { By } from '@angular/platform-browser';
// import { DebugElement } from '@angular/core';

// import { DateMmYyyyInputComponent } from './date-mm-yyyy-input.component';

// describe('DateMmYyyyInputComponent', () => {
//   let component: DateMmYyyyInputComponent;
//   let fixture: ComponentFixture<DateMmYyyyInputComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DateMmYyyyInputComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DateMmYyyyInputComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
