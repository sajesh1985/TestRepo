// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DateMmDdYyyyNewComponent } from './date-mm-dd-yyyy-new.component';

// describe('DateMmDdYyyyNewComponent', () => {
//   let component: DateMmDdYyyyNewComponent;
//   let fixture: ComponentFixture<DateMmDdYyyyNewComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DateMmDdYyyyNewComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DateMmDdYyyyNewComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
