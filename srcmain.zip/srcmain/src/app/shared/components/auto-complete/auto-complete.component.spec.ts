/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { AutoCompleteComponent } from './auto-complete.component';

// describe('Component: AutoComplete', () => {
//   it('should create an instance', () => {
//     let component = new AutoCompleteComponent();
//     expect(component).toBeTruthy();
//   });
// });
