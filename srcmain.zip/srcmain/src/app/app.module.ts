// import { ContentService } from './shared/services/content.service';
// import { SystemClockService } from './shared/services/system-clock.service';
// import { tinymceDefaultSettings } from './shared/components/tinymce/tinymce.defaultSettings';
import { environment } from '../environments/environment';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler, NgZone, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { HttpModule, Http, RequestOptions, XHRBackend } from '@angular/http';
import { JwtHelperService } from '@auth0/angular-jwt';
import { JwtAuthConfig } from './jwt-auth-config';

import { AngularFireModule } from 'angularfire2'
// import { AngularFireDatabaseModule, AngularFireDatabase } from 'angularfire2/database'
import { AuthHttp } from 'angular2-jwt';
import { MomentModule } from 'angular2-moment';
import { Ng2DatetimePickerModule } from 'ng2-datetime-picker';
import { HttpClient, HttpBackend, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
// import { TinyMceModule } from './shared/components/tinymce/tinymce.module';

import { AppComponent } from './app.component';
import { routing, appRoutingProviders } from './app.routing';
// import { AuthHttpClient } from './shared/AuthHttpClient';
// import { ApplicationHttpClient } from './shared/AppAuthHttpClient';
import { ModalService } from './shared/modal/modal.service';
import { SimpleNotificationsModule } from 'angular2-notifications';

// import { ActionNeededComponent } from './shared/components/action-needed/action-needed.component';
import { AppService } from './shared/services/app.service';
// import { AppHistoryAlertComponent } from './shared/components/app-history-alert/app-history-alert.component';
import { AutoCompleteComponent } from './shared/components/auto-complete/auto-complete.component';
// import { AutoResizeDirective } from './shared/directives/auto-resize.directive';
// tslint:disable-next-line:max-line-length
// import { Between13And18ChildrenAgeRepeaterComponent } from './participant/informal-assessment/edit/between13-and18-children-age-repeater/between13-and18-children-age-repeater.component';
// import { CaretakingRepeaterComponent } from './participant/informal-assessment/edit/caretaking-repeater/caretaking-repeater.component';
// import { ChildYouthSupportsEditComponent } from './participant/informal-assessment/edit/child-youth-supports.component';
// import { ChildYouthSupportsOverviewComponent } from './participant/informal-assessment/overview/child-youth-supports.component';
// import { CollegeRepeaterComponent } from './participant/informal-assessment/edit/college-repeater/college-repeater.component';
// import { ConfirmDialogComponent } from './shared/components/confirm-dialog/confirm-dialog.component';
// import { ContactDetailComponent } from './contacts/detail/detail.component';
// import { ContactsEditComponent } from './contacts/edit/edit.component';
// import { ContactsEmbedComponent } from './contacts/embed/embed.component';
// import { ContactsListComponent } from './contacts/list/list.component';
// import { ContactsListPageComponent } from './contacts/list-page/list-page.component';
// import { ContactsSelectComponent } from './contacts/select/select.component';
// import { ConvictionRepeaterComponent } from './participant/informal-assessment/edit/conviction-repeater/conviction-repeater.component';
// import { CourtDatesRepeaterComponent } from './participant/informal-assessment/edit/court-dates-repeater/court-dates-repeater.component';
// import { CurrencyInputComponent } from './shared/components/currency-input/currency-input.component';
import { HomePageComponent } from './home-page/home-page.component';
// import { DateInputComponent } from './shared/components/date-input/date-input.component';
// import { DateMmDdYyyyComponent } from './shared/components/date-mm-dd-yyyy/date-mm-dd-yyyy.component';
// import { DateMmYyyyInputComponent } from './shared/components/date-mm-yyyy-input/date-mm-yyyy-input.component';
// import { DegreeRepeaterComponent } from './participant/informal-assessment/edit/degree-repeater/degree-repeater.component';
// import { DialogBoxComponent } from './shared/components/dialog-box/dialog-box.component';
// import { EditComponent as InformalAssessmentEditComponent } from './participant/informal-assessment/edit/edit.component';
// import { EducationHistoryEditComponent } from './participant/informal-assessment/edit/education-history.component';
// import { EducationHistoryOverviewComponent } from './participant/informal-assessment/overview/education-history.component';
// import { EducationTabComponent } from './participant/informal-assessment/edit/education-tab/education-tab.component';
// import { EmptyStringIfNullPipe } from './shared/pipes/empty-string-if-null.pipe';
// import { FamilyBarriersEditComponent } from './participant/informal-assessment/edit/family-barriers.component';
// import { FamilyBarriersOverviewComponent } from './participant/informal-assessment/overview/family-barriers.component';
// import { GenericTextInputComponent } from './shared/components/generic-text-input/generic-text-input.component';
import { HeaderComponent } from './header/header.component';
// import { HousingEditComponent } from './participant/informal-assessment/edit/housing.component';
// import { HousingOverviewComponent } from './participant/informal-assessment/overview/housing.component';
// import { HousingRepeaterComponent } from './participant/informal-assessment/edit/housing-repeater/housing-repeater.component';
// import { InputFocusDirective } from './shared/directives/input-focus.directive';
// import { LanguageRepeaterComponent } from './participant/informal-assessment/edit/language-repeater/language-repeater.component';
// import { LanguagesEditComponent } from './participant/informal-assessment/edit/languages.component';
// import { LanguagesOverviewComponent } from './participant/informal-assessment/overview/languages.component';
// import { LegalIssuesEditComponent } from './participant/informal-assessment/edit/legal-issues.component';
// import { LegalIssuesOverviewComponent } from './participant/informal-assessment/overview/legal-issues.component';
// import { LicenseRepeaterComponent } from './participant/informal-assessment/edit/license-repeater/license-repeater.component';
// import { ListingComponent } from './shared/components/listing/listing.component';
import { LoginComponent } from './login/login.component';
// import { LogoutComponent } from './logout/logout.component';
import { LogService, LogServiceConfig } from './shared/services/log.service';
// import { MilitaryOverviewComponent } from './participant/informal-assessment/overview/military.component';
// import { MilitaryTrainingEditComponent } from './participant/informal-assessment/edit/military-training.component';
// import { ModifiedStampComponent } from './shared/components/modified-stamp/modified-stamp.component';
// import { NumericalInputComponent } from './shared/components/numerical-input/numerical-input.component';
// import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ParticipantService } from './shared/services/participant.service';
// import { PhoneNumberInputComponent } from './shared/components/phone-number-input/phone-number-input.component';
// import { PhoneNumberPipe } from './shared/pipes/phone-number.pipe';
// import { PostSecondaryEducationEditComponent } from './participant/informal-assessment/edit/post-secondary-education.component';
// import { PostSecondaryEducationOverviewComponent } from './participant/informal-assessment/overview/post-secondary-education.component';
// import { TransportationOverviewComponent } from './participant/informal-assessment/overview/transportation.component';
// import { RadioButtonComponent } from './shared/components/radio-button/radio-button.component';
// import { ReleaseNotesComponent } from './release-notes/release-notes.component';
// import { RemoteAutoCompleteComponent } from './shared/components/remote-auto-complete/remote-auto-complete.component';
// import { RemoteAutoSuggestComponent } from './shared/components/remote-auto-suggest/remote-auto-suggest.component';
// import { SelectComponent } from './shared/components/select/select.component';
import { StartComponent } from './start/start.component';
// import { SubHeaderComponent } from './sub-header/sub-header.component';
// import { SubHeaderNavComponent } from './sub-header-nav/sub-header-nav.component';
// import { SummaryComponent as InformalAssessmentSummaryComponent } from './participant/informal-assessment/summary/summary.component';
// import { SummaryComponent as ParticipantSummaryComponent } from './participant/summary/summary.component';
// import { TabSelectorComponent } from './shared/components/tab-selector/tab-selector.component';
// import { TestScoresEmbedComponent } from './test-scores/embed/embed.component';
// import { TextAreaComponent } from './shared/components/text-area/text-area.component';
// import { Under12ChildAgeRepeaterComponent } from './participant/informal-assessment/edit/under12-child-age-repeater/under12-child-age-repeater.component';
// import { ValidationSummaryComponent } from './shared/components/validation-summary/validation-summary.component';
// import { WorkHistoryCurrentWageComponent } from './work-history/current-wage/current-wage.component';
// import { WorkHistoryEditComponent } from './work-history/edit/edit.component';
// import { WorkHistoryGatepostEditComponent } from './participant/informal-assessment/edit/work-history.component';
// import { WorkHistoryLeaveHistoryComponent } from './work-history/leave-history/leave-history.component';
// import { WorkHistoryListComponent } from './work-history/list/list.component';
// import { WorkHistoryListPageComponent } from './work-history/list-page/list-page.component';
// import { WorkHistoryOverviewComponent } from './participant/informal-assessment/overview/work-history.component';
// import { WorkHistoryPastWageComponent } from './work-history/past-wage/past-wage.component';
// import { WorkHistoryWageHistoryComponent } from './work-history/wage-history/wage-history.component';
// import { WorkProgramRepeaterComponent } from './participant/informal-assessment/edit/work-program-repeater/work-program-repeater.component';
// import { WorkProgramsEditComponent } from './participant/informal-assessment/edit/work-programs.component';
// import { WorkProgramsOverviewComponent } from './participant/informal-assessment/overview/work-programs.component';
// import { YesNoBasicComponent } from './shared/components/yes-no-basic/yes-no-basic.component';
// import { YesNoComponent } from './shared/components/yes-no/yes-no.component';
// import { YesNoPipe } from './shared/pipes/yes-no.pipe';
import { MultiSelectDropdownComponent } from './shared/components/multi-select-dropdown/multi-select-dropdown.component';
// import { MoneyMaskDirective } from './shared/directives/money-mask.directive';
// import { WorkHistorySingleComponent } from './work-history/single/single.component';
// import { WorkHistoryEmbedComponent } from './work-history/embed/embed.component';
// import { TextInputComponent } from './shared/components/text-input/text-input.component';
// import { DropdownComponent } from './shared/components/dropdown/dropdown.component';
// import { AppErrorHandler } from './error.handler';
// import { DateMmYyyyComponent } from './shared/components/date-mm-yyyy/date-mm-yyyy.component';
// import { ParticipantBarriersEditComponent } from './participant/informal-assessment/edit/participant-barriers.component';
// import { YesNoRefuseComponent } from './shared/components/yes-no-refuse/yes-no-refuse.component';
// import { ParticipantBarriersEditComponent as ParticipantBarriersEditComponentApp } from './participant-barriers/edit/edit.component';
// import { ParticipantBarriersEmbedComponent } from './participant-barriers/embed/embed.component';
// import { ParticipantBarriersListComponent } from './participant-barriers/list/list.component';
// import { ParticipantBarriersListPageComponent } from './participant-barriers/list-page/list-page.component';
import { Ng2PaginationModule } from 'ng2-pagination';
// import { ParticipantBarriersSingleComponent } from './participant-barriers/single/single.component';
// import { BarriersAccommodationsRepeaterComponent } from './participant-barriers/accommodations/accommodations.component';
// import { BarriersFormalAssessmentRepeaterComponent } from './participant-barriers/formal-assessments/formal-assessments.component';
// import { DateMmDdYyyyNewComponent } from './shared/components/date-mm-dd-yyyy-new/date-mm-dd-yyyy-new.component';
// import { ContactsRepeaterComponent } from './contacts/repeater/repeater.component';
import { LoginDialogComponent } from './shared/components/login-dialog/login-dialog.component';
import { ModalPlaceholderComponent } from './shared/modal/modal-placeholder/modal-placeholder.component';
// import { MonthSelectorComponent } from './shared/components/month-selector/month-selector.component';
// import { SummaryComponent as TimeLimitsSummaryComponent } from './time-limits/summary/summary.component';
// import { ClockSummaryComponent } from './time-limits/summary/clock-summary.component';
// import { TimelimitsTimelineComponent } from './time-limits/timeline/limits-timeline.component';
// import { MonthDetailsComponent } from './time-limits/month-details/month-details.component';
// import { ClockSummaryDetailsComponent } from './time-limits/clock-summary-details/clock-summary-details.component';
// import { DefaultPipe } from './shared/pipes/default.pipe';
// import { EditExtensionComponent } from './time-limits/extensions/edit/edit-extension.component';
// import { MonthBoxComponent } from './time-limits/timeline/month-box/month-box.component';
// import { EditMonthComponent } from './time-limits/edit/edit-month.component';
// import { ScrollDirective } from './shared/directives/scroll.directive';
import { ValidationManager } from './shared/models/validation';
// import { ExtensionListComponent } from './time-limits/extensions/list/list.component';
// import { ExtensionListPageComponent } from './time-limits/extensions/list-page/list-page.component';
// import { ExtensionDetailComponent } from './time-limits/extensions/detail/detail.component';
// import { ClockTypeNamePipe } from './time-limits/pipes/clock-type-name.pipe';
// import { DateChangerComponent } from './shared/components/admin/date-changer/date-changer.component';
// import { RestrictedAccessDialogComponent } from './shared/components/restricted-access-dialog/restricted-access-dialog.component';
// import { SearchComponent } from './time-limits/search/search.component';
// import { TimeLimitsService } from './shared/services/timelimits.service';
// import { DateYyyyComponent } from './shared/components/date-yyyy/date-yyyy.component';
// import { NcpEditComponent } from './participant/informal-assessment/edit/ncp.component';
// import { NcpCaretakerRepeaterComponent } from './participant/informal-assessment/edit/ncp-caretaker-repeater/ncp-caretaker-repeater.component';
// import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
// import { NcpChildRepeaterComponent } from './participant/informal-assessment/edit/ncp-child-repeater/ncp-child-repeater.component';
// import { NcpOverviewComponent } from './participant/informal-assessment/overview/ncp.component';
// import { DeleteWarningComponent } from './time-limits/extensions/delete-warning/delete-warning.component';
// import { NcprChildRepeaterComponent } from './participant/informal-assessment/edit/ncpr-child-repeater/ncpr-child-repeater.component';
// import { NcprOtherParentRepeaterComponent } from './participant/informal-assessment/edit/ncpr-other-parent-repeater/ncpr-other-parent-repeater.component';
// import { NcprEditComponent } from './participant/informal-assessment/edit/ncpr.component';
// import { NcprOverviewComponent } from './participant/informal-assessment/overview/ncpr.component';
// import { HelpComponent } from './shared/components/help/help.component';
// import { TestScoresListComponent } from './test-scores/list/list.component';
// import { TestScoresEditComponent } from './test-scores/edit/edit.component';
// import { PageHelpComponent } from './help/help.component';
// import { HelpNavComponent } from './help/help-nav/help-nav.component';
// // import { HelpPagesComponent } from './help/help-pages/help-pages.component';
// import { TransportationEditComponent } from './participant/informal-assessment/edit/transportation.component';
// import { DeleteReasonButtonComponent } from './shared/components/delete-reason-button/delete-reason-button.component';
// import { TestScoresListPageComponent } from './test-scores/list-page/list-page.component';
// import { TimeLimitExtensionsHelpComponent } from './help/help-pages/tl-ext-decisions.component';
// import { TimeLimitOverviewHelpComponent } from './help/help-pages/tl-overview.component';
// import { TestScoreCardComponent } from './test-scores/card/card.component';
// import { ParticipantBarriersOverviewComponent } from './participant/informal-assessment/overview/participant-barriers.component';
// import { InputHistoryComponent } from './shared/components/input-history/input-history.component';
// import { ActionsNeededComponent } from './actions-needed/actions-needed.component';
// import { ActionNeededEmbedComponent } from './actions-needed/embed/embed.component';
// import { ActionNeededEditComponent } from './actions-needed/edit/edit.component';
// import { ActionNeededListViewComponent } from './actions-needed/list-view/list-view.component';
// import { ActionNeededTaskComponent } from './actions-needed/task/task.component';
// import { DateMmDdYyyyPipe } from './shared/pipes/date-mm-dd-yyyy.pipe';
// import { ActionNeededListPipe } from './actions-needed/pipes/action-needed-list.pipe';
// import { FilterComponent } from './shared/components/filter/filter.component';
// import { ActionNeededEmbedTaskComponent } from './actions-needed/embed/embed-task/embed-task.component';
// import { ArraySeparatorByCharPipe } from './shared/pipes/array-separator-by-char.pipe';
import { LoginSimulationDialogComponent } from './shared/components/login-simulation-dialog/login-simulation-dialog.component';
// import { CKButtonDirective, CKEditorComponent, CKGroupDirective, CkEditableDirective } from './shared/components/ck-editor';
// import { ContentContainerModuleComponent } from './shared/components/content/content-container/container.component';
// import { TextContentModuleComponent } from './shared/components/content/text-content-module/text-content-module.component';
// import { ContentEditBarComponent } from './shared/components/content/content-edit-bar/content-edit-bar.component';
import { DynamicModule } from 'ng-dynamic-component';
// import { ParticipantCardComponent } from './home-page/participant-card/participant-card.component';
// import { EnrollmentComponent } from './enrollment/enrollment/enrollment.component';
// import { DisenrollmentComponent } from './enrollment/disenrollment/disenrollment.component';
// import { EnrollmentHeaderComponent } from './enrollment/header/header.component';
// import { OnlyNumbersDirective } from './shared/directives/numbers-only.directive';
// import { WorkHistoryAppService } from './shared/services/work-history-app.service';
// import { ErrorModalComponent } from './shared/components/error-modal/error-modal.component';
// import { ReassignComponent } from './enrollment/reassign/reassign.component';
// import { ClearanceComponent } from './clearance/clearance.component';
// import { TransferComponent } from './enrollment/transfer/transfer.component';
// import { RegistrationComponent } from './enrollment/registration/registration.component';
// import { AliasSsnRepeaterComponent } from './enrollment/registration/alias-ssn-repeater/alias-ssn-repeater.component';
// import { RfaEditComponent } from './rfa/edit/edit.component';
// import { CwwChildrenComponent } from './participant/cww/cww-children/cww-children.component';
// import { CardHeaderComponent } from './participant/informal-assessment/overview/card-header/card-header.component';
// import { AppHistoryHeaderComponent } from './shared/components/app-history-header/app-histoy-header.component';
// import { SsnPipe } from './shared/pipes/ssn.pipe';
// import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
// import { InformalAssessmentEditService} from './shared/services/informal-assessment-edit.service';
// import { WarningModalComponent } from './shared/components/warning-modal/warning-modal.component';
// import { DateMmYyyyPipe } from './shared/pipes/date-mm-yyyy.pipe';
import { PadPipe } from './shared/pipes/pad.pipe';
// import { RfaChildrenRepeaterComponent } from './rfa/rfa-children-repeater/rfa-children-repeater.component';
// import { RfaPageComponent } from './rfa/page/page.component';
// import { RfaListComponent } from './rfa/list/list.component';
import { UserPreferencesService } from './shared/services/user-preferences.service';
// import { RfaSingleComponent } from './rfa/single/single.component';
// import { HighDatePipe } from './shared/pipes/high-date.pipe';
import { HighlightHoverDirective } from './shared/directives/highlight-hover';
// import { PepCardComponent } from './participant/summary/pep-card/pep-card.component';
// import { ReportsComponent } from './webi/reports/reports.component';
// import { AliasRepeaterComponent } from './clearance/alias-repeater/alias-repeater.component';
// import { RequestRestrictedAccessDialogComponent } from './shared/components/request-restricted-access-dialog/request-restricted-access-dialog.component';
import { NgxMaskModule } from 'ngx-mask'
import { AuthHttpInterceptor } from './shared/AuthHttpInterceptor';
import { AuthHttpClient } from './shared/AuthHttpClient';
// import { HttpBackend } from '@angular/common/http';
// Must export the AngularFireModule config
// export const firebaseConfig = {
//   production: environment.production,
//   firebase: {
//     apiKey: 'AIzaSyCz5i8ab9tfeDP9KcszdcZe38vSdcNLUaU',
//     authDomain: 'wwp-app.firebaseapp.com',
//     databaseURL: 'https://wwp-app.firebaseio.com',
//     storageBucket: 'wwp-app.appspot.com',
//     messagingSenderId: '429951518007'
//   }
// };

// export const logServiceConfig: LogServiceConfig = new LogServiceConfig {
//   messagesToConsole: true,
// };


@NgModule({
  declarations: [
    // ActionNeededComponent,
    AppComponent,
    // AppHistoryAlertComponent,
    AutoCompleteComponent,
    // AutoResizeDirective,
    // Between13And18ChildrenAgeRepeaterComponent,
    // CaretakingRepeaterComponent,
    // ChildYouthSupportsEditComponent,
    // ChildYouthSupportsOverviewComponent,
    // CollegeRepeaterComponent,
    // ConfirmDialogComponent,
    // ContactDetailComponent,
    // ContactsEditComponent,
    // ContactsEmbedComponent,
    // ContactsListComponent,
    // ContactsListPageComponent,
    // ContactsSelectComponent,
    // ConvictionRepeaterComponent,
    // CourtDatesRepeaterComponent,
    // CurrencyInputComponent,
    HomePageComponent,
    // DateInputComponent,
    // DateMmDdYyyyComponent,
    // DateMmYyyyInputComponent,
    // DegreeRepeaterComponent,
    // DialogBoxComponent,
    // EducationHistoryEditComponent,
    // EducationHistoryOverviewComponent,
    // EducationTabComponent,
    // EmptyStringIfNullPipe,
    // FamilyBarriersEditComponent,
    // FamilyBarriersOverviewComponent,
    // GenericTextInputComponent,
    HeaderComponent,
    // HousingEditComponent,
    // HousingOverviewComponent,
    // HousingRepeaterComponent,
    // InformalAssessmentEditComponent,
    // InformalAssessmentSummaryComponent,
    // InputFocusDirective,
    // LanguageRepeaterComponent,
    // LanguagesEditComponent,
    // LanguagesOverviewComponent,
    // LegalIssuesEditComponent,
    // LegalIssuesOverviewComponent,
    // LicenseRepeaterComponent,
    // ListingComponent,
    LoginComponent,
    // LogoutComponent,
    // MilitaryOverviewComponent,
    // MilitaryTrainingEditComponent,
    // ModifiedStampComponent,
    // NumericalInputComponent,
    // PageNotFoundComponent,
    // ParticipantSummaryComponent,
    // PhoneNumberInputComponent,
    // PhoneNumberPipe,
    // PostSecondaryEducationEditComponent,
    // PostSecondaryEducationOverviewComponent,
    // RadioButtonComponent,
    // ReleaseNotesComponent,
    // RemoteAutoCompleteComponent,
    // RemoteAutoSuggestComponent,
    // SelectComponent,
    StartComponent,
    // SubHeaderComponent,
    // SubHeaderNavComponent,
    // TabSelectorComponent,
    // TestScoresEmbedComponent,
    // TextAreaComponent,
    // Under12ChildAgeRepeaterComponent,
    // ValidationSummaryComponent,
    // WorkHistoryCurrentWageComponent,
    // WorkHistoryEditComponent,
    // WorkHistoryGatepostEditComponent,
    // WorkHistoryLeaveHistoryComponent,
    // WorkHistoryListComponent,
    // WorkHistoryListPageComponent,
    // WorkHistoryOverviewComponent,
    // WorkHistoryPastWageComponent,
    // WorkHistoryWageHistoryComponent,
    // WorkProgramRepeaterComponent,
    // WorkProgramsEditComponent,
    // WorkProgramsOverviewComponent,
    // YesNoBasicComponent,
    // YesNoComponent,
    // YesNoPipe,
    LoginDialogComponent,
    ModalPlaceholderComponent,
    MultiSelectDropdownComponent,
    // MoneyMaskDirective,
    // WorkHistorySingleComponent,
    // WorkHistoryEmbedComponent,
    // TextInputComponent,
    // DropdownComponent,
    // DateMmYyyyComponent,
    // ParticipantBarriersEditComponent,
    // YesNoRefuseComponent,
    // ParticipantBarriersEditComponentApp,
    // ParticipantBarriersEmbedComponent,
    // ParticipantBarriersListComponent,
    // ParticipantBarriersListPageComponent,
    // ParticipantBarriersSingleComponent,
    // BarriersAccommodationsRepeaterComponent,
    // BarriersFormalAssessmentRepeaterComponent,
    // DateMmDdYyyyNewComponent,
    // ContactsRepeaterComponent,
    // DropdownComponent,
    // MonthSelectorComponent,
    // TimeLimitsSummaryComponent,
    // ClockSummaryComponent,
    // TimelimitsTimelineComponent,
    // MonthDetailsComponent,
    // ClockSummaryDetailsComponent,
    // DefaultPipe,
    // EditExtensionComponent,
    // EditMonthComponent,
    // MonthBoxComponent,
    // ScrollDirective,
    // ExtensionListComponent,
    // RestrictedAccessDialogComponent,
    // SearchComponent,
    // ExtensionListPageComponent,
    // ExtensionDetailComponent,
    // ClockTypeNamePipe,
    // DateChangerComponent,
    // DateYyyyComponent,
    // NcpEditComponent,
    // NcpCaretakerRepeaterComponent,
    // NcpOverviewComponent,
    // UnauthorizedComponent,
    // NcpChildRepeaterComponent,
    // DeleteWarningComponent,
    // NcprChildRepeaterComponent,
    // NcprOtherParentRepeaterComponent,
    // NcprEditComponent,
    // NcprOverviewComponent,
    // HelpComponent,
    // TestScoresListComponent,
    // TestScoresEditComponent,
    // PageHelpComponent,
    // HelpNavComponent,
    // HelpPagesComponent,
    // TransportationEditComponent,
    // TransportationOverviewComponent,
    // DeleteReasonButtonComponent,
    // TestScoresListPageComponent,
    // TimeLimitExtensionsHelpComponent,
    // TimeLimitOverviewHelpComponent,
    // TestScoreCardComponent,
    // ParticipantBarriersOverviewComponent,
    // InputHistoryComponent,
    // ActionsNeededComponent,
    // ActionNeededEmbedComponent,
    // ActionNeededEditComponent,
    // ActionNeededListViewComponent,
    // ActionNeededTaskComponent,
    // DateMmDdYyyyPipe,
    // ActionNeededListPipe,
    // FilterComponent,
    // ActionNeededEmbedTaskComponent,
    // ArraySeparatorByCharPipe,
    // ParticipantCardComponent,
    LoginSimulationDialogComponent,
    // EnrollmentComponent,
    // DisenrollmentComponent,
    // EnrollmentHeaderComponent,
    // OnlyNumbersDirective,
    // ErrorModalComponent,
    // ReassignComponent,
    // ClearanceComponent,
    // CKButtonDirective,
    // CKEditorComponent,
    // CKGroupDirective,
    // CkEditableDirective,
    // TextContentModuleComponent,
    // ContentContainerModuleComponent,
    // ContentEditBarComponent,
    // TransferComponent,
    // RegistrationComponent,
    // AliasSsnRepeaterComponent,
    // RfaEditComponent,
    // CwwChildrenComponent,
    // CardHeaderComponent,
    // AppHistoryHeaderComponent,
    // SsnPipe,
    // WarningModalComponent,
    // DateMmYyyyPipe,
    // PadPipe,
    // RfaChildrenRepeaterComponent,
    // RfaPageComponent,
    // RfaListComponent,
    // RfaSingleComponent,
    // HighDatePipe,
    HighlightHoverDirective,
    // PepCardComponent,
    // ReportsComponent,
    // AliasRepeaterComponent,
    // RequestRestrictedAccessDialogComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    routing,
    MomentModule,
    Ng2DatetimePickerModule,
    Ng2PaginationModule,
    BrowserAnimationsModule,
    AngularFireModule.initializeApp(environment.firebase),
    // AngularFireDatabaseModule,
    NgxMaskModule.forRoot(),
    // DynamicModule.withComponents([
    //   ContentContainerModuleComponent,
    //   TextContentModuleComponent
    // ]),
    SimpleNotificationsModule.forRoot(),
    // LoggerModule.forRoot({
    //   serverLoggingUrl: environment.apiServer + 'api/log',
    //   level: NgxLoggerLevel.DEBUG,
    //   serverLogLevel: NgxLoggerLevel.ERROR
    // })
  ],
  providers: [
    LogServiceConfig,
    // [
    //   {
    //     provide: LogService,
    //     useClass: LogService,
    //     deps: [NgZone, LogServiceConfig]
    //   }
    // ],
    // { provide: ErrorHandler, useClass: AppErrorHandler },
    appRoutingProviders,
    ModalService,
    AppService,
    ParticipantService,
    UserPreferencesService,
    // TimeLimitsService,
    // ContentService,
    // SystemClockService,
    // WorkHistoryAppService,
    PadPipe,
    [{ provide: ValidationManager, deps: [AppService] }],
    {
        provide: HTTP_INTERCEPTORS,
        useClass: AuthHttpInterceptor,
        multi: true
    },
    // [
    //   {
    //   provide: AuthHttp,
    //   deps: [Http, RequestOptions, JwtAuthConfig],
    //   useFactory: authHttpFactory
    //   },
    // { provide: JwtAuthConfig, useFactory: jwtAuthConfigFactory }
    // ],
    [
      // {
      // provide: AuthHttpClient,
      // deps: [JwtAuthConfig, XHRBackend, RequestOptions, ModalService],
      // useFactory: httpFactory
      // },
      // { provide: NativeHttp, useClass: Http },
      // { provide: HttpClient, useExisting: ApplicationHttpClient },
      {
        provide: AuthHttpClient,        
        deps: [HttpClient]
      },
    ],
    { provide: HttpBackend, useClass: class {}},
    // , { provide: TINYMCE_SETTINGS_TOKEN, useValue: tinymceDefaultSettings }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [
    // ClockSummaryDetailsComponent,
    // DateChangerComponent,
    // HelpComponent,
    // InputHistoryComponent,
    // ActionNeededEditComponent,
    // DisenrollmentComponent,
    // EnrollmentComponent,
    // TimeLimitExtensionsHelpComponent,
    // TimeLimitOverviewHelpComponent,
    // ErrorModalComponent,
    LoginDialogComponent,
    LoginSimulationDialogComponent,
    // ReassignComponent,
    // RestrictedAccessDialogComponent,
    // RequestRestrictedAccessDialogComponent,
    // WarningModalComponent,
    // TransferComponent // so that Angular will create a component Factory for MdDialog to use
  ]
})
export class AppModule {}


// export function httpFactory(jwtAuthConfig: JwtAuthConfig, xhrBackend: XHRBackend, requestOptions: RequestOptions, modalService: ModalService) {
//   return new AuthHttpClient(jwtAuthConfig, xhrBackend, requestOptions, modalService);
// }
// export const JWTAuthProvider: Provider[] = [
//   {
//     provide: JwtAuthConfig, useFactory: () => {
//     new JwtAuthConfig(AuthConfigConsts.DEFAULT_TOKEN_NAME,
//     AuthConfigConsts.HEADER_PREFIX_BEARER,
//     AuthConfigConsts.DEFAULT_TOKEN_NAME,
//     () => localStorage.getItem(AuthConfigConsts.DEFAULT_TOKEN_NAME),
//     true,
//     new Array<Object>(),
//     false
//     ); }  }];
