/* tslint:disable:no-unused-variable */
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { By } from '@angular/platform-browser';
// import { DebugElement } from '@angular/core';

// import { CourtDatesRepeaterComponent } from './court-dates-repeater.component';

// describe('CourtDatesRepeaterComponent', () => {
//   let component: CourtDatesRepeaterComponent;
//   let fixture: ComponentFixture<CourtDatesRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ CourtDatesRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CourtDatesRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
