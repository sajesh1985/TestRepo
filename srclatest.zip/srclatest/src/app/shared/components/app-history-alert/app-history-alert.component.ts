import { Component, Input, DoCheck } from '@angular/core';

import { SectionError } from '../../models/section-error';
import { ValidationError } from '../../models/validation-error';

@Component({
  selector: 'app-history-alert',
  templateUrl: './app-history-alert.component.html',
  styleUrls: ['./app-history-alert.component.css']
})
export class AppHistoryAlertComponent {
  constructor() { }
}
