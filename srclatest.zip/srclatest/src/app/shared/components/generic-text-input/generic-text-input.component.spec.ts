/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { GenericTextInputComponent } from './generic-text-input.component';

// describe('Component: GenericTextInput', () => {
//   it('should create an instance', () => {
//     let component = new GenericTextInputComponent();
//     expect(component).toBeTruthy();
//   });
// });
