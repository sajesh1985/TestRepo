/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { RadioButtonComponent } from './radio-button.component';

// describe('Component: RadioButton', () => {
//   it('should create an instance', () => {
//     let component = new RadioButtonComponent();
//     expect(component).toBeTruthy();
//   });
// });
