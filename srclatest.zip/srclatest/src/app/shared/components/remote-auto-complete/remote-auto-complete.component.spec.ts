/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { RemoteAutoCompleteComponent } from './remote-auto-complete.component';

// describe('Component: RemoteAutoComplete', () => {
//   it('should create an instance', () => {
//     let component = new RemoteAutoCompleteComponent();
//     expect(component).toBeTruthy();
//   });
// });
