/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { YesNoBasicComponent } from './yes-no-basic.component';

// describe('Component: YesNoBasic', () => {
//   it('should create an instance', () => {
//     let component = new YesNoBasicComponent();
//     expect(component).toBeTruthy();
//   });
// });
