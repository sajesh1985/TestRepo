/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { PageNotFoundComponent } from './page-not-found.component';

// describe('Component: PageNotFound', () => {
//   it('should create an instance', () => {
//     let component = new PageNotFoundComponent();
//     expect(component).toBeTruthy();
//   });
// });
