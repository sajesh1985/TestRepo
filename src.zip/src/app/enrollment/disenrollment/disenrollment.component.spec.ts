// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DisenrollmentComponent } from './disenrollment.component';

// describe('DisenrollmentComponent', () => {
//   let component: DisenrollmentComponent;
//   let fixture: ComponentFixture<DisenrollmentComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DisenrollmentComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DisenrollmentComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
