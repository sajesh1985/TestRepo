import { ActivatedRoute, Router } from '@angular/router';
import { Component, EventEmitter, Output, Input, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable, forkJoin, of } from 'rxjs';

import { AppService } from '../../shared/services/app.service';
import { Authorization } from '../../shared/models/authorization';
import { BaseParticipantComponent } from '../../shared/components/base-participant-component';
import { DropDownField } from '../../shared/models/dropdown-field';
import { GoogleApiService } from '../../shared/services/google-api.service';
import { GoogleApi } from '../../shared/models/google-api';
import { FieldDataService } from '../../shared/services/field-data.service';
import { ParticipantService } from '../../shared/services/participant.service';
import { UIKitUtilities } from '../../shared/ui-kit.utilities';
import { ValidationManager } from '../../shared/models/validation-manager';
import { ModelErrors } from '../../shared/interfaces/model-errors';
import { MciParticipantSearch } from '../../shared/models/mciParticipantSearch.model';
import { Participant } from '../../shared/models/participant';

import { Address } from '../../shared/models/address.model';
import { Person } from '../../shared/models/person.model';
import { Phone } from '../../shared/models/phone.model';
import { ClientRegistration, RaceEthnicity } from '../../shared/models/client-registration.model';
import { MciParticipantReturn } from '../../shared/models/mciParticipantReturn.model';
import { ClientRegistrationService } from '../../shared/services/client-registration.service';
import { Status } from '../../shared/models/status.model';
import { Utilities } from '../../shared/utilities';
import { GoogleLocation } from '../../shared/models/google-location';
import { PadPipe } from '../../shared/pipes/pad.pipe';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
  providers: [FieldDataService, GoogleApiService, ClientRegistrationService]
})
export class RegistrationComponent extends BaseParticipantComponent implements OnInit, OnDestroy {
  Auth = Authorization;
  @Output()
  saveAndExitAndStatus = new EventEmitter<Status>();
  @Input()
  regId = 0;
  @Input()
  mciParticipantSearchModel: MciParticipantSearch;
  @Input()
  selectedMciParticipant: MciParticipantReturn;

  private countiesSub: Subscription;
  private countriesSub: Subscription;
  private suffixTypesSub: Subscription;
  private aliasTypesSub: Subscription;
  private langSub: Subscription;
  private tribeSub: Subscription;
  private ssnSub: Subscription;
  public genderDrop: DropDownField[];
  public aliasTypesDrop: DropDownField[];
  public aliasTypesDropNameAsId: DropDownField[];
  public suffixTypesDrop: DropDownField[];
  public suffixTypesDropNameAsId: DropDownField[];
  public countiesDrop: DropDownField[];
  public countriesDrop: DropDownField[];
  public languagesDrop: DropDownField[];
  public ssnTypesDrop: DropDownField[];
  public tribeDrop: DropDownField[];
  public hispanicDropdowns: DropDownField[];
  public isCollapsed = false;
  // public isLoaded = false;
  public hadSaveError = false;
  public isSaving = false;
  private hasTriedSave = false;
  private isSectionModified = false;
  public validationManager: ValidationManager = new ValidationManager(this.appService);
  public modelErrors: ModelErrors = {};
  public model: ClientRegistration;
  public originalModel: ClientRegistration;
  public isEthnicityAndRaceReadOnly = true;
  public isPinConfidentialReadOnly = false;
  public isPersonInformationReadOnly = true;
  public isAliasReadOnly = true;
  public englishId: number;
  public otherId: number;
  public isSectionValid: boolean;
  public householdAddressName = 'householdAddress';
  public mailingAddressName = 'mailingAddress';
  private fieldDataLoaded = false;
  public savingStatus: Status;
  private ggZipSub: Subscription;
  public pin;
  public isEditDemographicsMode = false;
  public isReadOnly = false;

  constructor(
    private googleApiService: GoogleApiService,
    public appService: AppService,
    private fdService: FieldDataService,
    private padPipe: PadPipe,
    route: ActivatedRoute,
    router: Router,
    partService: ParticipantService,
    private clientRegistrationService: ClientRegistrationService
  ) {
    super(route, router, partService);
  }

  get isLoaded() {
    return this.participant != null && this.model != null && this.fieldDataLoaded === true;
  }

  ngOnInit() {
    this.initHispanicDropdowns();
    this.genderDrop = this.initGenderDrop();

    // Load field data first because we need it when make search fields to our model.
    forkJoin(
      this.fdService.getSuffixTypes().take(1),
      this.fdService.getAliasTypes().take(1),
      this.fdService.getSsnTypes().take(1),
      this.fdService.getCounties('numeric').take(1),
      this.fdService.getCountries().take(1),
      this.fdService.getLanguages().take(1),
      this.fdService.getTribeNames().take(1)
    )
    .take(1)
    .subscribe(results => {
      this.initSuffixTypesDrop(results[0]);
      this.initAliasTypesDrop(results[1]);
      this.initSsnTypesDrop(results[2]);
      this.initWiCountiesDrop(results[3]);
      this.initCountriesDrop(results[4]);
      this.initLanguagesDrop(results[5]);
      this.initTribeDrop(results[6]);

      this.fieldDataLoaded = true;

      this.route.params.subscribe(params => {
        if (params['pin']) {
          this.pin = params['pin'];
          this.isEditDemographicsMode = true;
        }
      });

      if (this.pin != null) {
        this.selectedMciParticipant = new MciParticipantReturn();
      }

      if (this.selectedMciParticipant != null) {
        if (this.selectedMciParticipant.mciId != null) {
          // We have a participant in MCI.
          this.loadModel();
        } else if (this.pin != null) {
          this.getMciIdFromPin();
        } else {
          // Map what was entered on the clearance to client reg.
          this.createNewModelAndParticipant();
          this.mapMciToModel();
          this.originalModel = new ClientRegistration();
          ClientRegistration.clone(this.model, this.originalModel);
        }
      }
    });
  }

  onPartipantInit() {
    // If the participant is enrolled/referred in TMJ/TJ/CF Race and Ethnicity are editable.
    if (this.participant.enrolledTmjProgram != null || this.participant.enrolledTJProgram != null || this.participant.enrolledCFProgram != null) {
      this.isEthnicityAndRaceReadOnly = false;
      this.isPersonInformationReadOnly = false;
      this.isAliasReadOnly = false;
    } else if (this.participant.referredTmjProgram != null || this.participant.referredTJProgram != null || this.participant.referredCFProgram != null) {
      this.isEthnicityAndRaceReadOnly = false;
      this.isPersonInformationReadOnly = false;
      this.isAliasReadOnly = false;
    }
  }

  scroll(selector: string) {
    UIKitUtilities.scrollIntoView(selector);
  }

  private initHispanicDropdowns() {
    this.hispanicDropdowns = [];
    const d1 = new DropDownField();
    d1.name = 'Hispanic or Latino';
    d1.id = true;
    this.hispanicDropdowns.push(d1);

    const d2 = new DropDownField();
    d2.name = 'Not Hispanic or Latino';
    d2.id = false;
    this.hispanicDropdowns.push(d2);
  }

  loadModel() {
    this.clientRegistrationService.getClientRegistration(this.selectedMciParticipant).subscribe(data => this.initModel(data));
  }

  getMciIdFromPin() {
    this.partSub = this.partService.getCachedParticipant(this.pin).subscribe(p => {
      this.initParticipant(p);
      this.onPartipantInit();
      if (p.mciId) {
        this.selectedMciParticipant.mciId = p.mciId;
        this.loadModel();
      }
      return of(true);
    });
  }

  // For new participants not known to CWW or WWP.
  createNewModelAndParticipant() {
    this.model = new ClientRegistration();
    this.model.raceEthnicity.historySequenceNumber = 1;
    this.participant = new Participant();
  }

  initModel(data: ClientRegistration) {
    if (data == null && data.mciId != null) {
      this.mapMciToModel();
    } else {
      this.model = data;
      // We cant get pin from url, so we get it from our response here.
      if (data.pinNumber != null && this.partSub == null) {
        // this.emitPin.emit(data.pinNumber);
        this.partSub = this.partService.getParticipant(data.pinNumber.toString()).subscribe(part => {
          this.initParticipant(part);
          this.onPartipantInit();
        });
      } else if (this.pin == null) {
        // We dont have the pin if the participant isn't known to CWW Or WWP.
        this.createNewModelAndParticipant();
      }

      this.mapMciToModel(); // might get removed for when we dont get to client reg from clear screen
    }

    // We should have a model at this point.
    this.originalModel = new ClientRegistration();
    ClientRegistration.clone(this.model, this.originalModel);

    // Determine if the screen is read only if we are in edit demo mode.
    if (this.isEditDemographicsMode) {
      if (this.appService.isUserAuthorizedToEditClientReg(this.participant, this.isEditDemographicsMode)) {
        this.isReadOnly = false;
      } else if (this.appService.isUserAuthorizedToViewClientReg(this.participant)) {
        this.isReadOnly = true;
        this.isEthnicityAndRaceReadOnly = true;
        this.isAliasReadOnly = true;
        this.isPersonInformationReadOnly = true;
        this.isPinConfidentialReadOnly = true;
      }
    }
  }

  validate() {
    this.isSectionModified = true;
    if (this.hasTriedSave === true) {
      this.validationManager.resetErrors();

      // Call the model's validate method.
      const result = this.model.validate(this.validationManager, this.englishId, this.isPinConfidentialReadOnly, AppService.currentDate.format('MM/DD/YYYY'));

      this.isSectionValid = result.isValid;
      this.modelErrors = result.errors;

      if (this.isSectionValid === true) {
        this.hasTriedSave = false;
      }
    }
  }

  // When address changes we want to set the zipcode and address placeId.
  // The placeId here is from the street address call.
  addressChange(placeId: string, prop: string) {
    if (prop === this.householdAddressName) {
      this.model.householdAddress.addressPlaceId = placeId;
    } else if (prop === this.mailingAddressName) {
      this.model.mailingAddress.addressPlaceId = placeId;
    }

    this.autoPopulateZipcode(placeId, prop);
  }

  autoPopulateZipcode(placeId: string, prop: string) {
    this.ggZipSub = this.googleApiService.getZipCodeByPlaceId(placeId).subscribe(data => this.initZipCode(data, prop));
  }

  initZipCode(data: GoogleApi, prop: string) {
    if (prop === this.householdAddressName) {
      this.model.householdAddress.zipAddress = data.address.postalCode;
    } else if (prop === this.mailingAddressName) {
      this.model.mailingAddress.zipAddress = data.address.postalCode;
    }
    this.validate();
  }

  sidebarToggle() {
    this.isCollapsed = !this.isCollapsed;
    return this.isCollapsed;
  }

  saveAndExit() {
    this.hasTriedSave = true;
    this.savingStatus = null;
    this.validate();
    if (this.isSectionValid) {
      this.isSaving = true;
      const postModel = new ClientRegistration();
      ClientRegistration.clone(this.model, postModel);
      postModel.cleanseForPost(this.suffixTypesDrop);
      this.clientRegistrationService.saveClientRegistration(postModel).subscribe(
        data => {
          this.savingStatus = data;
          this.isSaving = false;
          // Stay on client reg when errored.
          if (this.savingStatus.errorMessages == null || this.savingStatus.errorMessages.length === 0) {
            this.saveAndExitAndStatus.emit(this.savingStatus);
          }
        },
        error => {
          this.savingStatus = null;
          this.isSaving = false;
          this.hadSaveError = true;
        }
      );
    }
  }

  exitRegistration() {
    if (this.isSectionModified === true) {
      this.appService.isDialogPresent = true;
    } else {
      this.saveAndExitAndStatus.emit(this.savingStatus);
    }
  }

  exitRegistrationIgnoreChanges($event) {
    if (this.isEditDemographicsMode) {
      // This is a non-normal situation when we are in this mode.
      // The super modal is normally shown over an existing route but
      // so the parent component would be listening for this event.  In
      // this case we don't have one so we will re-direct to the Participant
      // Summary.
      this.router.navigateByUrl(`/pin/${this.pin}`);
    } else {
      this.saveAndExitAndStatus.emit($event);
    }
  }

  ngOnDestroy() {
    // TODO: Find the Angular way!
    // let body = document.getElementsByTagName('body')[0];
    // body.classList.remove('noscroll');
    if (this.suffixTypesSub != null) {
      this.suffixTypesSub.unsubscribe();
    }
    if (this.aliasTypesSub != null) {
      this.aliasTypesSub.unsubscribe();
    }
    if (this.countiesSub != null) {
      this.countiesSub.unsubscribe();
    }
    if (this.langSub != null) {
      this.langSub.unsubscribe();
    }
    if (this.tribeSub != null) {
      this.tribeSub.unsubscribe();
    }
    if (this.ssnSub != null) {
      this.ssnSub.unsubscribe();
    }
    if (this.countriesSub != null) {
      this.countriesSub.unsubscribe();
    }
    if (this.ggZipSub != null) {
      this.ggZipSub.unsubscribe();
    }
  }

  initGenderDrop(): DropDownField[] {
    const drop = new Array<DropDownField>();
    const m = new DropDownField();
    m.id = 'M';
    m.name = 'Male';
    drop.push(m);
    const f = new DropDownField();
    f.id = 'F';
    f.name = 'Female';
    drop.push(f);
    return drop;
  }

  private initSuffixTypesDrop(data) {
    this.suffixTypesDrop = data;
    this.suffixTypesDropNameAsId = Utilities.createDropDownWithIdAsName(data);
  }

  private initAliasTypesDrop(data) {
    this.aliasTypesDrop = data;
    this.aliasTypesDropNameAsId = Utilities.createDropDownWithIdAsName(data);
  }

  private initSsnTypesDrop(data) {
    this.ssnTypesDrop = data;
  }

  private initWiCountiesDrop(data) {
    this.countiesDrop = data;
  }

  private initCountriesDrop(data) {
    this.countriesDrop = data;
  }

  private initLanguagesDrop(data) {
    this.englishId = Utilities.idByFieldDataName('English', data);
    this.languagesDrop = data;
  }

  private initTribeDrop(data) {
    this.otherId = Utilities.idByFieldDataName('Other', data);
    this.tribeDrop = data;
  }

  private getSuffixIdByName(suffix: string): number {
    if (Utilities.isStringEmptyOrNull(suffix)) {
      return 0;
    }

    if (this.suffixTypesDrop != null) {
      for (const s of this.suffixTypesDrop) {
        if (s.name.trim().toLocaleLowerCase() === suffix.trim().toLocaleLowerCase()) {
          return s.id;
        }
      }
    }
  }

  mapMciToModel() {
    if (this.mciParticipantSearchModel != null) {
      if (this.model == null) {
        this.model = new ClientRegistration();
        this.model.name = new Person();
      }

      this.model.name.firstName = this.selectedMciParticipant.name.firstName;
      this.model.name.middleInitial = this.selectedMciParticipant.name.middleInitial;
      this.model.name.lastName = this.selectedMciParticipant.name.lastName;
      this.model.name.suffixTypeId = this.getSuffixIdByName(this.selectedMciParticipant.name.suffix);
      this.model.dateOfBirthMmDdYyyy = this.selectedMciParticipant.dateOfBirthMmDdYyyy;

      // A zero from mci search means no ssn.
      if (this.selectedMciParticipant.ssn != null && this.selectedMciParticipant.ssn.length > 1) {
        if (this.selectedMciParticipant.ssn.length < 9) {
          this.selectedMciParticipant.ssn = this.padPipe.transform(this.selectedMciParticipant.ssn, 9);
        }
        this.model.ssn = this.selectedMciParticipant.ssn;
      } else if ((this.selectedMciParticipant.ssn != null && this.selectedMciParticipant.ssn.length === 1) || this.selectedMciParticipant.isNoSsn) {
        this.model.isNoSsn = true;
      }

      this.model.genderIndicator = this.selectedMciParticipant.gender;

      // Comes from return but we wont have it for new participants.
      this.model.mciId = this.selectedMciParticipant.mciId;

      this.model.ssnVerificationCode = this.selectedMciParticipant.ssnVerificationCode;
      this.model.ssnVerificationCodeDescription = this.selectedMciParticipant.ssnVerificationCodeDescription;
    }
  }
}
