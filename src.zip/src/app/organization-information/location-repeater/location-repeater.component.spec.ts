import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationRepeaterComponent } from './location-repeater.component';

describe('LocationRepeaterComponent', () => {
  let component: LocationRepeaterComponent;
  let fixture: ComponentFixture<LocationRepeaterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocationRepeaterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationRepeaterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
