import { Component, OnInit, OnChanges, forwardRef, Input } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { BaseRepeaterComponent } from '../../shared/components/base-repeater-component';
import { FinalistLocation } from '../../shared/models/organization-information.model';

@Component({
  selector: 'app-location-repeater',
  templateUrl: './location-repeater.component.html',
  styleUrls: ['./location-repeater.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => LocationRepeaterComponent),
      multi: true
    }
  ]
})
export class LocationRepeaterComponent extends BaseRepeaterComponent<FinalistLocation> implements ControlValueAccessor {
  @Input() isReadOnly = false;
  @Input() model: FinalistLocation;
  constructor() {
    super(FinalistLocation.create);
  }

  // ngOnInit() {}
}
