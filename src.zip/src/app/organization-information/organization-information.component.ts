// tslint:disable: import-blacklist
import { Component, OnInit } from '@angular/core';
import { DropDownField } from '../shared/models/dropdown-field';
import { FieldDataService } from '../shared/services/field-data.service';
import { OrganizationInformation, FinalistLocation } from '../shared/models/organization-information.model';
import { ModelErrors } from '../shared/interfaces/model-errors';
import { Router } from '@angular/router';
import { OrganizationInformationService } from '../shared/services/organization-information.service';

@Component({
  selector: 'app-organization-information',
  templateUrl: './organization-information.component.html',
  styleUrls: ['./organization-information.component.scss']
})
export class OrganizationInformationComponent implements OnInit {
  public isLoaded = false;
  public programId: number;
  public cachedProgramId: number;
  public organizationId: number;
  public cachedOrganizationId: number;
  public programDrop: DropDownField[] = [];
  public orgDrop: DropDownField[] = [];
  public model: OrganizationInformation;
  public cachedModel: OrganizationInformation = new OrganizationInformation();
  public modelErrors: ModelErrors = {};
  public isReadOnly = false;
  public goBackUrl: string;

  constructor(private oiService: OrganizationInformationService, private fdService: FieldDataService, private router: Router) {}

  ngOnInit() {
    this.goBackUrl = `/home`;

    this.fdService.getAllRfaPrograms().subscribe(result => {
      this.initProgramsDrop(result);
    });
  }

  initModel(): void {
    if (this.programId && this.organizationId) {
      this.oiService.getOrganizationInformation(this.programId, this.organizationId).subscribe(result => {
        this.model = result;

        if (this.model !== null) {
          OrganizationInformation.clone(this.model, this.cachedModel);
          this.isLoaded = true;
        } else {
          this.newModel();
          this.model.locations = [];
          OrganizationInformation.clone(this.model, this.cachedModel);
          this.isLoaded = true;
        }
      });
    }
  }

  newModel() {
    const model = new OrganizationInformation();
    model.id = 0;
    model.locations = [];
    this.model = model;
  }

  private initProgramsDrop(data): void {
    this.cachedProgramId = null;
    this.cachedOrganizationId = null;
    this.programDrop = data.filter(p => p.code !== 'FCD');
  }

  initOrganization(programId): void {
    if (this.programId)
      this.fdService.getOrganizationsByProgram(programId).subscribe(res => {
        this.orgDrop = res;
      });
    else this.orgDrop = [];
  }

  cancel() {
    this.router.navigateByUrl(this.goBackUrl);
  }
}
