// tslint:disable: import-blacklist
import { Component } from '@angular/core';
import { Router, ActivationEnd } from '@angular/router';
import { AppService } from 'src/app/core/services/app.service';
import { PinCommentsService } from '../shared/services/pin-comments.service';
import { forkJoin, of } from 'rxjs';
import * as moment from 'moment';
import { take, concatMap } from 'rxjs/operators';

@Component({
  selector: 'app-pin-comments',
  templateUrl: './pin-comments.component.html',
  styleUrls: ['./pin-comments.component.scss']
})
export class PinCommentsComponent {
  public participantPin: string;
  public isPinBased = false;
  public isInEditMode = false;
  public isPinCommentsPage = false;
  public pinCommentId: number;
  public showPinCommentsFeature = false;

  constructor(private router: Router, public appService: AppService, public pinCommentsService: PinCommentsService) {
    this.router.events.subscribe(val => {
      if (val instanceof ActivationEnd) {
        // Everytime the router changes, lets clear pin.
        this.participantPin = '';
        this.pinCommentsService.participantPin = this.participantPin;
        this.isPinBased = false;
        this.participantPin = val.snapshot.params['pin'];
        if (this.participantPin != null) {
          this.pinCommentsService.participantPin = this.participantPin;
          this.isPinBased = true;
        }

        if (val.snapshot.routeConfig.path === 'pin/:pin/pin-comments') {
          this.isPinCommentsPage = true;
        } else {
          this.isPinCommentsPage = false;
        }
      }

      if (this.participantPin && this.participantPin.trim() !== '' && !this.isPinCommentsPage) this.onInit();
    });
  }

  onInit() {
    const feature = 'PinComments';
    forkJoin(this.pinCommentsService.modeForPinComment.pipe(take(1)), this.appService.featureToggles.pipe(take(1)))
      .pipe(
        take(1),
        concatMap(results => {
          this.pinCommentId = results[0].id;
          this.isInEditMode = results[0].isInEditMode;

          if (results[1] && results[1].length > 0) {
            this.showPinCommentsFeature = this.appService.getFeatureToggleDate(feature);
            return of(null);
          } else return this.appService.getFeatureToggleValues();
        })
      )
      .subscribe(res => {
        if (res) {
          const featureToggleDate = res.filter(i => i.parameterName === feature)[0].parameterValue;
          this.showPinCommentsFeature = moment().isSameOrAfter(moment(featureToggleDate));
          this.appService.featureToggles.next(res);
        }
      });
  }

  onAdd() {
    this.isInEditMode = true;
    this.pinCommentId = 0;
    this.pinCommentsService.modeForPinComment.next({ id: 0, readOnly: false, isInEditMode: this.isInEditMode });
  }

  closeEdit(e: boolean) {
    this.isInEditMode = e;
  }
}
