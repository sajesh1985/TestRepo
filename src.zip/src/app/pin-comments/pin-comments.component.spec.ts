import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PinCommentsComponent } from './pin-comments.component';

describe('PinCommentsComponent', () => {
  let component: PinCommentsComponent;
  let fixture: ComponentFixture<PinCommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PinCommentsComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PinCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
