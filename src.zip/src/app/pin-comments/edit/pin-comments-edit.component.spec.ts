import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PinCommentsEditComponent } from './pin-comments-edit.component';

describe('PinCommentsEditComponent', () => {
  let component: PinCommentsEditComponent;
  let fixture: ComponentFixture<PinCommentsEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PinCommentsEditComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PinCommentsEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
