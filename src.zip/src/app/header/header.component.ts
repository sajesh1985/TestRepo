import { Component, ComponentRef, HostListener, OnInit, ElementRef, OnDestroy } from '@angular/core';
import { LoginSimulationDialogComponent } from '../shared/components/login-simulation-dialog/login-simulation-dialog.component';
import { ModalService } from '../shared/modal';
import { Router, ActivatedRoute, Params, ActivationEnd } from '@angular/router';
import { Subscription } from 'rxjs';

import { AppService } from '../shared/services/app.service';
// import { AuthHttpClient } from '../shared/AuthHttpClient';
import { ApplicationHttpClient } from '../shared/AppAuthHttpClient';
import { Authorization } from '../shared/models/authorization';
import { version, build } from '../shared/version';
import { Utilities } from '../shared/utilities';

declare var $: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  public isWorkerToolsSubMenuDisplayed = false;
  public isCaseManagementSubMenuDisplayed = false;
  public isUserAccountSubMenuDisplayed = false;
  public ver: string;
  public isPinBased = false;
  public logoPath = 'assets/img/logo.png';

  private routeSub: Subscription;
  get canSimulateUsers(): boolean {
    return this.appService.isUserAuthorized(Authorization.canSimulateLogins, null);
  }

  get isSimulatingUser(): boolean {
    return this.appService.isUserSimulated;
  }
  public participantPin: string;

  private tempModalRef: ComponentRef<LoginSimulationDialogComponent>;

  constructor(
    public appService: AppService,
    private router: Router,
    private authHttpClient: ApplicationHttpClient,
    private activatedRoute: ActivatedRoute,
    private modalService: ModalService,
    private eRef: ElementRef
  ) {
    this.ver = version.toString();

    // If we're including a build, then add it.
    if (build.length > 0) {
      this.ver = `${this.ver} (${build})`;
    }

    router.events.subscribe(val => {
      if (val instanceof ActivationEnd) {
        // Everytime the router changes, lets clear pin.
        this.participantPin = '';
        this.isPinBased = false;
        this.participantPin = val.snapshot.params['pin'];
        if (this.participantPin != null) {
          this.isPinBased = true;
        }
        this.closeSubMenu();
      }
    });
  }

  ngOnInit() {
    // TODO: Figure out why we cant use ActivatedRoute to query params on first load.
    let str = this.router.url.substring(this.router.url.indexOf('/pin/') + 5);
    if (!+str) {
      str = str.split('/')[0];
    }
    if (!Utilities.isStringEmptyOrNull(str)) {
      this.participantPin = str;
      this.isPinBased = true;
    }
  }

  @HostListener('document: click', ['$event.target'])
  onClick(target: HTMLElement) {
    if (this.eRef.nativeElement.contains(target)) {
      // Nothing for inside click.
    } else {
      this.closeSubMenu();
    }
  }

  navigateByPage(page: string) {
    this.router.navigateByUrl('pin/' + this.participantPin + '/' + page);
    this.closeSubMenu();
  }

  goHome() {
    this.router.navigateByUrl('/home');
  }

  get isCaseManagementDisplayed() {
    return this.isPinBased;
  }

  clickWorkerTools() {
    this.isWorkerToolsSubMenuDisplayed = !this.isWorkerToolsSubMenuDisplayed;
    this.isCaseManagementSubMenuDisplayed = false;
    this.isUserAccountSubMenuDisplayed = false;
  }

  clickCaseManagement() {
    this.isCaseManagementSubMenuDisplayed = !this.isCaseManagementSubMenuDisplayed;
    this.isWorkerToolsSubMenuDisplayed = false;
    this.isUserAccountSubMenuDisplayed = false;
  }

  clickUserAccount() {
    this.isUserAccountSubMenuDisplayed = !this.isUserAccountSubMenuDisplayed;
    this.isWorkerToolsSubMenuDisplayed = false;
    this.isCaseManagementSubMenuDisplayed = false;
  }

  navigateTo(page: string) {
    switch (page) {
      case 'home': {
        this.router.navigateByUrl('/home');
        break;
      }
      case 'participant-summary': {
        this.router.navigateByUrl('/pin/' + this.participantPin);
        break;
      }
      case 'clearance': {
        this.router.navigateByUrl('/clearance');
        break;
      }
      // case 'help': {
      //   this.router.navigateByUrl('/help');
      //   break;
      // }
      case 'release-notes': {
        this.router.navigateByUrl('/release-notes');
        break;
      }
      case 'logout': {
        this.router.navigateByUrl('/logout');
        break;
      }
      case 'reports': {
        this.router.navigateByUrl('/reports');
        break;
      }
      default: {
        break;
      }
    }
    this.closeSubMenu();
  }

  private closeSubMenu() {
    this.isWorkerToolsSubMenuDisplayed = false;
    this.isCaseManagementSubMenuDisplayed = false;
    this.isUserAccountSubMenuDisplayed = false;
  }

  showSimulateUserBox() {
    if (this.tempModalRef && this.tempModalRef.instance) {
      this.tempModalRef.instance.destroy();
    }
    this.modalService.create<LoginSimulationDialogComponent>(LoginSimulationDialogComponent).subscribe(x => {
      this.tempModalRef = x;
    });
  }

  cancelUserSimualtion() {
    this.appService.stopUserSimulation();
  }

  ngOnDestroy() {
    if (this.routeSub != null) {
      this.routeSub.unsubscribe();
    }
  }
}
