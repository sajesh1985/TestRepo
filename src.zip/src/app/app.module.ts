import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NgZone, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { Ng2DatetimePickerModule } from 'ng2-datetime-picker';
import { CoreModule } from './core/core.module';

import { AppComponent } from './app.component';
import { routing, appRoutingProviders } from './app.routing';

import { SimpleNotificationsModule } from 'angular2-notifications';

// tslint:disable-next-line:max-line-length
import { Between13And18ChildrenAgeRepeaterComponent } from './participant/informal-assessment/edit/between13-and18-children-age-repeater/between13-and18-children-age-repeater.component';
import { CaretakingRepeaterComponent } from './participant/informal-assessment/edit/caretaking-repeater/caretaking-repeater.component';
import { ChildYouthSupportsEditComponent } from './participant/informal-assessment/edit/child-youth-supports.component';
import { ChildYouthSupportsOverviewComponent } from './participant/informal-assessment/overview/child-youth-supports.component';
import { CollegeRepeaterComponent } from './participant/informal-assessment/edit/college-repeater/college-repeater.component';
import { ContactDetailComponent } from './contacts/detail/detail.component';
import { ContactsEditComponent } from './contacts/edit/edit.component';
import { ContactsEmbedComponent } from './contacts/embed/embed.component';
import { ContactsListComponent } from './contacts/list/list.component';
import { ContactsListPageComponent } from './contacts/list-page/list-page.component';
import { ContactsSelectComponent } from './contacts/select/select.component';
import { ConvictionRepeaterComponent } from './participant/informal-assessment/edit/conviction-repeater/conviction-repeater.component';
import { CourtDatesRepeaterComponent } from './participant/informal-assessment/edit/court-dates-repeater/court-dates-repeater.component';
import { HomePageComponent } from './home-page/home-page.component';
import { DegreeRepeaterComponent } from './participant/informal-assessment/edit/degree-repeater/degree-repeater.component';
import { EditComponent as InformalAssessmentEditComponent } from './participant/informal-assessment/edit/edit.component';
import { EducationHistoryEditComponent } from './participant/informal-assessment/edit/education-history.component';
import { EducationHistoryOverviewComponent } from './participant/informal-assessment/overview/education-history.component';
import { EducationTabComponent } from './participant/informal-assessment/edit/education-tab/education-tab.component';
import { FamilyBarriersEditComponent } from './participant/informal-assessment/edit/family-barriers.component';
import { FamilyBarriersOverviewComponent } from './participant/informal-assessment/overview/family-barriers.component';
import { HeaderComponent } from './header/header.component';
import { HousingEditComponent } from './participant/informal-assessment/edit/housing.component';
import { HousingOverviewComponent } from './participant/informal-assessment/overview/housing.component';
import { HousingRepeaterComponent } from './participant/informal-assessment/edit/housing-repeater/housing-repeater.component';
import { LanguageRepeaterComponent } from './participant/informal-assessment/edit/language-repeater/language-repeater.component';
import { LanguagesEditComponent } from './participant/informal-assessment/edit/languages.component';
import { LanguagesOverviewComponent } from './participant/informal-assessment/overview/languages.component';
import { LegalIssuesEditComponent } from './participant/informal-assessment/edit/legal-issues.component';
import { LegalIssuesOverviewComponent } from './participant/informal-assessment/overview/legal-issues.component';
import { LicenseRepeaterComponent } from './participant/informal-assessment/edit/license-repeater/license-repeater.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { MilitaryOverviewComponent } from './participant/informal-assessment/overview/military.component';
import { MilitaryTrainingEditComponent } from './participant/informal-assessment/edit/military-training.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PostSecondaryEducationEditComponent } from './participant/informal-assessment/edit/post-secondary-education.component';
import { PostSecondaryEducationOverviewComponent } from './participant/informal-assessment/overview/post-secondary-education.component';
import { TransportationOverviewComponent } from './participant/informal-assessment/overview/transportation.component';
import { ReleaseNotesComponent } from './release-notes/release-notes.component';
import { StartComponent } from './start/start.component';
// import { SubHeaderComponent } from './sub-header/sub-header.component';
// import { SubHeaderNavComponent } from './sub-header-nav/sub-header-nav.component';
import { SummaryComponent as InformalAssessmentSummaryComponent } from './participant/informal-assessment/summary/summary.component';
import { SummaryComponent as ParticipantSummaryComponent } from './participant/summary/summary.component';
//import { TestScoresEmbedComponent } from './test-scores/embed/embed.component';
import { Under12ChildAgeRepeaterComponent } from './participant/informal-assessment/edit/under12-child-age-repeater/under12-child-age-repeater.component';
import { WorkHistoryWageComponent } from './work-history/current-wage/current-wage.component';
import { WorkHistoryEditComponent } from './work-history/edit/edit.component';
import { WorkHistoryGatepostEditComponent } from './participant/informal-assessment/edit/work-history.component';
import { WorkHistoryLeaveHistoryComponent } from './work-history/leave-history/leave-history.component';
import { WorkHistoryListComponent } from './work-history/list/list.component';
import { WorkHistoryListPageComponent } from './work-history/list-page/list-page.component';
import { WorkHistoryOverviewComponent } from './participant/informal-assessment/overview/work-history.component';
import { WorkHistoryPastWageComponent } from './work-history/past-wage/past-wage.component';
import { WorkHistoryWageHistoryComponent } from './work-history/wage-history/wage-history.component';
import { WorkProgramRepeaterComponent } from './participant/informal-assessment/edit/work-program-repeater/work-program-repeater.component';
import { WorkProgramsEditComponent } from './participant/informal-assessment/edit/work-programs.component';
import { WorkProgramsOverviewComponent } from './participant/informal-assessment/overview/work-programs.component';
import { WorkHistorySingleComponent } from './work-history/single/single.component';
import { WorkHistoryEmbedComponent } from './work-history/embed/embed.component';
// import { DropdownComponent } from './shared/components/dropdown/dropdown.component';
// import { AppErrorHandler } from './error.handler';
import { ParticipantBarriersEditComponent } from './participant/informal-assessment/edit/participant-barriers.component';
import { ParticipantBarriersEditComponent as ParticipantBarriersEditComponentApp } from './participant-barriers/edit/edit.component';
import { ParticipantBarriersEmbedComponent } from './participant-barriers/embed/embed.component';
import { ParticipantBarriersListComponent } from './participant-barriers/list/list.component';
import { ParticipantBarriersListPageComponent } from './participant-barriers/list-page/list-page.component';
// import { Ng2PaginationModule } from 'ng2-pagination';
import { ParticipantBarriersSingleComponent } from './participant-barriers/single/single.component';
import { BarriersAccommodationsRepeaterComponent } from './participant-barriers/accommodations/accommodations.component';
import { BarriersFormalAssessmentRepeaterComponent } from './participant-barriers/formal-assessments/formal-assessments.component';
import { ContactsRepeaterComponent } from './contacts/repeater/repeater.component';
import { SummaryComponent as TimeLimitsSummaryComponent } from './time-limits/summary/summary.component';
import { ClockSummaryComponent } from './time-limits/summary/clock-summary.component';
import { TimelimitsTimelineComponent } from './time-limits/timeline/limits-timeline.component';
import { MonthDetailsComponent } from './time-limits/month-details/month-details.component';
import { ClockSummaryDetailsComponent } from './time-limits/clock-summary-details/clock-summary-details.component';
import { EditExtensionComponent } from './time-limits/extensions/edit/edit-extension.component';
import { MonthBoxComponent } from './time-limits/timeline/month-box/month-box.component';
import { EditMonthComponent } from './time-limits/edit/edit-month.component';
import { ValidationManager } from './shared/models/validation';
import { ExtensionListComponent } from './time-limits/extensions/list/list.component';
import { ExtensionListPageComponent } from './time-limits/extensions/list-page/list-page.component';
import { ExtensionDetailComponent } from './time-limits/extensions/detail/detail.component';
import { ClockTypeNamePipe } from './time-limits/pipes/clock-type-name.pipe';
import { SearchComponent } from './time-limits/search/search.component';
import { NcpEditComponent } from './participant/informal-assessment/edit/ncp.component';
import { NcpCaretakerRepeaterComponent } from './participant/informal-assessment/edit/ncp-caretaker-repeater/ncp-caretaker-repeater.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { NcpChildRepeaterComponent } from './participant/informal-assessment/edit/ncp-child-repeater/ncp-child-repeater.component';
import { NcpOverviewComponent } from './participant/informal-assessment/overview/ncp.component';
import { DeleteWarningComponent } from './time-limits/extensions/delete-warning/delete-warning.component';
import { NcprChildRepeaterComponent } from './participant/informal-assessment/edit/ncpr-child-repeater/ncpr-child-repeater.component';
import { NcprOtherParentRepeaterComponent } from './participant/informal-assessment/edit/ncpr-other-parent-repeater/ncpr-other-parent-repeater.component';
import { NcprEditComponent } from './participant/informal-assessment/edit/ncpr.component';
import { NcprOverviewComponent } from './participant/informal-assessment/overview/ncpr.component';
// import { TestScoresListComponent } from './test-scores/list/list.component';
// import { TestScoresEditComponent } from './test-scores/edit/edit.component';
import { PageHelpComponent } from './help/help.component';
import { HelpNavComponent } from './help/help-nav/help-nav.component';
import { TransportationEditComponent } from './participant/informal-assessment/edit/transportation.component';
// import { TestScoresListPageComponent } from './test-scores/list-page/list-page.component';
import { TimeLimitExtensionsHelpComponent } from './help/help-pages/tl-ext-decisions.component';
import { TimeLimitOverviewHelpComponent } from './help/help-pages/tl-overview.component';
//import { TestScoreCardComponent } from './test-scores/card/card.component';
import { ParticipantBarriersOverviewComponent } from './participant/informal-assessment/overview/participant-barriers.component';
// import { ActionsNeededComponent } from './actions-needed/actions-needed.component';
// import { ActionNeededEmbedComponent } from './actions-needed/embed/embed.component';
// import { ActionNeededEditComponent } from './actions-needed/edit/edit.component';
// import { ActionNeededListViewComponent } from './actions-needed/list-view/list-view.component';
// import { ActionNeededTaskComponent } from './actions-needed/task/task.component';
// import { ActionNeededListPipe } from './actions-needed/pipes/action-needed-list.pipe';
// // import { FilterComponent } from './shared/components/filter/filter.component';
// import { ActionNeededEmbedTaskComponent } from './actions-needed/embed/embed-task/embed-task.component';
// import { CKButtonDirective, CKEditorComponent, CKGroupDirective, CkEditableDirective } from './shared/components/ck-editor';
import { ParticipantCardComponent } from './home-page/participant-card/participant-card.component';
import { EnrollmentComponent } from './enrollment/enrollment/enrollment.component';
import { DisenrollmentComponent } from './enrollment/disenrollment/disenrollment.component';
import { EnrollmentHeaderComponent } from './enrollment/header/header.component';
// import { OnlyNumbersDirective } from './shared/directives/numbers-only.directive';
import { ReassignComponent } from './enrollment/reassign/reassign.component';
import { ClearanceComponent } from './clearance/clearance.component';
import { TransferComponent } from './enrollment/transfer/transfer.component';
import { RegistrationComponent } from './enrollment/registration/registration.component';
import { AliasSsnRepeaterComponent } from './enrollment/registration/alias-ssn-repeater/alias-ssn-repeater.component';
import { RfaEditComponent } from './rfa/edit/edit.component';
import { CwwChildrenComponent } from './participant/cww/cww-children/cww-children.component';
import { CardHeaderComponent } from './participant/informal-assessment/overview/card-header/card-header.component';
import { RfaChildrenRepeaterComponent } from './rfa/rfa-children-repeater/rfa-children-repeater.component';
import { RfaPageComponent } from './rfa/page/page.component';
import { RfaListComponent } from './rfa/list/list.component';
import { RfaSingleComponent } from './rfa/single/single.component';
// import { HighDatePipe } from './shared/pipes/high-date.pipe';
import { PepCardComponent } from './participant/summary/pep-card/pep-card.component';
import { ReportsComponent } from './webi/reports/reports.component';
import { AliasRepeaterComponent } from './clearance/alias-repeater/alias-repeater.component';
// import { ParticipationStatusListComponent } from './participation-statuses/list/list.component';
// import { ParticipationStatusEditComponent } from './participation-statuses/edit/edit.component';
// import { ParticipationStatusesListPageComponent } from './participation-statuses/list-page/list-page.component';
import { EmployabilityPlanOverviewComponent } from './employability-plan/ep-overview/employability-plan-overview/employability-plan-overview.component';
import { PrintComponent } from './work-history/print/print.component';
import { CareerAssessmentEditComponent } from './career-assessment/edit/edit.component';
import { CareerAssessmentListComponent } from './career-assessment/list/list.component';
import { CareerAssessmentComponent } from './career-assessment/career-assessment.component';
import { OrganizationInformationComponent } from './organization-information/organization-information.component';
import { LocationRepeaterComponent } from './organization-information/location-repeater/location-repeater.component';
import { PinCommentsComponent } from './pin-comments/pin-comments.component';
import { PinCommentsListComponent } from './pin-comments/list/pin-comments-list.component';
import { PinCommentsPageComponent } from './pin-comments/page/pin-comments-page/pin-comments-page.component';
import { PinCommentsEditComponent } from './pin-comments/edit/pin-comments-edit.component';
import { SupportiveServiceComponent } from './employability-plan/supportive-service/supportive-service.component';
import { EmploymentPlanComponent } from './employability-plan/employment-plan/employment-plan.component';
import { GoalsPageComponent } from './employability-plan/goals/page/page.component';
import { GoalStepRepeaterComponent } from './employability-plan/goals/goal-step-repeater/goal-step-repeater.component';
import { ServiceRepeaterComponent } from './employability-plan/supportive-service/service-repeater/service-repeater.component';
import { EpEmploymentsPageComponent } from './employability-plan/employments/page/page.component';
import { ElapsedActivitiesComponent } from './employability-plan/ep-overview/elapsed-activities/elapsed-activities.component';
import { ActivitiesPageComponent } from './employability-plan/activities/page/page.component';
import { EmployabilityPlanPageComponent } from './employability-plan/page/page.component';
import { HistoricalGoalsComponent } from './employability-plan/historical-goals/historical-goals.component';
import { HistoricalActivitiesComponent } from './employability-plan/historical-activities/historical-activities.component';
import { EndEmployabilityPlanComponent } from './employability-plan/end-employability-plan/end-employability-plan.component';
import { EmployabilityPlanDriverFlowComponent } from './employability-plan/driver-flow/driver-flow.component';
import { ActivitySingleComponent } from './employability-plan/activities/single/single.component';
import { ScheduleRepeaterComponent } from './employability-plan/activities/edit/schedule-repeater/schedule-repeater.component';
import { ActivitiesEditComponent } from './employability-plan/activities/edit/edit.component';
import { ActivitiesListComponent } from './employability-plan/activities/list/list.component';
import { EpEmploymentsListComponent } from './employability-plan/employments/list/list.component';
import { ActivityOverviewComponent } from './employability-plan/ep-overview/activity-overview/activity-overview.component';
import { EpEmploymentsOverviewComponent } from './employability-plan/ep-overview/employments-overview/employments-overview.component';
import { EpCardHeaderComponent } from './employability-plan/ep-overview/ep-card-header/ep-card-header.component';
import { GoalsOverviewComponent } from './employability-plan/ep-overview/goals-overview/goals-overview.component';
import { SupportiveServicesOverviewComponent } from './employability-plan/ep-overview/supportive-services-overview/supportive-services-overview.component';
import { EpOverviewComponent } from './employability-plan/ep-overview/ep-overview.component';
import { EmployabilityListComponent } from './employability-plan/list/list.component';
import { GoalsEditComponent } from './employability-plan/goals/edit/edit.component';
import { GoalsListComponent } from './employability-plan/goals/list/list.component';
import { AppService } from './core/services/app.service';
import { SharedModule } from './shared/shared.module';
import { LoginDialogComponent } from './shared/components/login-dialog/login-dialog.component';
import { NgxMaskModule } from 'ngx-mask';
import { ActionsNeededModule } from './features-modules/actions-needed/actions-needed.module';
import { ParticipationStatusModule } from './features-modules/participation-statuses/participation-statuses.module';
import { TestScoresModule } from './features-modules/test-scores/test-scores.module';

@NgModule({
  declarations: [
    ActivitiesPageComponent,
    ActivitySingleComponent,
    ActivitiesEditComponent,
    ActivitiesListComponent,
    ActivityOverviewComponent,
    AppComponent,
    Between13And18ChildrenAgeRepeaterComponent,
    CaretakingRepeaterComponent,
    ChildYouthSupportsEditComponent,
    ChildYouthSupportsOverviewComponent,
    CollegeRepeaterComponent,
    ContactDetailComponent,
    ContactsEditComponent,
    ContactsEmbedComponent,
    ContactsListComponent,
    ContactsListPageComponent,
    ContactsSelectComponent,
    ConvictionRepeaterComponent,
    CourtDatesRepeaterComponent,
    HomePageComponent,
    DegreeRepeaterComponent,
    EducationHistoryEditComponent,
    EducationHistoryOverviewComponent,
    EducationTabComponent,
    ElapsedActivitiesComponent,
    EmployabilityListComponent,
    EmploymentPlanComponent,
    EmployabilityPlanDriverFlowComponent,
    EmployabilityPlanOverviewComponent,
    EmployabilityPlanPageComponent,
    EpCardHeaderComponent,
    EpEmploymentsListComponent,
    EpEmploymentsPageComponent,
    EpEmploymentsOverviewComponent,
    EpOverviewComponent,
    EndEmployabilityPlanComponent,
    FamilyBarriersEditComponent,
    FamilyBarriersOverviewComponent,
    GoalsEditComponent,
    GoalsListComponent,
    GoalsOverviewComponent,
    GoalsPageComponent,
    GoalStepRepeaterComponent,
    HeaderComponent,
    HousingEditComponent,
    HousingOverviewComponent,
    HousingRepeaterComponent,
    HistoricalActivitiesComponent,
    HistoricalGoalsComponent,
    InformalAssessmentEditComponent,
    InformalAssessmentSummaryComponent,
    LanguageRepeaterComponent,
    LanguagesEditComponent,
    LanguagesOverviewComponent,
    LegalIssuesEditComponent,
    LegalIssuesOverviewComponent,
    LicenseRepeaterComponent,
    LoginComponent,
    LogoutComponent,
    LoginDialogComponent,
    MilitaryOverviewComponent,
    MilitaryTrainingEditComponent,
    PageNotFoundComponent,
    ParticipantSummaryComponent,
    PostSecondaryEducationEditComponent,
    PostSecondaryEducationOverviewComponent,
    ReleaseNotesComponent,
    ScheduleRepeaterComponent,
    ServiceRepeaterComponent,
    StartComponent,
    // SubHeaderComponent,
    // SubHeaderNavComponent,
    SupportiveServiceComponent,
    SupportiveServicesOverviewComponent,
    //TestScoresEmbedComponent,
    Under12ChildAgeRepeaterComponent,
    WorkHistoryWageComponent,
    WorkHistoryEditComponent,
    WorkHistoryGatepostEditComponent,
    WorkHistoryLeaveHistoryComponent,
    WorkHistoryListComponent,
    WorkHistoryListPageComponent,
    WorkHistoryOverviewComponent,
    WorkHistoryPastWageComponent,
    WorkHistoryWageHistoryComponent,
    WorkProgramRepeaterComponent,
    WorkProgramsEditComponent,
    WorkProgramsOverviewComponent,
    WorkHistorySingleComponent,
    WorkHistoryEmbedComponent,
    // DropdownComponent,
    ParticipantBarriersEditComponent,
    ParticipantBarriersEditComponentApp,
    ParticipantBarriersEmbedComponent,
    ParticipantBarriersListComponent,
    ParticipantBarriersListPageComponent,
    ParticipantBarriersSingleComponent,
    BarriersAccommodationsRepeaterComponent,
    BarriersFormalAssessmentRepeaterComponent,
    ContactsRepeaterComponent,
    // DropdownComponent,
    TimeLimitsSummaryComponent,
    ClockSummaryComponent,
    TimelimitsTimelineComponent,
    MonthDetailsComponent,
    ClockSummaryDetailsComponent,
    EditExtensionComponent,
    EditMonthComponent,
    MonthBoxComponent,
    ExtensionListComponent,
    SearchComponent,
    ExtensionListPageComponent,
    ExtensionDetailComponent,
    ClockTypeNamePipe,
    NcpEditComponent,
    NcpCaretakerRepeaterComponent,
    NcpOverviewComponent,
    UnauthorizedComponent,
    NcpChildRepeaterComponent,
    DeleteWarningComponent,
    NcprChildRepeaterComponent,
    NcprOtherParentRepeaterComponent,
    NcprEditComponent,
    NcprOverviewComponent,
    //TestScoresListComponent,
    //TestScoresEditComponent,
    PageHelpComponent,
    HelpNavComponent,
    TransportationEditComponent,
    TransportationOverviewComponent,
    //TestScoresListPageComponent,
    TimeLimitExtensionsHelpComponent,
    TimeLimitOverviewHelpComponent,
    //TestScoreCardComponent,
    ParticipantBarriersOverviewComponent,
    // ActionsNeededComponent,
    // ActionNeededEmbedComponent,
    // ActionNeededEditComponent,
    // ActionNeededListViewComponent,
    // ActionNeededTaskComponent,
    // ActionNeededListPipe,
    // // FilterComponent,
    // ActionNeededEmbedTaskComponent,
    ParticipantCardComponent,
    EnrollmentComponent,
    DisenrollmentComponent,
    EnrollmentHeaderComponent,
    ReassignComponent,
    ClearanceComponent,
    // CKButtonDirective,
    // CKEditorComponent,
    // CKGroupDirective,
    // CkEditableDirective,
    TransferComponent,
    RegistrationComponent,
    AliasSsnRepeaterComponent,
    RfaEditComponent,
    CwwChildrenComponent,
    CardHeaderComponent,
    RfaChildrenRepeaterComponent,
    RfaPageComponent,
    RfaListComponent,
    RfaSingleComponent,
    // HighDatePipe,
    PepCardComponent,
    ReportsComponent,
    AliasRepeaterComponent,
    // ParticipationStatusListComponent,
    // ParticipationStatusEditComponent,
    // ParticipationStatusesListPageComponent,
    PrintComponent,
    OrganizationInformationComponent,
    LocationRepeaterComponent,
    PinCommentsComponent,
    PinCommentsListComponent,
    PinCommentsPageComponent,
    PinCommentsEditComponent,
    CareerAssessmentComponent,
    CareerAssessmentListComponent,
    CareerAssessmentEditComponent
    // YesNoPipe
  ],
  imports: [
    BrowserModule,
    SharedModule.forRoot(),
    NgxMaskModule.forRoot(),
    CoreModule,
    routing,
    // Ng2DatetimePickerModule,
    // Ng2PaginationModule,
    BrowserAnimationsModule,
    SimpleNotificationsModule.forRoot(),
    ActionsNeededModule.forRoot(),
    ParticipationStatusModule,
    TestScoresModule.forRoot()
  ],
  providers: [appRoutingProviders, [{ provide: ValidationManager, deps: [AppService] }]],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [
    // ClockSummaryDetailsComponent,
    LoginDialogComponent,
    DisenrollmentComponent,
    EnrollmentComponent,
    TimeLimitExtensionsHelpComponent,
    TimeLimitOverviewHelpComponent,
    ReassignComponent,
    TransferComponent // so that Angular will create a component Factory for MdDialog to use
  ]
})
export class AppModule {}
