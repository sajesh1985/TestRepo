// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { NcpChildRepeaterComponent } from './ncp-child-repeater.component';

// describe('NcpChildRepeaterComponent', () => {
//   let component: NcpChildRepeaterComponent;
//   let fixture: ComponentFixture<NcpChildRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ NcpChildRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(NcpChildRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
