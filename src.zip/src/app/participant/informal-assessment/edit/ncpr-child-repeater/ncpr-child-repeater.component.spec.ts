// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { NcprChildRepeaterComponent } from './ncpr-child-repeater.component';

// describe('NcprChildRepeaterComponent', () => {
//   let component: NcprChildRepeaterComponent;
//   let fixture: ComponentFixture<NcprChildRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ NcprChildRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(NcprChildRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
