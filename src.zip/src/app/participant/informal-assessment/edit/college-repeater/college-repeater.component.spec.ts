/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { CollegeRepeaterComponent } from './college-repeater.component';

// describe('Component: CollegeRepeater', () => {
//   it('should create an instance', () => {
//     let component = new CollegeRepeaterComponent();
//     expect(component).toBeTruthy();
//   });
// });
