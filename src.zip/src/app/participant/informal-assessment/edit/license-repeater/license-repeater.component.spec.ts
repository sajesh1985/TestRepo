/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { LicenseRepeaterComponent } from './license-repeater.component';

// describe('Component: LicenseRepeater', () => {
//   it('should create an instance', () => {
//     let component = new LicenseRepeaterComponent();
//     expect(component).toBeTruthy();
//   });
// });
