// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { NcprOtherParentRepeaterComponent } from './ncpr-other-parent-repeater.component';

// describe('NcprOtherParentRepeaterComponent', () => {
//   let component: NcprOtherParentRepeaterComponent;
//   let fixture: ComponentFixture<NcprOtherParentRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ NcprOtherParentRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(NcprOtherParentRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
