import { Component, OnInit, Input } from '@angular/core';
import { EnrolledProgram } from '../../../shared/models/enrolled-program.model';

@Component({
  selector: 'app-pep-card',
  templateUrl: './pep-card.component.html',
  styleUrls: ['./pep-card.component.css']
})
export class PepCardComponent implements OnInit {

  @Input() enrolledProgram: EnrolledProgram;
  @Input() wpGeoArea: string;

  constructor() { }

  ngOnInit() {
  }

}
