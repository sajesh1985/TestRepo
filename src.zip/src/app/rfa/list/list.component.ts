import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { RFAProgram } from '../../shared/models/rfa.model';
import { RfaService } from '../../shared/services/rfa.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Utilities } from '../../shared/utilities';
import * as _ from 'lodash';
import { AccessType } from '../../shared/enums/access-type.enum';
import { AppService } from '../../shared/services/app.service';
import { Authorization } from '../../shared/models/authorization';

@Component({
  selector: 'app-rfa-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
  providers: [RfaService]
})
export class RfaListComponent implements OnInit {


  @Input() pin;

  @Input() isReadOnly = false;
  @Input() accessType: AccessType;
  AccessType = AccessType;

  public isInEdit = false;

  public programList: RFAProgram[] = [];

  public isSortByStatusToggled = true;

  public editId = 0;

  public isLoaded = false;

  private rSub: Subscription;
  constructor(public rfaService: RfaService, private router: Router, private appService: AppService) {
  }

  ngOnInit() {
    this.loadRfaList();
  }

  public onSearch() {
  }

  public sortByStatus() {
    this.programList.reverse();
    this.isSortByStatusToggled = !this.isSortByStatusToggled;
  }

  displayEdit(value: boolean, id = 0) {
    this.isInEdit = value;
    this.editId = id;
    // Reload list when we close the edit view.
    if (!value) {
      this.ngOnInit();
    }
  }

  goToSingleView(id: number): void {
    if (this.isInEdit) {
      return;
    }
    this.router.navigateByUrl(`/pin/${this.pin}/rfa/${id}`);
  }

  private loadRfaList() {
    this.isLoaded = false;
    this.rSub = this.rfaService.getRfasByPin(this.pin)
      .subscribe(rfas => {
        this.programList = this.sortRfaList(rfas);
        this.setAccessType();
        this.isLoaded = true;
      });
  }
  private setAccessType() {
    for (const program of this.programList) {
      if (this.appService.user.agencyCode === program.contractorCode  && this.appService.isUserAuthorized(Authorization[`canAccessProgram_${program.programCode.trim()}`])) {
        program.canEditRfa = true;
      }
    }
  }
  private sortRfaList(rfaPrograms: RFAProgram[]): RFAProgram[] {
    const sortOrder = { 'In Progress': 1, 'Referred': 2, 'Enrolled': 3, 'Disenrolled': 4, 'RFA Denied': 5, 'RFA Denied – System': 6 };

    const sorted = _.sortBy<RFAProgram>(rfaPrograms, [function (o) {
      return sortOrder[o.statusName];
    }, function (o) {
      if (o.applicationDate != null && o.applicationDate.trim() !== '') {
        return new Date(o.applicationDate);
      }
    }]);

    return sorted;
  }

  isStringEmptyOrNull(str) { return Utilities.isStringEmptyOrNull(str); }

}
