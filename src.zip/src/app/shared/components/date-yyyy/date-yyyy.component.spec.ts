// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DateYyyyComponent } from './date-yyyy.component';

// describe('DateYyyyComponent', () => {
//   let component: DateYyyyComponent;
//   let fixture: ComponentFixture<DateYyyyComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DateYyyyComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DateYyyyComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
