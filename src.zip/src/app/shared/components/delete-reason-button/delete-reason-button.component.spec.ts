// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { DeleteReasonButtonComponent } from './delete-reason-button.component';

// describe('DeleteReasonButtonComponent', () => {
//   let component: DeleteReasonButtonComponent;
//   let fixture: ComponentFixture<DeleteReasonButtonComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DeleteReasonButtonComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DeleteReasonButtonComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
