import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// Please do not remove these modules we ahve to include these here some that angular would know about these module during complining lazy loading still works as intended even we import these modules here.
import { JobReadinessModule } from './features-modules/job-readiness/job-readiness.module';
import { ActionsNeededModule } from './features-modules/actions-needed/actions-needed.module';

import { Authorization } from './shared/models/authorization';
import { ChildYouthSupportsEditComponent } from './participant/informal-assessment/edit/child-youth-supports.component';
import { ContactDetailComponent } from './contacts/detail/detail.component';
import { ContactsListPageComponent } from './contacts/list-page/list-page.component';
import { HomePageComponent } from './home-page/home-page.component';
import { EditComponent as EditInformalAssessmentComponent } from './participant/informal-assessment/edit/edit.component';
import { EducationHistoryEditComponent } from './participant/informal-assessment/edit/education-history.component';
import { FamilyBarriersEditComponent } from './participant/informal-assessment/edit/family-barriers.component';
import { HousingEditComponent } from './participant/informal-assessment/edit/housing.component';
import { LanguagesEditComponent } from './participant/informal-assessment/edit/languages.component';
import { LegalIssuesEditComponent } from './participant/informal-assessment/edit/legal-issues.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { MilitaryTrainingEditComponent } from './participant/informal-assessment/edit/military-training.component';
import { ParticipantBarriersEditComponent } from './participant/informal-assessment/edit/participant-barriers.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ParticipantBarriersListPageComponent } from './participant-barriers/list-page/list-page.component';
import { PostSecondaryEducationEditComponent } from './participant/informal-assessment/edit/post-secondary-education.component';
import { ReleaseNotesComponent } from './release-notes/release-notes.component';
import { PageHelpComponent } from './help/help.component';
import { StartComponent } from './start/start.component';
import { SummaryComponent as InformalAssessmentSummaryComponent } from './participant/informal-assessment/summary/summary.component';
import { SummaryComponent as ParticipantSummaryComponent } from './participant/summary/summary.component';
import { TestScoresListPageComponent } from './features-modules/test-scores/list-page/list-page.component';
import { TransportationEditComponent } from './participant/informal-assessment/edit/transportation.component';
import { WorkHistoryGatepostEditComponent } from './participant/informal-assessment/edit/work-history.component';
import { WorkHistoryListPageComponent } from './work-history/list-page/list-page.component';
import { WorkProgramsEditComponent } from './participant/informal-assessment/edit/work-programs.component';
import { WorkHistorySingleComponent } from './work-history/single/single.component';
import { SummaryComponent as TimeLimitsSummaryComponent } from './time-limits/summary/summary.component';
import { ExtensionListPageComponent } from './time-limits/extensions/list-page/list-page.component';
import { ExtensionDetailComponent } from './time-limits/extensions/detail/detail.component';
//import { SearchComponent as TimelimitsSearchComponent } from "./time-limits/search/search.component";
import { ParticipantBarriersSingleComponent } from './participant-barriers/single/single.component';
import { NcpEditComponent } from './participant/informal-assessment/edit/ncp.component';
import { NcprEditComponent } from './participant/informal-assessment/edit/ncpr.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { ClearanceComponent } from './clearance/clearance.component';
import { ParticipantService } from './shared/services/participant.service';
import { RfaPageComponent } from './rfa/page/page.component';
import { RfaSingleComponent } from './rfa/single/single.component';
import { ReportsComponent } from './webi/reports/reports.component';
import { WorkHistoryAppGuard } from './shared/guards/work-history-app.guard';
import { TimeLimitsAppGuard } from './shared/guards/time-limits-app.guard';
import { ParticipantGuard } from './shared/guards/participant-guard';
import { CoreAccessGuard } from './shared/guards/core-access-guard';
import { ClientRegistrationGuard } from './shared/guards/client-registration-guard';
import { InformalAssessmentGuard } from './shared/guards/informal-assessment-guard';
import { ParticipantBarriersAppGuard } from './shared/guards/participant-barriers-app-guard';
import { AuthGuard } from './shared/guards/auth-guard';
import { RegistrationComponent } from './enrollment/registration/registration.component';
import { ParticipationStatusesListPageComponent } from './features-modules/participation-statuses/list-page/list-page.component';
import { OrganizationInformationComponent } from './organization-information/organization-information.component';
import { OrgInfoGuard } from './shared/guards/org-info-guard';
import { EmployabilityPlanDriverFlowComponent } from './employability-plan/driver-flow/driver-flow.component';
import { EmployabilityPlanPageComponent } from './employability-plan/page/page.component';
import { HistoricalGoalsComponent } from './employability-plan/historical-goals/historical-goals.component';
import { HistoricalActivitiesComponent } from './employability-plan/historical-activities/historical-activities.component';
import { EndEmployabilityPlanComponent } from './employability-plan/end-employability-plan/end-employability-plan.component';
import { ActivitySingleComponent } from './employability-plan/activities/single/single.component';
import { EpOverviewComponent } from './employability-plan/ep-overview/ep-overview.component';
import { EPGuard } from './shared/guards/ep-guard';
import { EmploymentPlanComponent } from './employability-plan/employment-plan/employment-plan.component';
import { GoalsPageComponent } from './employability-plan/goals/page/page.component';
import { EpEmploymentsPageComponent } from './employability-plan/employments/page/page.component';
import { ElapsedActivitiesComponent } from './employability-plan/ep-overview/elapsed-activities/elapsed-activities.component';
import { ActivitiesPageComponent } from './employability-plan/activities/page/page.component';
import { SupportiveServiceComponent } from './employability-plan/supportive-service/supportive-service.component';
import { MasterParticipantGuard } from './shared/guards/master-participant-guard';
import { PinCommentsPageComponent } from './pin-comments/page/pin-comments-page/pin-comments-page.component';
import { CareerAssessmentComponent } from './career-assessment/career-assessment.component';
import { JobReadinessComponent } from './features-modules/job-readiness/job-readiness.component';
import { ActionsNeededComponent } from './features-modules/actions-needed/actions-needed.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/start', pathMatch: 'full' },
  { path: 'start', component: StartComponent },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'unauthorized', component: UnauthorizedComponent },
  { path: 'home', component: HomePageComponent, canActivate: [AuthGuard] },
  { path: 'home', component: HomePageComponent },
  { path: 'release-notes', component: ReleaseNotesComponent },
  { path: 'help', component: PageHelpComponent },
  {
    path: 'organization-information',
    component: OrganizationInformationComponent,
    data: { authorizations: [Authorization.canAccessOrganizationInformation] },
    canActivate: [AuthGuard, CoreAccessGuard, OrgInfoGuard]
  },
  { path: 'reports', component: ReportsComponent, data: { authorizations: [Authorization.canAccessReports] }, canActivate: [AuthGuard, CoreAccessGuard] },
  { path: 'clearance', data: { authorizations: [Authorization.canAccessClearance] }, component: ClearanceComponent, canActivate: [AuthGuard, CoreAccessGuard] },
  {
    path: 'pin/:pin/client-registration',
    data: { authorizations: [Authorization.canAccessClientReg_View] },
    component: RegistrationComponent,
    canActivate: [AuthGuard, CoreAccessGuard, ClientRegistrationGuard]
  },
  {
    path: 'pin/:pin/assessment/edit',
    // sec_page Assessment Edit
    // sec_usage Retricts access to any of the edit assessement functionality
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessInformalAssessment_Edit] },
    component: EditInformalAssessmentComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    canDeactivate: [InformalAssessmentGuard],
    children: [
      {
        path: 'languages',
        component: LanguagesEditComponent
      },
      {
        path: 'education',
        component: EducationHistoryEditComponent
      },
      {
        path: 'post-secondary',
        component: PostSecondaryEducationEditComponent
      },
      {
        path: 'military',
        component: MilitaryTrainingEditComponent
      },
      {
        path: 'work-programs',
        component: WorkProgramsEditComponent
      },
      {
        path: 'child-youth-supports',
        component: ChildYouthSupportsEditComponent
      },
      {
        path: 'housing',
        component: HousingEditComponent
      },
      {
        path: 'legal-issues',
        component: LegalIssuesEditComponent
      },
      {
        path: 'work-history',
        component: WorkHistoryGatepostEditComponent
      },
      {
        path: 'family-barriers',
        component: FamilyBarriersEditComponent
      },
      {
        path: 'participant-barriers',
        component: ParticipantBarriersEditComponent
      },
      {
        path: 'non-custodial-parents',
        component: NcpEditComponent
      },
      {
        path: 'non-custodial-parents-referral',
        component: NcprEditComponent
      },
      {
        path: 'transportation',
        component: TransportationEditComponent
      },
      {
        path: '',
        component: LanguagesEditComponent
      }
    ]
  },
  {
    path: 'pin/:pin/assessment',
    component: InformalAssessmentSummaryComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessInformalAssessment_View] }
  },
  {
    path: 'pin/:pin/contacts/:id',
    component: ContactDetailComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessContactsApp_Edit] }
  },
  {
    path: 'pin/:pin/contacts',
    component: ContactsListPageComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessContactsApp_View] }
  },
  {
    path: 'pin/:pin/test-scores',
    component: TestScoresListPageComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessTestScoresApp_View] }
  },
  {
    path: 'pin/:pin/action-needed',
    component: ActionsNeededComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessActionNeededApp_View] }
  },
  { path: 'pin/:pin/participant-barriers/:id', component: ParticipantBarriersSingleComponent, canActivate: [AuthGuard, ParticipantGuard] },
  { path: 'pin/:pin/participant-barriers', component: ParticipantBarriersListPageComponent, canActivate: [AuthGuard, ParticipantGuard, ParticipantBarriersAppGuard] },
  {
    path: 'pin/:pin/time-limits',
    component: TimeLimitsSummaryComponent,
    canActivate: [AuthGuard, ParticipantGuard, TimeLimitsAppGuard]
  },
  {
    path: 'pin/:pin/time-limits/extensions',
    component: ExtensionListPageComponent,
    canActivate: [AuthGuard, ParticipantGuard, TimeLimitsAppGuard]
  },
  {
    path: 'pin/:pin/time-limits/extensions/:id',
    component: ExtensionDetailComponent,
    canActivate: [AuthGuard, ParticipantGuard, TimeLimitsAppGuard]
  },
  {
    path: 'pin/:pin/rfa',
    component: RfaPageComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessRfa_View] }
  },
  {
    path: 'pin/:pin/rfa/:id',
    component: RfaSingleComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['CoreAccessGuard', 'ParticipantGuard'], authorizations: [Authorization.canAccessRfa_View] }
  },
  {
    path: 'pin/:pin/pin-comments',
    component: PinCommentsPageComponent,
    canActivate: [AuthGuard, CoreAccessGuard],
    data: { authorizations: [Authorization.canAccessPinComments_View] }
  },
  {
    path: 'pin/:pin/job-readiness',
    loadChildren: './features-modules/job-readiness/job-readiness.module#JobReadinessModule',
    data: { authorizations: [Authorization.canAccessJobReadiness_View] },
    canActivate: [AuthGuard, CoreAccessGuard],
    canDeactivate: [InformalAssessmentGuard]
  },
  { path: 'pin/:pin/work-history/:id', component: WorkHistorySingleComponent, canActivate: [AuthGuard, ParticipantGuard, WorkHistoryAppGuard] },
  { path: 'pin/:pin/work-history', component: WorkHistoryListPageComponent, canActivate: [AuthGuard, ParticipantGuard, WorkHistoryAppGuard] },
  {
    path: 'pin/:pin/employability-plan/list',
    component: EmployabilityPlanPageComponent,
    canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
    data: { authorizations: [Authorization.canAccessEmployabilityPlanApp_View] }
  },
  {
    path: 'pin/:pin/historical-goals',
    component: HistoricalGoalsComponent,
    canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard, EPGuard],
    data: { authorizations: [Authorization.canAccessEmployabilityPlanApp_View] }
  },
  {
    path: 'pin/:pin/historical-activities',
    component: HistoricalActivitiesComponent,
    canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard, EPGuard],
    data: { authorizations: [Authorization.canAccessEmployabilityPlanApp_View] }
  },
  {
    path: 'pin/:pin/end-employability-plan',
    component: EndEmployabilityPlanComponent,
    canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard, EPGuard],
    data: { authorizations: [Authorization.canAccessEmployabilityPlanApp_View] }
  },
  {
    path: 'pin/:pin/employability-plan',
    component: EmployabilityPlanDriverFlowComponent,
    canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
    canDeactivate: [InformalAssessmentGuard],
    data: { authorizations: [Authorization.canAccessEmployabilityPlanApp_View, Authorization.canAccessEmployabilityPlanApp_Edit] },
    children: [
      {
        path: ':id',
        component: EmploymentPlanComponent,
        canActivate: [EPGuard]
      },
      {
        path: 'goals/:id',
        component: GoalsPageComponent,
        canActivate: [EPGuard]
      },
      {
        path: 'employments/:id',
        component: EpEmploymentsPageComponent,
        canActivate: [EPGuard]
      },
      {
        path: 'elapsed-activities/:id',
        component: ElapsedActivitiesComponent,
        canActivate: [EPGuard]
        // canDeactivate: [SupportiveServiceGuard]
      },
      {
        path: 'activities/:id',
        component: ActivitiesPageComponent,
        canActivate: [EPGuard]
      },

      {
        path: 'supportive-service/:id',
        component: SupportiveServiceComponent,
        canActivate: [EPGuard]
        // canDeactivate: [SupportiveServiceGuard]
      }
    ]
  },
  {
    path: 'pin/:pin/employability-plan/single/activity/:id',
    component: ActivitySingleComponent,
    data: { authorizations: [Authorization.canAccessEmployabilityPlanApp_View] }
  },
  {
    path: 'pin/:pin/employability-plan/overview/:id',
    component: EpOverviewComponent,
    canActivate: [EPGuard],
    data: { authorizations: [Authorization.canAccessEmployabilityPlanApp_View] }
  },
  {
    path: 'pin/:pin/career-assessment',
    component: CareerAssessmentComponent,
    data: { authorizations: [Authorization.canAccessCareerAssessment_View] },
    canActivate: [AuthGuard, CoreAccessGuard]
  },
  {
    path: 'pin/:pin',
    component: ParticipantSummaryComponent,
    canActivate: [AuthGuard, MasterParticipantGuard],
    data: { guards: ['ParticipantGuard', 'CoreAccessGuard'], authorizations: [Authorization.canAccessParticipantSummary], isFromPartSumGuard: true }
  },
  {
    path: 'pin/:pin/participation-statuses',
    component: ParticipationStatusesListPageComponent,
    canActivate: [AuthGuard, CoreAccessGuard],
    data: { authorizations: [Authorization.canAccessParticipationStatus_View] }
  },
  { path: '**', component: PageNotFoundComponent }
];

export const appRoutingProviders: any[] = [
  AuthGuard,
  ParticipantGuard,
  ClientRegistrationGuard,
  CoreAccessGuard,
  InformalAssessmentGuard,
  ParticipantBarriersAppGuard,
  ParticipantService,
  TimeLimitsAppGuard,
  WorkHistoryAppGuard,
  MasterParticipantGuard,
  OrgInfoGuard,
  WorkHistoryAppGuard,
  EPGuard
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
