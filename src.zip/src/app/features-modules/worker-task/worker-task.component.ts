// tslint:disable: import-blacklist
import { Component, OnInit } from '@angular/core';
import { WorkerTask } from './models/worker-task.model';
import { Router } from '@angular/router';
import { WorkerTaskService } from './services/worker-task.service';
import { AppService } from '../../core/services/app.service';
import { DropDownField } from 'src/app/shared/models/dropdown-field';
import * as _ from 'lodash';
import { Utilities } from 'src/app/shared/utilities';

@Component({
  selector: 'app-worker-task',
  templateUrl: './worker-task.component.html',
  styleUrls: ['./worker-task.component.scss']
})
export class WorkerTaskComponent implements OnInit {
  public isLoaded = false;
  public dueDateId;
  public searchQuery: string;
  public selectedSort: number;
  public isFilterAsc = false;
  public showSortOptions = false;
  public categoryTypeDrop: DropDownField[] = [];
  private origCategoryTypeDrop: DropDownField[] = [];
  public originalWorkerTasks: WorkerTask[] = [];
  public categoryTypes = [];
  public sortDrop: DropDownField[] = [];

  public workerTasks: WorkerTask[];
  public filteredTasks: WorkerTask[];
  public goBackUrl: string;
  public selectedTask: WorkerTask;

  constructor(private workerTaskService: WorkerTaskService, public appService: AppService, private router: Router) {}

  ngOnInit() {
    this.goBackUrl = `/home`;
    this.initModel();
  }

  /**
   * Initializes the Worker Task model
   */
  initModel(): void {
    this.workerTaskService.getWorkerTaskList().subscribe(result => {
      this.workerTasks = result;
      this.originalWorkerTasks = result;
      this.sortTasks();
      this.initSortDrop();
      this.initCategoryTypes();

      this.origCategoryTypeDrop = this.categoryTypeDrop;
      this.isLoaded = true;
    });
  }

  changeState(task: WorkerTask) {
    this.selectedTask = task;
    this.workerTaskService.saveCompletedWorkerTask(task).subscribe(data => this.updateTask(data));
  }

  updateTask(data: WorkerTask) {
    this.selectedTask.completedDate = data['value'].completedDate;
  }

  public reverseClick() {
    this.reverseList();
  }

  public reverseList() {
    if (this.workerTasks != null) {
      this.workerTasks = Array.from(this.workerTasks.reverse());
    }
  }

  public sortTasks() {
    this.workerTasks = this.sortDueDate(this.workerTasks);
  }

  private sortDueDate(workerTask: WorkerTask[]): WorkerTask[] {
    const sortedByDueDate = _.sortBy<WorkerTask>(workerTask, [
      function(o: any) {
        if (o.taskDate != null && o.taskDate.trim() !== '') {
          return new Date(o.taskDate);
        }
      }
    ]);

    return sortedByDueDate;
  }

  private initSortDrop() {
    const options = ['Date'];

    this.sortDrop = options.map(function(option, index) {
      const x = new DropDownField();
      x.id = index;
      x.name = option;
      return x;
    });

    this.dueDateId = Utilities.idByFieldDataName('Date', this.sortDrop);
  }

  initCategoryTypes() {
    if (this.originalWorkerTasks) {
      const categoryTypeNames: DropDownField[] = [];
      const workerTasks = this.originalWorkerTasks;
      workerTasks.forEach(j => {
        const ctdd = new DropDownField();
        ctdd.id = j.categoryId;
        ctdd.name = j.categoryName;
        categoryTypeNames.push(ctdd);
      });
      this.categoryTypeDrop = _.orderBy<DropDownField>(
        _.uniqBy(categoryTypeNames, 'id'),
        [
          function(o) {
            return o.name;
          }
        ],
        ['asc']
      );
    }

    this.categoryTypes = this.categoryTypeDrop && this.categoryTypeDrop.length > 0 ? this.categoryTypes : [];
  }

  filter() {
    let categoryTypes: any[];
    this.filteredTasks = [];
    if (this.categoryTypes) categoryTypes = this.categoryTypes.length > 0 ? this.categoryTypes : this.origCategoryTypeDrop.map(i => i.id);

    if (categoryTypes) this.filteredTasks = this.originalWorkerTasks.filter(j => categoryTypes.indexOf(j.categoryId) > -1);

    this.workerTasks = this.filteredTasks;

    this.initCategoryTypes();
  }

  filterList(searchQuery: string) {
    if (searchQuery != null && searchQuery.trim() !== '' && this.workerTasks != null) {
      this.filteredTasks = [];
      const query = searchQuery.trim().toLowerCase();

      this.filteredTasks = this.originalWorkerTasks.filter(
        x =>
          x.fullName.toLowerCase().indexOf(query) > -1 ||
          x.pin.toString().indexOf(query) > -1 ||
          x.taskDate.toString().indexOf(query) > -1 ||
          x.categoryName
            .toLowerCase()
            .toString()
            .indexOf(query) > -1 ||
          x.taskDetails.toLowerCase().indexOf(query) > -1
      );

      this.workerTasks = this.filteredTasks;
    } else {
      this.workerTasks = this.originalWorkerTasks;
    }
  }
}
