import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { WorkerTaskRoutingModule } from './worker-task-routing.module';
import { WorkerTaskComponent } from './worker-task.component';
import { WorkerTaskService } from './services/worker-task.service';

@NgModule({
  imports: [CommonModule, SharedModule, WorkerTaskRoutingModule],
  declarations: [WorkerTaskComponent],
  providers: [WorkerTaskService]
})
export class WorkerTaskModule {}
