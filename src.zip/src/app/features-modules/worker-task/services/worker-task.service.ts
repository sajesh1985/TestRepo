// tslint:disable: deprecation
import { LogService } from '../../../shared/services/log.service';
import { Injectable } from '@angular/core';
import { AppService } from '../../../core/services/app.service';
import { Response } from '@angular/http';
import { AuthHttpClient } from '../../../core/interceptors/AuthHttpClient';
import { BaseService } from '../../../core/services/base.service';
import { Observable, BehaviorSubject } from 'rxjs';
import { WorkerTask } from '../models/worker-task.model';
import { Utilities } from '../../../shared/utilities';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class WorkerTaskService extends BaseService {
  private workerTaskUrl: string;

  constructor(http: AuthHttpClient, logService: LogService, private appService: AppService) {
    super(http, logService);
    this.workerTaskUrl = this.appService.apiServer + 'api/worker-task/';
  }

  /**
   * Fetches the WorkerTask List from the api
   */
  public getWorkerTaskList(): Observable<WorkerTask[]> {
    return this.http.get(this.workerTaskUrl).pipe(map(this.extractWorkerTaskList), catchError(this.handleError));
  }

  /**
   * Saves the completed Worker Task to the api
   */
  public saveCompletedWorkerTask(workerTask: WorkerTask) {
    const body = JSON.stringify(workerTask);

    return this.http.post(this.workerTaskUrl, body).pipe(map(this.extractWorkerTask), catchError(this.handleError));
  }

  /**
   * Handles the success response from the api
   */
  private extractWorkerTaskList(res: WorkerTask[]): WorkerTask[] {
    const jsonObjs = res as WorkerTask[];

    return jsonObjs;
  }

  /**
   * Handles the success response from the api
   */
  private extractWorkerTask(res: WorkerTask): WorkerTask {
    const jsonObjs = res as WorkerTask;

    return jsonObjs;
  }
}
