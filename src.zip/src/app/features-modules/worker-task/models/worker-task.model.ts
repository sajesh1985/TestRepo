// tslint:disable: no-use-before-declare
import { Utilities } from '../../../shared/utilities';
import { ValidationManager, ValidationResult, ValidationCode } from 'src/app/shared/models/validation';
import * as moment from 'moment';

export class WorkerTask {
  public id: number;
  public participantId: number;
  public fullName: string;
  public pin: number;
  public categoryId: number;
  public categoryName: string;
  public categoryCode: string;
  public taskDate: string;
  public taskDetails: string;
  public completedDate: string;
  public modifiedBy: string;
  public modifiedDate: string;

  public static clone(input: any, instance: WorkerTask) {
    instance.id = input.id;
    instance.participantId = input.participantId;
    instance.fullName = input.fullName;
    instance.pin = input.pin;
    instance.categoryId = input.categoryId;
    instance.categoryName = input.categoryName;
    instance.categoryCode = input.categoryCode;
    instance.taskDate = input.taskDate;
    instance.taskDetails = input.taskDetails;
    instance.completedDate = input.completedDate;
    instance.modifiedBy = input.modifiedBy;
    instance.modifiedDate = input.modifiedDate;
  }
  public deserialize(input: any) {
    WorkerTask.clone(input, this);
    return this;
  }
}
