import { ParticipationStatusEditComponent } from './edit.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { async } from 'q';
import { ActivatedRoute, Router } from '@angular/router';
import { FieldDataService } from '../../shared/services/field-data.service';
import { ParticipantService } from '../../shared/services/participant.service';
import { AppService } from './../../core/services/app.service';

// describe('EditComponent', () => {
//   let component: ParticipationStatusEditComponent;
//   let fixture: ComponentFixture<ParticipationStatusEditComponent>;
//   let fbService: FieldDataService;
//   let router: Router;
//   let route: ActivatedRoute;
//   let appService: AppService;
//   let partService: ParticipantService

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       declarations: [ParticipationStatusEditComponent],
//       providers:[AppService]
//     })
//     fixture = TestBed.createComponent(ParticipationStatusEditComponent);
//     component = fixture.componentInstance;
//     fbService = new FieldDataService(null, null);
//     appService = new AppService(null, null, null, null, null)
//   });

//   it('should create', () => {
//     component.
//     expect(component).toBeTruthy();
//   });
// });
