// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ActivitySingleComponent } from './single.component';

// describe('ActivitySingleComponent', () => {
//   let component: ActivitySingleComponent;
//   let fixture: ComponentFixture<ActivitySingleComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ActivitySingleComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ActivitySingleComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
