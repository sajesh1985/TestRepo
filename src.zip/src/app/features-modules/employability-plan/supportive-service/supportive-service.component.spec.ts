// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { SupportiveServiceComponent } from './supportive-service.component';

// describe('SupportiveServiceComponent', () => {
//   let component: SupportiveServiceComponent;
//   let fixture: ComponentFixture<SupportiveServiceComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [SupportiveServiceComponent]
//     }).compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SupportiveServiceComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
