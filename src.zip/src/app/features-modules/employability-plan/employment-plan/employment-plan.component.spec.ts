// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EmploymentPlanComponent } from './employment-plan.component';

// describe('EmploymentPlanComponent', () => {
//   let component: EmploymentPlanComponent;
//   let fixture: ComponentFixture<EmploymentPlanComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EmploymentPlanComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EmploymentPlanComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
