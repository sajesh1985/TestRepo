export enum ActivityLocation {
  selfDirected = 'Self-directed',

  offSite = 'Off-site',

  onSite = 'On-site'
}
