import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuxiliaryEditComponent } from './edit.component';

describe('AuxiliaryEditComponent', () => {
  let component: AuxiliaryEditComponent;
  let fixture: ComponentFixture<AuxiliaryEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AuxiliaryEditComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuxiliaryEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
