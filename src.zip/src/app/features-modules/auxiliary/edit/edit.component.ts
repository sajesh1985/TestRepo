import { HelpService } from './../../../shared/services/help.service';
import { AuxiliaryStatusTypes } from './../enums/auxiliary-status-types.enums';
import { Auxiliary } from '../models/auxiliary.model';
import { FieldDataService } from '../../../shared/services/field-data.service';
import { AuxiliaryService } from '../services/auxiliary.service';
import { Component, OnInit, Input } from '@angular/core';
import { DropDownField } from 'src/app/shared/models/dropdown-field';
import { Participant } from 'src/app/shared/models/participant';
import { take, concatMap } from 'rxjs/operators';
import { of, forkJoin } from 'rxjs';
import { ValidationManager } from 'src/app/shared/models/validation';
import { AppService } from 'src/app/core/services/app.service';
import { ModelErrors } from 'src/app/shared/interfaces/model-errors';

@Component({
  selector: 'app-auxiliary-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class AuxiliaryEditComponent implements OnInit {
  public isLoaded = false;
  public hadSaveError = false;
  public isSaving = false;
  public isSectionValid = true;
  public yearsDrop: DropDownField[] = [];
  public participationPeriodDrop: DropDownField[] = [];
  public auxiliaryReasonsDrop: DropDownField[] = [];
  public auxiliaryStatusTypesDrop: DropDownField[];
  @Input() participant: Participant;
  @Input() participationDetails: any;
  public isReadOnly: boolean;
  public canApproveAux = false;
  public isStatusRequired = false;
  public auxiliary: Auxiliary = new Auxiliary();
  public cachedModel: Auxiliary = new Auxiliary();
  public hasTriedSave: boolean;
  public isSectionModified: boolean;
  public validationManager: ValidationManager = new ValidationManager(this.appService);
  public modelErrors: ModelErrors = {};

  public canViewStatusesbol = false;
  public canWithDrawbool = false;
  public isReturnedAuxbool = false;
  public auxSheetUrl: string;
  constructor(private auxService: AuxiliaryService, private fbService: FieldDataService, private appService: AppService, private helpService: HelpService) {}

  ngOnInit() {
    this.initAuxiliaryModel();
    this.canWithDrawbool = this.canWithDraw();
  }
  requestDataFromMultipleSources() {
    return forkJoin(this.fbService.getParticipationPeriods().pipe(take(1)), this.fbService.getAuxiliaryReasons().pipe(take(1)));
  }
  initYearDrop() {
    const max = new Date().getFullYear();
    const drop = [];
    for (let year = max, size = 24; size >= 0; year--, size--) {
      const m = new DropDownField();
      m.id = year;
      m.name = year.toString();
      drop.push(m);
    }
    return drop;
  }
  initAuxStatusTypes() {
    this.fbService.getAuxiliaryStatusTypes().subscribe(res => {
      this.auxiliaryStatusTypesDrop = res;
      this.isLoaded = true;
    });
  }
  initAuxiliaryModel() {
    forkJoin(
      this.auxService.modeForAuxiliary.pipe(
        take(1),
        concatMap(res => {
          this.isReadOnly = res.readonly;
          return res.aux ? of(res) : of(null);
        })
      ),
      this.helpService.getHelpUrl('auxiliary-worksheet')
    ).subscribe(data => {
      if (data[0]) {
        this.auxiliary = data[0].aux;
        this.canApproveAux = data[0].canApprove;
        this.auxiliary.details = null;
        this.isStatusRequired = this.auxiliary.isStatusRequired(this.auxiliary.auxiliaryStatusTypeCode, data[0].canApprove);
        const obj = new DropDownField(this.auxiliary.participationPeriodId, this.auxiliary.participationPeriodName);
        this.participationPeriodDrop.push(obj);
        const obj1 = new DropDownField(this.auxiliary.auxiliaryReasonId, this.auxiliary.auxiliaryReasonName);
        this.auxiliaryReasonsDrop.push(obj1);
        const obj2 = new DropDownField(this.auxiliary.participationPeriodYear, this.auxiliary.participationPeriodYear.toString());
        this.yearsDrop.push(obj2);
        Auxiliary.clone(this.auxiliary, this.cachedModel);
        this.isReturnedAuxbool = this.isReturnedAux();
        // this.isReadOnly = data.isreadOnly || this.isReturnedAuxbool || this.canApproveAux;
        this.initAuxStatusTypes();
      } else {
        // TODO: Hard code the values on the backeend .
        this.auxiliary.id = 0;
        this.auxiliary.pinNumber = +this.participant.pin;
        this.auxiliary.participantName = this.participant.displayName;
        this.auxiliary.participantId = this.participant.id;
        //this.auxiliary.originalPayment = 100;
        //this.auxiliary.countyName = 'Dane';
        //this.auxiliary.countyNumber = 13;
        //this.auxiliary.officeNumber = 811;
        this.auxiliary.caseNumber = this.participationDetails.basicInfo.caseNumber ? this.participationDetails.basicInfo.caseNumber : 1235436;
        Auxiliary.clone(this.auxiliary, this.cachedModel);
        this.requestDataFromMultipleSources().subscribe(results => {
          this.participationPeriodDrop = results[0];
          this.auxiliaryReasonsDrop = results[1];
          this.yearsDrop = this.initYearDrop();
          this.isLoaded = true;
        });
      }

      this.auxSheetUrl = data[1];
    });
  }

  getDetailsBasedonParticipationPeriod() {
    if (this.auxiliary.participationPeriodId && this.auxiliary.participationPeriodYear) {
      this.auxService.getDetailsBasedonParticipationPeriod(this.auxiliary.participationPeriodId, this.auxiliary.participationPeriodYear).subscribe(res => {
        this.auxiliary.originalPayment = res.originalPayment;
        this.auxiliary.countyName = res.countyName;
        this.auxiliary.countyNumber = res.countyNumber;
        this.auxiliary.officeNumber = res.officeNumber;
      });
    } else {
      this.auxiliary.originalPayment = null;
      this.auxiliary.countyName = null;
      this.auxiliary.countyNumber = null;
      this.auxiliary.officeNumber = null;
    }
  }

  isReturnedAux() {
    return this.auxiliary.auxiliaryStatusTypeCode === AuxiliaryStatusTypes.RT;
  }
  exit() {
    if (this.isSectionModified) {
      this.appService.isUrlChangeBlocked = false;
      this.appService.isDialogPresent = true;
    } else {
      this.auxService.modeForAuxiliary.next({ readOnly: false, isInEditMode: false });
    }
  }
  exitAuxEditIgnoreChanges(e) {
    this.auxService.modeForAuxiliary.next({ readOnly: false, isInEditMode: false });
  }
  validate() {
    this.isSectionModified = true;
    if (this.hasTriedSave === true) {
      this.validationManager.resetErrors();
      const result = this.auxiliary.validate(this.validationManager, this.canApproveAux, this.auxiliaryStatusTypesDrop);
      this.isSectionValid = result.isValid;
      this.modelErrors = result.errors;
      if (this.isSectionValid) this.hasTriedSave = false;
      if (this.modelErrors) {
        this.isSaving = false;
      }
    }
  }
  save() {
    // TODO: Look if this can be refactored
    if (this.isSectionValid) {
      this.hadSaveError = false;
      this.isSaving = true;
      let pin;
      if (this.participant) {
        pin = this.participant.pin;
      } else {
        pin = this.auxiliary.pinNumber;
      }
      this.auxService.saveAuxiliary(this.auxiliary, pin).subscribe(
        res => {
          this.auxService.modeForAuxiliary.next({ readOnly: false, isInEditMode: false });
          this.isSaving = false;
        },
        error => {
          this.isSaving = false;
          this.hadSaveError = true;
        }
      );
    }
  }
  changeStatus() {
    if (this.auxiliary.auxiliaryStatusTypeId === null) {
      this.auxiliary.auxiliaryStatusTypeName = 'Submitted';
    } else {
      this.auxiliary.auxiliaryStatusTypeName = null;
    }
  }
  canWithDraw() {
    if (this.auxiliary.id > 0) {
      return this.auxiliary.auxiliaryStatusTypeName === 'Return';
    } else {
      return false;
    }
  }

  submit() {
    this.auxiliary.isSubmit = true;
    this.auxiliary.isWithDraw = false;
    this.saveAndExit();
  }
  withDraw() {
    this.auxiliary.isSubmit = false;
    this.auxiliary.isWithDraw = true;
    this.saveAndExit();
  }
  saveAndExit() {
    this.hasTriedSave = true;
    this.validate();
    this.save();
  }
}
