import { AuxiliaryStatusTypes } from './../enums/auxiliary-status-types.enums';
import { Serializable } from '../../../shared/interfaces/serializable';
import { ValidationManager, ValidationResult, ValidationCode } from 'src/app/shared/models/validation';
import { AuxiliaryStatus } from './auxiliary-status.model';
import { Utilities } from 'src/app/shared/utilities';
import { DropDownField } from 'src/app/shared/models/dropdown-field';

export class Auxiliary implements Serializable<Auxiliary> {
  id: number;
  pinNumber: number;
  participantName: string;
  participantId: number;
  caseNumber: number;
  countyNumber: number;
  countyName: string;
  officeNumber: number;
  officeName: string;
  agencyCode: string;
  participationPeriodId: number;
  participationPeriodName: string;
  participationPeriodYear: number;
  originalPayment: number;
  requestedAmount: number;
  auxiliaryReasonId: number;
  auxiliaryReasonName: string;
  auxiliaryStatusTypeId: number;
  auxiliaryStatusTypeCode: string;
  auxiliaryStatusTypeName: string;
  auxiliaryStatusTypeDisplayName: string;
  auxiliaryStatusDate: string;
  details: string;
  isSubmit: boolean;
  isWithDraw: boolean;
  createdDate: string;
  auxiliaryStatuses: AuxiliaryStatus[];
  modifiedBy: string;
  modifiedDate: string;

  public static clone(input: any, instance: Auxiliary) {
    instance.id = input.id;
    instance.pinNumber = input.pinNumber;
    instance.participantName = input.participantName;
    instance.participantId = input.participantId;
    instance.caseNumber = input.caseNumber;
    instance.countyName = input.countyName;
    instance.countyNumber = input.countyNumber;
    instance.officeNumber = input.officeNumber;
    instance.officeName = input.officeName;
    instance.agencyCode = input.agencyCode;
    instance.participationPeriodId = input.participationPeriodId;
    instance.participationPeriodName = input.participationPeriodName;
    instance.participationPeriodYear = input.participationPeriodYear;
    instance.originalPayment = input.originalPayment;
    instance.requestedAmount = input.requestedAmount;
    instance.auxiliaryStatusTypeId = input.auxiliaryStatusTypeId;
    instance.auxiliaryStatusTypeCode = input.auxiliaryStatusTypeCode;
    instance.auxiliaryStatusTypeName = input.auxiliaryStatusTypeName;
    instance.auxiliaryStatusTypeDisplayName = input.auxiliaryStatusTypeDisplayName;
    instance.auxiliaryReasonId = input.auxiliaryReasonId;
    instance.auxiliaryReasonName = input.auxiliaryReasonName;
    instance.auxiliaryStatusDate = input.auxiliaryStatusDate;
    instance.details = input.details;
    instance.isSubmit = input.isSubmit;
    instance.isWithDraw = input.isWithDraw;
    instance.auxiliaryStatuses = Utilities.deserilizeChildren(input.auxiliaryStatuses, AuxiliaryStatus);
    instance.createdDate = input.createdDate;
    instance.modifiedBy = input.modifiedBy;
    instance.modifiedDate = input.modifiedDate;
  }

  public deserialize(input: any) {
    Auxiliary.clone(input, this);
    return this;
  }
  public isStatusRequired(statusTypeCode, canApprove) {
    return (statusTypeCode === AuxiliaryStatusTypes.SB || statusTypeCode === AuxiliaryStatusTypes.RV) && canApprove;
  }
  public validate(validationManager: ValidationManager, canApprove: boolean, auxiliaryStatusTypesDrop?: DropDownField[]): ValidationResult {
    const result = new ValidationResult();
    if (this.participationPeriodId == null || this.participationPeriodId.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Participation Period');
      result.addError('participationPeriodId');
    }
    if (this.participationPeriodYear == null || this.participationPeriodYear.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Participation Period Year');
      result.addError('participationPeriodYear');
    }
    if (this.originalPayment == null || this.originalPayment.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Original Payment Amount');
      result.addError('originalPayment');
    }
    if (this.requestedAmount == null || this.requestedAmount.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'W-2 Auxiliary Amount');
      result.addError('requestedAmount');
    }
    if (this.auxiliaryReasonId == null || this.auxiliaryReasonId.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Reason');
      result.addError('auxiliaryReasonId');
    }
    if (this.details == null || this.details.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Details');
      result.addError('details');
    }
    if (this.isStatusRequired(this.auxiliaryStatusTypeCode, canApprove)) {
      if (Utilities.fieldDataCodeById(this.auxiliaryStatusTypeId, auxiliaryStatusTypesDrop, true) === '') {
        validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Auxiliary Status');
        result.addError('auxiliaryStatusTypeId');
      }
    }
    return result;
  }
}
