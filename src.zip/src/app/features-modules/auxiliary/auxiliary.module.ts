import { SharedModule } from 'src/app/shared/shared.module';
import { NgModule } from '@angular/core';
import { AuxiliaryApproverListComponent } from './approver-list/approver-list.component';
import { CommonModule } from '@angular/common';
import { AuxiliaryWorkerListComponent } from './worker-list/worker-list.component';
import { AuxiliaryComponent } from './auxiliary.component';
import { AuxiliaryRoutingModule } from './auxiliary.routing';
import { AuxiliaryEditComponent } from './edit/edit.component';
import { AuxiliaryService } from './services/auxiliary.service';

@NgModule({
  declarations: [AuxiliaryComponent, AuxiliaryApproverListComponent, AuxiliaryWorkerListComponent, AuxiliaryEditComponent],
  imports: [CommonModule, AuxiliaryRoutingModule, SharedModule],
  providers: [AuxiliaryService]
})
export class AuxiliaryModule {}
