import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auxiliary',
  template: `
    <app-aux-approver-list *ngIf="!isParticipantAuxiliary"></app-aux-approver-list>
    <app-aux-worker-list *ngIf="isParticipantAuxiliary"></app-aux-worker-list>
  `
})
export class AuxiliaryComponent {
  public isParticipantAuxiliary = false;

  constructor(private router: Router) {
    this.isParticipantAuxiliary = this.router.url.includes('pin');
  }
}
