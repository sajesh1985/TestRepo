export enum AuxiliaryStatusTypes {
  SB = 'SB',
  RT = 'RT',
  RV = 'RV'
}
