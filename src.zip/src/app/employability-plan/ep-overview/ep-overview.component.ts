import { ModelErrors } from './../../shared/interfaces/model-errors';
import { EmployabilityPlanOverview } from './../../shared/models/employability-plan-overview';
import { EmployabilityPlan } from './../../shared/models/employability-plan.model';
import { SupportiveServiceService } from './../../shared/services/supportive-service.service';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { EmployabilityPlanService } from './../../shared/services/employability-plan.service';
// tslint:disable-next-line: import-blacklist
import { Observable } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Activity } from '../../shared/models/activity.model';
import { SupportiveService } from '../../shared/models/supportive-service.model';
import { Goal } from '../../shared/models/goal.model';
import { Participant } from '../../shared/models/participant';
import { ParticipantService } from '../../shared/services/participant.service';
import { ValidationManager } from '../../shared/models/validation';
import { AppService } from './../../core/services/app.service';
import { AccessType } from '../../shared/enums/access-type.enum';
import { SubSink } from 'subsink';
import * as moment from 'moment';
import * as _ from 'lodash';
import { EnrolledProgram } from '../../shared/models/enrolled-program.model';
import { WhyReason } from '../../shared/models/why-reasons.model';
import { ParticipationStatus } from '../../shared/models/participation-statuses.model';
import { Location } from '@angular/common';
import { forkJoin } from 'rxjs';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-ep-overview',
  templateUrl: './ep-overview.component.html',
  styleUrls: ['./ep-overview.component.scss']
})
export class EpOverviewComponent implements OnInit, OnDestroy {
  id: number;
  goBackToOverviewUrl: string;
  isElapsedActivity: boolean;
  public pin: string;
  public employabilityPlanId: string;
  public goBackUrl: string;
  public isCollapsed = false;
  public inConfirmDeleteView = false;
  public isSectionValid = true;
  public modelErrors: ModelErrors = {};
  public isEpInProgress = true;
  public isEpDeleted = false;
  public isEpDeletedByWorker = false;
  public detailsLoaded = false;

  public participant: Participant;
  public employabilityPlan: EmployabilityPlan;
  public activities: Activity[];
  public goals: Goal[];
  public supportiveServices: SupportiveService[];
  public validationManager: ValidationManager = new ValidationManager(this.appService);
  public isElapsedChanges = false;
  private subs = new SubSink();
  public employments: any;
  public allActivities: Activity[];
  elapsedActivityNotEnded: boolean;
  public elapsedNotEndedactivities: Activity[];
  participationStatuses: ParticipationStatus[] = [];
  localParticipationStatuses: ParticipationStatus[];
  isPSLoaded: boolean;
  currentlyEnrolledPrograms: EnrolledProgram[];
  canView: boolean;
  public precheck: WhyReason;
  public activityTypeIds: string;
  public isSubmitting = true;
  public showEndEPButton = false;
  public showSubmitSuccess = false;
  public showSubmitFail = false;
  public subjectdetailsLoaded = false;
  public saveSuccess = false;
  currentEp: any;
  public isEpSubmittedRecently = false;
  empInfo: any;
  empInfoObj: any;
  public showCalendar = false;
  // public navigationSubscription: any;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private employabilityPlanService: EmployabilityPlanService,
    private supportiveServiceService: SupportiveServiceService,
    public appService: AppService,
    private partService: ParticipantService,
    private location: Location
  ) {}

  ngOnInit() {
    this.subs.add(
      this.route.params.subscribe(params => {
        this.pin = params.pin;
        this.employabilityPlanId = params.id;
        this.goBackUrl = '/pin/' + this.pin + '/employability-plan/list';
        this.getDetails();
      })
    );
  }

  sidebarToggle() {
    this.isCollapsed = !this.isCollapsed;
    return this.isCollapsed;
  }
  onSubmit() {
    this.employabilityPlanService.canAddActivity(this.pin, +this.employabilityPlanId, this.activityTypeIds ? this.activityTypeIds : '0').subscribe(
      res => {
        this.precheck = _.merge(res, this.precheck);
        return;
      },
      error => console.log(error),
      // This will be called once the above subscription is complete and validate and save are called only when we dont have any errors from precheck
      () => {
        if (this.precheck.status !== true) {
          this.isSectionValid = false;
        }
        this.validate(this.isSectionValid);
        return;
      }
    );
  }

  closeSubmit() {
    //in navigate url, the url is wrong so navigate will return false and moves on to navigate by url
    this.router
      .navigate([`pin/${this.pin}/employability-plan/overview/`], { skipLocationChange: true })
      .then(() => this.router.navigateByUrl(`pin/${this.pin}/employability-plan/overview/${this.employabilityPlanId}`));
    this.showSubmitSuccess = false;
    this.showSubmitFail = false;
  }

  delete() {
    this.inConfirmDeleteView = true;
  }
  onConfirmDelete() {
    const autoDelete = false;
    this.employabilityPlanService.deleteEP(this.pin, this.employabilityPlanId, autoDelete).subscribe(res => {
      if (res) {
        this.inConfirmDeleteView = false;
        this.router.navigateByUrl(`/pin/${this.pin}/employability-plan/list`);
      }
    });
  }
  onCancelDelete() {
    this.inConfirmDeleteView = false;
  }
  showCalendarView() {
    this.showCalendar = !this.showCalendar;
  }
  closeCalendar(e: boolean) {
    this.showCalendar = e;
  }
  private getDetails() {
    this.subs.add(
      this.requestDataFromMultipleSources()
        .pipe(take(1))
        .subscribe(results => {
          this.initEp(results[0]);
          this.goals = results[1];
          this.activities = results[2];
          this.appService.activitiesFromOverview.next(this.activities);
          this.appService.goalsFromOverview.next(this.goals);
          this.allActivities = results[2];
          this.activities.filter(activity => {
            if (activity && activity !== null) {
              if (!this.activityTypeIds || this.activityTypeIds === null) this.activityTypeIds = `${activity.activityTypeId}`;
              else this.activityTypeIds = `${this.activityTypeIds},${activity.activityTypeId}`;
            }
          });
          this.supportiveServices = results[3];
          this.participant = results[4];
          this.getAllStatusesForPin(results[5]);
        })
    );
  }

  public requestDataFromMultipleSources(): Observable<any[]> {
    const response1 = this.employabilityPlanService.getEpById(this.pin, this.employabilityPlanId).pipe(take(1));
    const response2 = this.employabilityPlanService.getGoals(this.pin, this.employabilityPlanId).pipe(take(1));
    const response3 = this.employabilityPlanService.getActivities(this.pin, this.employabilityPlanId).pipe(take(1));
    const response4 = this.supportiveServiceService.getSupportiveServices(this.pin, this.employabilityPlanId).pipe(take(1));
    const response5 = this.partService.getCurrentParticipant();
    const response6 = this.partService.getAllStatusesForPin(this.pin);
    // Observable.forkJoin (RxJS 5) changes to just forkJoin() in RxJS 6
    return forkJoin([response1, response2, response3, response4, response5, response6]);
  }
  private initEp(ep) {
    this.employabilityPlan = ep;
    this.appService.employabilityPlan.next(ep);

    this.getData().subscribe(result => {
      if (result[0] && result[0].results) {
        this.empInfoObj = result[0].results;
      } else if (result[0] && result[0].beginDate !== undefined) {
        this.empInfo = result[0];
      }
      this.isEpSubmittedRecently = result[1].submittedEp;
      this.showHideEndEpButton(this.empInfo, this.empInfoObj, ep);
      this.appService.submittedEpGoToOverview.next({ submittedEp: false });
    });

    // this.appService.employabilityPlanInfo
    //   .concatMap(data => {
    //     if (data && data.results) {
    //       this.empInfoObj = data.results;
    //     } else if (data && data.beginDate !== undefined) {
    //       this.empInfo = data;
    //     }
    //     return this.appService.submittedEpGoToOverview;
    //   })
    //   .subscribe(result => {
    //     this.isEpSubmittedRecently = result.submittedEp;
    //   });

    this.isEpInProgress = ep.employabilityPlanStatusTypeName === 'In Progress';
    this.isEpDeleted = ep.isDeleted;
    this.isEpDeletedByWorker = ep.isWorkerDeleted;
    this.employabilityPlanService
      .getEmploymentForEP(this.pin, +this.employabilityPlanId, this.employabilityPlan.beginDate.split('/').join('-'), this.employabilityPlan.enrolledProgramCd)
      .subscribe(res => {
        this.employments = res.filter(i => i.isSelected === true);
        this.detailsLoaded = true;
      });
  }
  public getData() {
    return forkJoin([this.appService.employabilityPlanInfo.pipe(take(1)), this.appService.submittedEpGoToOverview.pipe(take(1))]);
  }
  private showHideEndEpButton(data?: any, dataObj?: any, selectedEp?) {
    if ((data && data.length > 0) || (dataObj && dataObj.length > 0)) {
      const enrolledPrograms =
        dataObj.length > 0
          ? dataObj[1].getCurrentEnrolledProgramsUserHasAccessTo(this.appService.user, this.appService)
          : data[1].getCurrentEnrolledProgramsUserHasAccessTo(this.appService.user, this.appService);
      const submittedEps =
        dataObj.length > 0 ? dataObj[0].filter(i => i.employabilityPlanStatusTypeName === 'Submitted') : data[0].filter(i => i.employabilityPlanStatusTypeName === 'Submitted');
      const submittedEPsUserHasAccessTo = submittedEps.filter(ep => this.appService.isUserAuthorizedForProgramByCode(ep.enrolledProgramCd));
      const inProgressEP =
        dataObj.length > 0 ? dataObj[0].filter(i => i.employabilityPlanStatusTypeName === 'In Progress') : data[0].filter(i => i.employabilityPlanStatusTypeName === 'In Progress');
      const inProgressEPsUserHasAccessTo = inProgressEP.filter(ep => this.appService.isUserAuthorizedForProgramByCode(ep.enrolledProgramCd));
      const enrolledProgramsIds = [];
      const submittedEpProgramIds = [];
      const inprogessEpProgramIds = [];
      this.currentEp =
        dataObj.length > 0
          ? dataObj[0].filter(ep => ep.employabilityPlanStatusTypeName === 'Submitted' && ep.enrolledProgramCd === this.employabilityPlan.enrolledProgramCd)
          : data[0].filter(ep => ep.employabilityPlanStatusTypeName === 'Submitted' && ep.enrolledProgramCd === this.employabilityPlan.enrolledProgramCd);
      enrolledPrograms.forEach(element => {
        enrolledProgramsIds.push(element.enrolledProgramId);
      });
      submittedEPsUserHasAccessTo.forEach(element => {
        submittedEpProgramIds.push(element.enrolledProgramId);
      });
      inProgressEPsUserHasAccessTo.forEach(element => {
        inprogessEpProgramIds.push(element.enrolledProgramId);
      });
      // using index of as IE 11 doesn't support includes
      if (
        (enrolledProgramsIds &&
          enrolledProgramsIds.length > 0 &&
          submittedEpProgramIds &&
          submittedEpProgramIds.length > 0 &&
          this.currentEp &&
          this.currentEp.length > 0 &&
          !(inprogessEpProgramIds.indexOf(this.currentEp[0].enrolledProgramId) > -1) &&
          inProgressEPsUserHasAccessTo &&
          inProgressEPsUserHasAccessTo.length === 0 &&
          selectedEp &&
          selectedEp.employabilityPlanStatusTypeName !== 'Ended' &&
          selectedEp.employabilityPlanStatusTypeName !== 'In Progress' &&
          this.appService.isUserAuthorizedForProgramByCode(this.employabilityPlan.enrolledProgramCd)) ||
        (this.isEpSubmittedRecently && selectedEp.employabilityPlanStatusTypeName !== 'Ended' && selectedEp.employabilityPlanStatusTypeName !== 'In Progress')
      ) {
        this.showEndEPButton = true;
        this.subjectdetailsLoaded = true;
      } else {
        this.subjectdetailsLoaded = true;
      }
    } else if (this.isEpSubmittedRecently && selectedEp.employabilityPlanStatusTypeName !== 'Ended' && selectedEp.employabilityPlanStatusTypeName !== 'In Progress') {
      this.showEndEPButton = true;
      this.subjectdetailsLoaded = true;
    } else {
      this.showEndEPButton = false;
      this.subjectdetailsLoaded = true;
    }
  }

  public getAllStatusesForPin(res) {
    res.filter(data => {
      if (data.enrolledProgramName === this.employabilityPlan.enrolledProgramName) this.participationStatuses.push(data);
    });
    this.localParticipationStatuses = _.orderBy(this.participationStatuses.slice(), ['isCurrent', 'BeginDate'], ['desc', 'asc']);
  }

  public editSection(epComponent) {
    if (epComponent) {
      this.appService.employabilityPlanInfo.next(this.employabilityPlan);
      const url = `/pin/${this.pin}/employability-plan/${epComponent}/${this.employabilityPlanId}`;
      this.router.navigateByUrl(url);
    } else {
      const url = `/pin/${this.pin}/employability-plan/${this.employabilityPlanId}`;
      this.router.navigateByUrl(url);
    }
  }

  public elapsedSection() {
    this.isElapsedActivity = true;
  }

  checkIfAnyElapsedActivitiesToSave(activities: Activity[]) {
    this.elapsedNotEndedactivities = activities.filter(activity => {
      // In an In progress EP, in the elapsed activity section driver flow, we check if the activity is carried over and if the ep is in progress
      if (activity.isCarriedOver && activity.activityCompletionReasonId === null) {
        return moment(activity.maxEndDate, 'MM/DD/YYYY').isBefore(moment(this.employabilityPlan.beginDate).format('MM/DD/YYYY'));

        // If no activity is carried over
      }
    });
  }

  showEndEmployabilityPlan() {
    const url = `/pin/${this.pin}/end-employability-plan`;
    this.router.navigateByUrl(url);
  }

  validate(isValid: boolean) {
    const epOverView = new EmployabilityPlanOverview();
    this.checkIfAnyElapsedActivitiesToSave(this.allActivities);
    const result = epOverView.validate(this.validationManager, this.employabilityPlan, this.allActivities, this.goals, this.elapsedNotEndedactivities);
    this.isSectionValid = result.isValid;
    this.modelErrors = result.errors;
    if (this.isSectionValid && isValid) {
      this.employabilityPlanService.submitEp(this.pin, +this.employabilityPlanId).subscribe(res => {
        if (res) {
          this.showSubmitSuccess = true;
          this.saveSuccess = true;
          // storing value that tells us if the ep was submitted recently
          this.appService.submittedEpGoToOverview.next({ submittedEp: true });
          this.employabilityPlanService.EditActivitySection.next({ readOnly: true, inEditView: false, showControls: false });
          this.employabilityPlanService.EditGoalSection.next({ readOnly: true, inEditView: false, showControls: false, isHistory: false });
        }
      });
    } else this.isSubmitting = false;
  }

  exitToEp() {
    this.isElapsedActivity = false;
  }

  elapsedSaveChanges(isSaved: boolean) {
    this.isElapsedChanges = isSaved;
  }

  exitElapsedActivityEditIgnoreChanges($event) {
    this.appService.isDialogPresent = false;
    this.isElapsedActivity = false;
  }
  exitToEpView() {
    this.isElapsedChanges ? (this.appService.isDialogPresent = true) : (this.isElapsedActivity = false);
  }
  hasEditEpAccess(): boolean {
    let canEdit = false;
    if (this.appService.coreAccessContext) {
      if (this.appService.coreAccessContext.evaluate() === AccessType.edit) {
        const programsUserHasAccessto = this.participant.getCurrentEnrolledProgramsUserHasAccessTo(this.appService.user, this.appService);
        if (programsUserHasAccessto.length > 0) {
          programsUserHasAccessto.some(program => {
            if (program.programCode === this.employabilityPlan.enrolledProgramName) {
              canEdit = true;
              return true;
            }
          });
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else {
      return false;
    }
    return canEdit;
  }
  ngOnDestroy() {
    this.subs.unsubscribe();
    // // avoid memory leaks here by cleaning up after ourselves. If we
    // // don't then we will continue to run our initialiseInvites()
    // // method on every navigationEnd event.
    // if (this.navigationSubscription) {
    //   this.navigationSubscription.unsubscribe();
    // }
  }
}
