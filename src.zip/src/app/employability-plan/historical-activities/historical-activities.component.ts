import { Component, OnInit } from '@angular/core';
import { Activity } from '../../shared/models/activity.model';
import { Router, ActivatedRoute } from '@angular/router';
import { PaginationInstance } from 'ng2-pagination';
import { Utilities } from '../../shared/utilities';
import { EmployabilityPlanService } from '../../shared/services/employability-plan.service';
import { Participant } from '../../shared/models/participant';
import { ParticipantService } from '../../shared/services/participant.service';
// tslint:disable-next-line: import-blacklist
import { AppService } from './../../core/services/app.service';
import { forkJoin } from 'rxjs';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-historical-activities',
  templateUrl: './historical-activities.component.html',
  styleUrls: ['./historical-activities.component.scss']
})
export class HistoricalActivitiesComponent implements OnInit {
  public activities: Activity[];
  public participant: Participant;
  public isLoaded = false;
  public pin: string;
  public goBackUrl: string;
  public config: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 10,
    currentPage: 1
  };

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private employabilityPlanService: EmployabilityPlanService,
    private partService: ParticipantService,
    private appService: AppService
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.pin = params.pin;
    });
    return forkJoin([this.partService.getCurrentParticipant(), this.employabilityPlanService.getActivitiesForPin(this.pin).pipe(take(1))])
      .pipe(take(1))
      .subscribe(result => {
        this.participant = result[0];
        this.activities = result[1];
        this.employabilityPlanService.findMinAndMaxDatesForActivity(this.activities);
        this.goBackUrl = '/pin/' + this.pin + '/employability-plan/list';
        this.isLoaded = true;
      });
  }

  numberInView(config, p, max: number) {
    return Utilities.numberOfItemsOnCurrentPage(config, p, max);
  }

  singleEntry(a) {
    this.employabilityPlanService.EditActivitySection.next({ readOnly: true, inEditView: true, showControls: false, activity: a });
    this.appService.inHistoryMode.next({ inHistory: true });
    this.router.navigateByUrl(`pin/${this.pin}/employability-plan/activities/${a.employabilityPlanId}`);
  }
}
