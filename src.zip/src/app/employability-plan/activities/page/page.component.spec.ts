// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ActivitiesPageComponent } from './page.component';

// describe('ActivitiesPageComponent', () => {
//   let component: ActivitiesPageComponent;
//   let fixture: ComponentFixture<ActivitiesPageComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ActivitiesPageComponent]
//     }).compileComponents();
//   }));

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
