import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EpEmployment } from '../../../shared/models/ep-employment.model';
import { EmployabilityPlanService } from '../../../shared/services/employability-plan.service';
import { AppService } from '../../../core/services/app.service';

@Component({
  selector: 'app-epemployments-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class EpEmploymentsListComponent implements OnInit {
  @Input() employments: EpEmployment[];
  @Input() showControls = true;
  @Input() isReadOnly = true;
  @Output() selectedEmployment = new EventEmitter();
  public checked: boolean;
  public tempEmps;

  constructor(private employabilityPlanService: EmployabilityPlanService, private appService: AppService) {}

  ngOnInit() {
    if (this.employments) {
      this.tempEmps = this.employments.splice(0);
    }
  }

  selected() {
    this.selectedEmployment.emit(this.tempEmps);
    this.appService.componentDataModified.next({ dataModified: true });
    this.appService.isUrlChangeBlocked = true;
  }
}
