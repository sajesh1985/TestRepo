
import { AuthConfigConsts, IAuthConfig, AuthHttp, AuthConfig } from 'angular2-jwt';
import { Injectable } from '@angular/core';
import { Http, RequestOptions, BaseRequestOptions, Headers } from '@angular/http';

export class JwtAuthConfig extends AuthConfig {

  constructor(
    headerName: string = AuthConfigConsts.DEFAULT_HEADER_NAME,
    headerPrefix: string = AuthConfigConsts.HEADER_PREFIX_BEARER,
    tokenName: string = AuthConfigConsts.DEFAULT_TOKEN_NAME,
    public tokenGetter: () => string = () => localStorage.getItem(tokenName),
    noJwtError: boolean = false, // try the request anyway, let the server figure out what to do
    globalHeaders: Array<Object> = [{'Content-Type':'application/json'}],
    noTokenScheme: boolean = false,
    public expirationOffset: number = 0,
    public tokenSetter: (data: any) => void = (data) => localStorage.setItem(tokenName, data)
  ) {
    super({
      headerName: headerName,
      headerPrefix: headerPrefix,
      tokenName: tokenName,
      tokenGetter: tokenGetter,
      noJwtError: noJwtError,
      globalHeaders: globalHeaders,
      noTokenScheme: noTokenScheme
    }
    );
  }
}

export function authHttpFactory(http: Http, options: RequestOptions, config: IAuthConfig){
        return new AuthHttp(new AuthConfig(config), http, options);
      }

export function jwtAuthConfigFactory(){
  return new JwtAuthConfig();
}

// export function ProvideJwtAuth() {
//   return [
//     {
//       provide: AuthHttp,
//       deps: [Http, RequestOptions, JwtAuthConfig],
//       useFactory: authHttpFactory
//     },
//     { provide: JwtAuthConfig, useFactory: jwtAuthConfigFactory }
//   ];
// }


