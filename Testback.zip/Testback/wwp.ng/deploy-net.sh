# Running the build
npm run build-now

# Deploy to pre-configured netlify
netlify deploy --prod --dir=dist --open
