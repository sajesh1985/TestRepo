# WWP Angular Application
### Angular code for the WWP application

[![CircleCI](https://circleci.com/gh/chujanen/wwp.ng/tree/develop.svg?style=svg&circle-token=47590022f91576c5833a12ea3f7654dd859cb4a6)](https://circleci.com/gh/chujanen/wwp.ng/tree/develop)

----
