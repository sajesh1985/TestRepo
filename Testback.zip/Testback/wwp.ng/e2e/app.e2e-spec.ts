import { WWPPage } from './app.po';
import { browser, element, by, promise, ElementFinder, Key } from 'protractor';

describe('WWP App', () => {
    // let page: WWPPage;

    // beforeEach(() => {
    //     page = new WWPPage();
    // });

    it('should display message saying app works', () => {

        browser.get('/', 30000);
        browser.waitForAngularEnabled(false);
        element(by.name('UserLogin')).sendKeys('sohinder');
        element(by.name('Password')).sendKeys('good');
        element(by.name('Password')).sendKeys(Key.ENTER);
        browser.driver.sleep(10000);
        //  browser.waitForAngularEnabled(true);
        element(by.name('searchQuery')).sendKeys('write first protractor test');


        //    element(by.model('todoList.todoText')).sendKeys('write first protractor test');
    });
});
