import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseParticipantComponent } from '../../shared/components/base-participant-component';
import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { DropDownField } from '../../shared/models/dropdown-field';
import { Employment } from '../../shared/models/work-history-app';
import { FieldDataService } from '../../shared/services/field-data.service';
import { ParticipantService } from '../../shared/services/participant.service';
import { RFAProgram } from '../../shared/models/rfa.model';
import { RfaService } from '../../shared/services/rfa.service';
import { Subscription, Observable } from 'rxjs/Rx';
import { Utilities } from '../../shared/utilities';

@Component({
  selector: 'app-single',
  templateUrl: './single.component.html',
  styleUrls: ['./single.component.css'],
  providers: [RfaService, FieldDataService]
})
export class RfaSingleComponent extends BaseParticipantComponent implements OnInit, OnDestroy {

  public goBackUrl: string;
  public model: RFAProgram;
  public programDrop: DropDownField[] = [];

  private rfaSub: Subscription;
  private rfaId = 0;

  private routeIdSub: Subscription;
  constructor(private activatedRoute: ActivatedRoute, router: Router,
    private rfaService: RfaService, participantService: ParticipantService,
    private fieldDataService: FieldDataService) {
    super(activatedRoute, router, participantService);
  }

  ngOnInit() {
    super.onInit();

    this.routeIdSub = this.activatedRoute.params.subscribe(params => {
      this.goBackUrl = '/pin/' + this.pin + '/rfa';
      this.rfaService.setPin(this.pin);
      this.rfaId = params['id'];

      this.rfaSub =   this.rfaService.getRfaById(this.rfaId.toString()).subscribe(data => this.initModel(data));
    });
  }

  private initModel(data) {
    this.model = data;
  }

  private initRfaProgramsDrop(data): void {
    this.programDrop = data;
  }

  ngOnDestroy(): void {
    if (this.rfaSub != null) {
      this.rfaSub.unsubscribe();
    }
  }

}
