import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';

import { coerceNumber } from '../../../shared/decorators/number-property';
import { ActionNeeded } from '../../../shared/models/action-needed';
import { Authorization } from '../../../shared/models/authorization';
import { BaseParticipantComponent } from '../../../shared/components/base-participant-component';
import { BooleanDictionary } from '../../../shared/interfaces/boolean-dictionary';
import { Dictionary } from '../../../shared/dictionary';
import { DropDownField } from '../../../shared/models/dropdown-field';
import { FieldDataService } from '../../../shared/services/field-data.service';
import { InformalAssessment } from '../../../shared/models/informal-assessment';
import { InformalAssessmentService } from '../../../shared/services/informal-assessment.service';
import { LogService } from '../../../shared/services/log.service';
import { Participant } from '../../../shared/models/participant';
import { ParticipantService } from '../../../shared/services/participant.service';
import { ValidationManager } from '../../../shared/models/validation-manager';
import { AppService } from '../../../shared/services/app.service';
import { ModelErrors } from '../../../shared/interfaces/model-errors';
import { Utilities } from '../../../shared/utilities';
import { WorkHistoryAppService } from '../../../shared/services/work-history-app.service';
import { AccessType } from '../../../shared/enums/access-type.enum';

import * as moment from 'moment';

declare var $: any;

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css'],
  providers: [InformalAssessmentService, FieldDataService, WorkHistoryAppService]
})
export class SummaryComponent extends BaseParticipantComponent implements OnInit, OnDestroy {
  Auth = Authorization;
  AccessType = AccessType;
  public assessment: InformalAssessment;
  public goBackUrl: string;
  public isSidebarCollapsed = false;
  public pin: string;
  public hasPBAccessBol: boolean;
  public canRequestPBAccess: boolean;
  public hasFBAccessBol: boolean;
  public canRequestFBAccess: boolean;
  public fbAccessType: AccessType;
  public pbSub: Subscription;
  public fbSub: Subscription;

  public isLoaded = false;
  public isSubmitable = false;
  public showSubmitSuccess = false;
  public showSubmitFail = false;
  public isSectionValid: BooleanDictionary = {};
  public modelErrors: ModelErrors = {};
  public validationManagers: Dictionary<string, ValidationManager>;

  get canAccessPB(): boolean {
    return this.appService.isUserAuthorized(Authorization.canAccessPB, null);
  }
  get canRequestRestrictedAccess(): boolean {
    return this.appService.isUserAuthorized(Authorization.canRequestRestrictedAccess, null);
  }

  constructor(
    public appService: AppService,
    protected route: ActivatedRoute,
    protected router: Router,
    private logService: LogService,
    protected partService: ParticipantService,
    private iaService: InformalAssessmentService
  ) {
    super(route, router, partService);

    // jQuery for sidebar
    $(window).on('scroll', function() {
      var o = $('#sidebar');
      if (1.2 * $('#sidebar').outerHeight() < $(window).height()) {
        var e = $(window).scrollTop(),
          s = e - $('app-header').outerHeight() - $('app-sub-header').outerHeight() + 0;
        s > 0 ? o.css('top', s + 'px') : o.css('top', '0');
      } else o.css('top', '0');
    });

    // jQuery for scrolling to sections
    $(document).on('click', '#sidebar li.menu-item', function() {
      let sec = $(this).data('goto');
      $('html, body').stop();
      if (sec) {
        $('html, body').animate(
          {
            scrollTop: $('#' + sec).offset().top - 75
          },
          1000
        );
      }
    });
  }

  ngOnInit() {
    super.onInit();
  }

  onPinInit() {
    this.goBackUrl = '/pin/' + this.pin;
  }

  onPartipantInit() {
    this.iaService.getInformalAssessment(this.pin).subscribe(ia => {
      this.assessment = ia;
     // initializing the PBSection Behavior subject here
      this.iaService.initPbvars(this.pin);

      if (this.assessment != null && this.assessment.id !== 0) {
        this.iaService.loadValidationContextsAndValidate(this.participant, this.assessment).subscribe(
          n => n,
          e => e,
          () => {
            // The next and error events above are not needed.  We only care about
            // knowing when the validation is complete so we can update our class
            // properties to those from the service.
            this.isSectionValid = this.iaService.isSectionValid;
            this.modelErrors = this.iaService.modelErrors;
            this.validationManagers = this.iaService.validationManagers;

            // We should enable the Submit when we are in an assessment and all sections
            // are valid.
            if (this.assessment.id === 0 || this.assessment.submitDate != null) {
              // We either don't have an assessment or it's already been submitted.
              this.isSubmitable = false;
            } else {
              // We have one so check if all the sections are valid.
              this.isSubmitable = this.iaService.areAllSectionsValid();
            }

            this.iaService.participant = this.participant;
            this.isLoaded = true;
            this.appService.hasPBAccess(this.participant);
            this.appService.hasPHIAccess(this.participant);
            this.pbSub = this.appService.PBSection.subscribe(res => {
              this.hasPBAccessBol = res.hasPBAccessBol;
              this.canRequestPBAccess = res.canRequestPBAccess;
            });
            this.fbSub = this.appService.FBSection.subscribe(res => {
              this.hasFBAccessBol = res.hasFBAccessBol;
              this.canRequestFBAccess = res.canRequestFBAccess;
            })
          }
        );
      } else {
        this.isLoaded = true;
      }
    });
  }

  ngOnDestroy() {
    if (this.pbSub != null) {
      this.pbSub.unsubscribe();
    }
  }

  // onDashboard() {
  //   this.router.navigateByUrl('home');
  // }

  onEdit() {
    this.router.navigateByUrl(`/pin/${this.pin}/assessment/edit`);
  }

  onNew() {
    this.iaService.createNewAssessment(this.participant).subscribe(
      n => n,
      e => e,
      () => {
        // The next and error events above are not needed.  We only care about
        // knowing when the call is complete.
        this.onEdit();
      }
    );
  }

  onSubmit() {
    this.showSubmitSuccess = true;
    this.iaService.submitAssessment(this.participant).subscribe(
      n => n,
      e => e,
      () => {
        // To optimize the performance, we'll just manually set the assessment submit date.
        this.assessment.submitDate = moment();
        this.isSubmitable = false;
      }
    );
  }

  closeSubmit() {
    this.showSubmitSuccess = false;
    this.showSubmitFail = false;
  }

  toggleSidebar() {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }

  hasEditIaAccess(): boolean {
    if (
      this.appService.coreAccessContext.evaluate() === AccessType.edit &&
      this.participant.isCurrentlyEnrolled(this.appService.user.agencyCode) === true &&
      this.assessment != null &&
      (this.assessment.id > 0 || this.assessment.submitDate !== null)
    ) {
      return true;
    } else {
      return false;
    }
  }

  onReenableValidation() {
    this.iaService.validate(this.assessment);
  }
}
