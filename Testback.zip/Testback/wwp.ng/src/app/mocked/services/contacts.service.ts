import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';

import { Contact } from '../../shared/models/contact';


@Injectable()
export class MockedContactsService {

    constructor() {
    }

    getContactById(id: number, pin: string): Observable<Contact> {
        let contact = new Contact();
        contact.id = id;
        contact.name = 'Mocked Contact';
        return Observable.of(contact);
    }

    getContactsByPin(pin: string): Observable<Contact[]> {
        let contacts = [];

        let contact = new Contact();
        contact.id = 1;
        contact.name = 'Mocked Contact1';

        contacts.push(contact);

        contact = new Contact();
        contact.id = 2;
        contact.name = 'Mocked Contact2';

        contacts.push(contact);

        return Observable.of(contacts);
    }


    deleteContactById(id: string, pin: string) {
    }
}
