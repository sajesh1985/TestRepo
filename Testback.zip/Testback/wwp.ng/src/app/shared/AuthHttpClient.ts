import { ComponentRef, Injectable } from '@angular/core';
import { ConnectionBackend, Headers, Http, Request, RequestMethod, RequestOptions, RequestOptionsArgs, Response, ResponseOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';

import { IAuthConfig, AuthHttpError, JwtHelper } from 'angular2-jwt';
import * as moment from 'moment';

import { JwtAuthConfig } from '../jwt-auth-config';
import { LoginDialogComponent } from './components/login-dialog/login-dialog.component';
import { ModalService } from '../shared/modal';

@Injectable()
export class AuthHttpClient extends Http {
  private config: IAuthConfig;
  public jwtConfig: JwtAuthConfig;
  private jwtHelper: JwtHelper;
  private lastRequest: moment.Moment;

  // public httpErrorHandler: (err: any, caught: Observable<Response>) => Observable<Response> = (err, caught) => { return Observable.throw(err); }
  // private loginModalComponent: ComponentRef<LoginDialogComponent>;
  private loginModalComponentObs: Observable<ComponentRef<LoginDialogComponent>>;
  private loginSummitedSub: Subscription;
  constructor(authConfigOptions: JwtAuthConfig, protected _backend: ConnectionBackend, protected _defaultOptions: RequestOptions, private _modalService: ModalService) {
    super(_backend, _defaultOptions);
    this.jwtConfig = authConfigOptions;
    this.config = authConfigOptions.getConfig();
    // this.config.noJwtError = true; // supress JWT client side errors and try the request anyway
    this.jwtHelper = new JwtHelper();
  }

  // private errorHandler(err: any, obs: Observable<Response>): Observable<Response> {
  //   if (err instanceof AuthHttpError || (err instanceof Response && err.status === 401) && this._modalService.activeInstances === 0) {
  //     return this.openLoginDialog();
  //   } else {
  //     return Observable.throw(err);
  //   }
  // }

  /**
   * Indicates if the authenticated user is inactive.
   *
   * @returns {boolean}
   * @memberof AuthHttpClient
   */
  public isUserInactive(): boolean {
    const now = moment();

    if (this.lastRequest == null) {
      // We can use the logic above because we know the token will already be checked and must be
      // valid and non-expired.  So, if we get here it means we don't have the last request in
      // memory so we'll check local storage.
      const lr = localStorage.getItem('lr');

      if (lr == null || lr.length === 0) {
        return true;
      }

      this.lastRequest = moment(lr, 'YYYYMMDDHHmmss', true);
    }

    // We'll get the duration in seconds in case we want to do some testing and use a smaller
    // time duration.
    const duration = moment.duration(now.diff(this.lastRequest)).asSeconds();

    // Do a quick sanity check here to make sure the duration hasn't been tampered with
    // by checking that it's not less than 0 (meaning the previous value is in the future)
    // as well as that the duration is within 20 minutes from now.  (20 * 60) == 1200
    if (duration < 0 || duration > 1200) {
      return true;
    }

    // Update the last request value in local storage.
    this.markUserAsActive(now);

    return false;
  }

  /**
   * Marks user as active and updates the last request tracking variable.
   * @param [timestamp]
   */
  public markUserAsActive(timestamp?: moment.Moment) {
    if (timestamp === undefined) {
      timestamp = moment();
    }

    this.lastRequest = timestamp;
    localStorage.setItem('lr', this.lastRequest.format('YYYYMMDDHHmmss'));
  }

  /**
   * Clears user active indicator, which is useful when the user logs out.
   */
  public clearUserActive() {
    localStorage.removeItem('lr');
  }

  private openLoginDialog(): Subject<Response> {
    const loginSubject: Subject<Response> = new Subject<Response>();

    if (!this.loginModalComponentObs) {
      this.loginModalComponentObs = this._modalService.create(LoginDialogComponent);
    }

    this.loginModalComponentObs.take(1).subscribe(componentRef => {
      if (this.loginSummitedSub) {
        this.loginSummitedSub.unsubscribe();
      }
      this.loginSummitedSub = componentRef.instance.loginSubmitted.subscribe(authResult => {
        if (authResult.authorized) {
          this.lastRequest = moment();
          const opts = new ResponseOptions();
          opts.body = authResult;
          opts.status = 200;
          const response = new Response(opts);
          loginSubject.next(response);
          loginSubject.complete();
        }
      });

      componentRef.onDestroy(() => {
        this.loginModalComponentObs = null;
        if (this.loginSummitedSub && !this.loginSummitedSub.closed) {
          this.loginSummitedSub.unsubscribe();
        }
      });
    });

    return loginSubject;
  }

  private mergeOptions(providedOpts: RequestOptionsArgs, defaultOpts?: RequestOptions) {
    let newOptions = defaultOpts || new RequestOptions();
    if (this.config.globalHeaders) {
      this.setGlobalHeaders(this.config.globalHeaders, providedOpts);
    }

    // Note that `headers` and `search` will override existing values completely if present in
    // * the `options` object. If these values should be merged, it should be done prior to calling
    // * `merge` on the `RequestOptions` instance.
    // providedOpts.headers = Object.assign(newOptions.headers, providedOpts.headers);

    newOptions = newOptions.merge(new RequestOptions(providedOpts));

    return newOptions;
  }

  private requestHelper(requestArgs: RequestOptionsArgs, additionalOptions?: RequestOptionsArgs): Observable<Response> {
    let options = new RequestOptions(requestArgs);
    if (additionalOptions) {
      options = options.merge(additionalOptions);
    }
    return this.request(new Request(this.mergeOptions(options, this._defaultOptions))).catch((err: any, caught: Observable<Response>) => {
      if (err instanceof AuthHttpError || (err instanceof Response && err.status === 401 && this._modalService.activeInstances === 0)) {
        return this.openLoginDialog().flatMap(res => {
          return this.request(new Request(this.mergeOptions(options, this._defaultOptions))); // Retry original request
        });
      }
      return Observable.throw(err);
    });
  }

  private requestWithToken(req: Request, token: string): Observable<Response> {
    // TODO: cache calculation so we don't do this on requests with the same token
    // trying to avoid user manipulation causing the app to crash
    let tokenExpired: boolean;
    try {
      tokenExpired = this.jwtHelper.isTokenExpired(token);
      if (tokenExpired === false) {
        // Check the timeout
        tokenExpired = this.isUserInactive();
      }
    } catch (e) {
      tokenExpired = true;
    }

    if (tokenExpired && !this.config.noClientCheck) {
      // note: We are ignoring the noJwtError config value because i don't see a use for throwing exceptions on the client.
      // if the token expired the client-side action should always be the same (try to refresh, open login dialog, etc)
      return this.openLoginDialog().flatMap(res => {
        const requestOpts = new RequestOptions();
        requestOpts.body = req.getBody();
        requestOpts.headers = req.headers;
        requestOpts.method = req.method;
        requestOpts.url = req.url;
        requestOpts.responseType = req.responseType;
        requestOpts.withCredentials = req.withCredentials;
        return this.request(new Request(requestOpts)); // Retry original request
      });
    } else {
      req.headers.set(this.config.headerName, this.config.headerPrefix + token);
    }
    return super.request(req);
  }

  public setGlobalHeaders(headers: Array<Object>, request: Request | RequestOptionsArgs) {
    if (!request.headers) {
      request.headers = new Headers();
    }
    headers.forEach((header: Object) => {
      const key: string = Object.keys(header)[0];
      const headerValue: string = (header as any)[key];
      (request.headers as Headers).set(key, headerValue);
    });
  }

  public request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    if (typeof url === 'string') {
      return this.get(url, options); // Recursion: transform url from String to Request
    }
    // else if ( ! url instanceof Request ) {
    //   throw new Error('First argument must be a url string or Request instance.');
    // }

    // from this point url is always an instance of Request;
    const req: Request = url as Request;
    if (req.withCredentials === false || (options && options.withCredentials === false)) {
      return super.request(req);
    } else {
      const token: string = this.jwtConfig.tokenGetter();
      return this.requestWithToken(req, token);
    }

    // if (token instanceof Promise) {
    //   return Observable.fromPromise(token).mergeMap((jwtToken: string) => this.requestWithToken(req, jwtToken));
    // } else {
    //   return this.requestWithToken(req, token);
    // }
  }

  public get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper({ body: '', method: RequestMethod.Get, url: url }, options);
  }

  public post(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper({ body: body, method: RequestMethod.Post, url: url }, options);
  }

  public put(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper({ body: body, method: RequestMethod.Put, url: url }, options);
  }

  public delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper({ body: '', method: RequestMethod.Delete, url: url }, options);
  }

  public patch(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper({ body: body, method: RequestMethod.Patch, url: url }, options);
  }

  public head(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper({ body: '', method: RequestMethod.Head, url: url }, options);
  }

  public options(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.requestHelper({ body: '', method: RequestMethod.Options, url: url }, options);
  }
}

// @Injectable()
// export class NativeHttp extends Http { }
