/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { ValidationSummaryComponent } from './validation-summary.component';

// describe('Component: ValidationSummary', () => {
//   it('should create an instance', () => {
//     let component = new ValidationSummaryComponent();
//     expect(component).toBeTruthy();
//   });
// });
