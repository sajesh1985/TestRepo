import { Component, forwardRef, Input, OnChanges, OnInit } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

import { BaseComponent } from '../base-component';


export const PhoneNumberControlValueAccessor: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => PhoneNumberInputComponent),
  multi: true
};

@Component({
  selector: 'app-phone-number-input',
  templateUrl: './phone-number-input.component.html',
  styleUrls: ['./phone-number-input.component.css'],
  providers: [PhoneNumberControlValueAccessor]
})
export class PhoneNumberInputComponent extends BaseComponent implements ControlValueAccessor, OnChanges, OnInit {

  @Input() index: number = 0;
  @Input() isDisabled: boolean = false;
  @Input() isInvalid: boolean = false;
  @Input() placeholder: string;

  @Input() isRequired: boolean;
  @Input() maxLength: number;

  constructor() {
    super();
  }

  ngOnInit() {
  }

  ngOnChanges() {
  }

  get value(): any {
    return this.innerValue;
  };


  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = this.cleanseValue(v);
      this.onChangeCallback(this.innerValue);
    }
  }

  cleanseValue(value: string): string {
    if (!value) {
      return '';
    }

    if (value === '') {
      return value;
    }

    let cleansed = value.replace(/[A-z]/g, '').trim();
    if (cleansed === '') {
      cleansed = ' ';     // Hack for not being able to clean it to an empty string.
    }

    return cleansed;
  }

  onBlur() {
    this.onTouchedCallback();
  }

  writeValue(value: any) {
    if (value !== this.innerValue) {
      this.innerValue = this.cleanseValue(value);
    }
  }


  registerOnChange(fn: any) {
    this.onChangeCallback = fn;
  }


  registerOnTouched(fn: any) {
    this.onTouchedCallback = fn;
  }


  keyDown(e: KeyboardEvent): boolean {
    if (e.keyCode < 65 || e.keyCode > 90) {
      return true;
    }

    // Now look for key modifieres that are allowed.
    if (e.ctrlKey || e.metaKey || e.altKey) {
      return true;
    }

    return false;
  }

  validateInput(e: KeyboardEvent) {
  }

}
