import { ModalService } from '../../../modal/modal.service';
import { NotificationsService } from 'angular2-notifications';
import { SystemClockService } from '../../../services/system-clock.service';
import { Component, OnInit } from '@angular/core';
import { Modal } from "../../../modal/modal-placeholder/modal-placeholder.component";
import { AppService } from "../../../services/app.service";
import * as moment from 'moment';
import { DestroyableComponent } from "../../../modal/index";

@Component({
  selector: 'app-date-changer',
  templateUrl: 'date-changer.component.html',
  styleUrls: ['date-changer.component.css']
})
@Modal()
export class DateChangerComponent implements DestroyableComponent, OnInit {
  public isTimeSimulated: boolean;


  public destroy: Function = () => { };
  public closeDialog: Function = () => { };
  model: Date;
  constructor(private notificationService: NotificationsService, private modalService: ModalService) {
    this.model = SystemClockService.appDateTime.toDate();
    this.isTimeSimulated = SystemClockService.isTimeSimulated;
  }

  ngOnInit() {

  }

  saveAndExit() {
    SystemClockService.simulateClientDateTime(moment(this.model));
    this.notificationService.warn("Date/Time simulated:", `${SystemClockService.appDateTime.format('LLL')}`, { timeOut: 0, clickToClose: false }).click.take(1).subscribe(x => {
      this.modalService.create<DateChangerComponent>(DateChangerComponent);
    });
    this.exit();
  }

  cancelSimulation() {
    SystemClockService.cancelSimulateClientDateTime();
    this.notificationService.remove();
    this.notificationService.info("Canceled", "Date/Time simualtion cancelled.");
    this.notificationService.success("Date/Time reset", `Time reset to set: <br> ${SystemClockService.appDateTime.format('LLL')}`);
    this.exit();
  }

  exit() {
    this.closeDialog();
    this.destroy();
  }
}
