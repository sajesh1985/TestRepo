// augmentations.ts
// TODO: Remove this when RxJS releases a stable version with a correct declaration of `Subject`. (v6?)
import {Operator} from 'rxjs/Operator'
import {Observable} from 'rxjs/Observable'

declare module 'rxjs/Subject' {
  interface Subject<T> {
    lift<R>(operator: Operator<T, R>): Observable<R>
  }
}