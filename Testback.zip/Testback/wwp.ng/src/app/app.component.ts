import { Component, OnDestroy, HostListener } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';

import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

import * as moment from 'moment';

import { environment } from '../environments/environment';
import { LogService } from './shared/services/log.service';
import { AppService } from './shared/services/app.service';
import { Startup } from './shared/models/events/startup';
import { version, SemanticVersion } from './shared/version';

declare var ga: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnDestroy {
  private static previousUrl = '';
  private routerSub: Subscription;
  private timeUpdateSub: Subscription;

  // http://stackoverflow.com/questions/37655898/tracking-google-analytics-page-views-in-angular2
  // private appService: AppService,
  constructor(private router: Router, private route: ActivatedRoute, public appService: AppService, private logService: LogService) {
    // Set up a subscriptionfor route changes.
    this.routerSub = this.router.events.subscribe(e => {
      if (e instanceof NavigationEnd) {
        if (AppComponent.previousUrl !== '') {
          this.logService.timerEndUpdateEvent('route');
        }

        this.logService.timerStartEvent('route', { url: e.url });
        AppComponent.previousUrl = e.url;

        if (environment.production) {
          ga('send', 'pageview', e.url);
        }
      }
    });

    // Update the application time every 60 seconds
    this.timeUpdateSub = Observable.interval(1000 * 60)
      .timeInterval()
      .subscribe(x => {
        appService
          .getServerStatus()
          .take(1)
          .subscribe(
            status => {
              // try {

              //   AppService.currentDate = moment(status.date);
              //   // console.info('updated date: ' + AppService.currentDate.format());
              // } catch (error) {
              //   AppService.currentDate = moment();
              //   const errorMsg = 'Error updating client application time:' + error && error.message ? error.message : '';
              //   logService.error(errorMsg);
              // }
              // if (AppService.currentDate == null || !AppService.currentDate.isValid()) {
              //   AppService.currentDate = moment();
              // }
              if (status.environment != null) {
                this.appService.currentEnvironment = status.environment;
                // localStorage.setItem('environment', status.environment.toString());
              }

              // First determine if we think we are out of date
              if (status.version && !status.version.equals(version)) {
                let reloadedToVersion: SemanticVersion = null;
                let versionString = localStorage.getItem('reloadedToVersion');
                reloadedToVersion = SemanticVersion.parse(versionString);
                if (reloadedToVersion && reloadedToVersion.equals(status.version)) {
                  logService.warn(`Already attempted application reload to version ${reloadedToVersion}. Version out of sync. Server:${version}. Client:${status.version}`);
                } else {
                  localStorage.setItem('reloadedToVersion', status.version.toString());
                  location.reload(true);
                }
              } else {
                localStorage.removeItem('reloadedToVersion');
              }
            },
            error => console.error(error)
          );
      });

    const s = new Startup();
    s.os = navigator.platform;

    s.sh = screen.height;
    s.sw = screen.width;

    const w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;

    const h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

    s.wh = h;
    s.ww = w;

    s.ua = navigator.userAgent;
    s.host = window.location.host;
    s.ver = version.toString();

    this.logService.event('app-startup', s);
  }

  public notificationOptions = {
    position: ['bottom', 'right'],
    timeOut: 5000,
    lastOnBottom: true,
    preventDuplicates: true,
    maxStack: 3,
    pauseOnHover: true
  };

  ngOnDestroy() {
    if (this.routerSub != null) {
      this.routerSub.unsubscribe();
    }
    if (this.timeUpdateSub != null) {
      this.timeUpdateSub.unsubscribe();
    }
  }
  @HostListener('document:keydown', ['$event'])
  handleKeyPress(event: KeyboardEvent) {
    if (event.ctrlKey && event.shiftKey && event.keyCode === 65) {
      this.appService.showAdminDialogTimeBox();
    }
    // tslint:disable-next-line:max-line-length
    if (
      event.which === 8 &&
      ((<HTMLInputElement>event.target).nodeName !== 'TEXTAREA' && (<HTMLInputElement>event.target).nodeName !== 'INPUT' && (<HTMLInputElement>event.target).nodeName !== 'SELECT')
    ) {
      event.preventDefault();
    }
  }
}
