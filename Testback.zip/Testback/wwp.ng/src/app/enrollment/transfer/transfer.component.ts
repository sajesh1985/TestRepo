import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs/Rx';
import { DestroyableComponent } from '../../shared/modal/index';
import { EnrolledProgram } from '../../shared/models/enrolled-program.model';
import { ModalBase } from '../../shared/modal/modal-base';
import { DropDownField } from '../../shared/models/dropdown-field';
import { AgencyService } from '../../shared/services/agency.service';
import { AgencyWorker } from '../../shared/models/agency-worker';
import { AppService } from '../../shared/services/app.service';
import { ParticipantService } from '../../shared/services/participant.service';
import { Participant, ParticipantDetails } from '../../shared/models/participant';
import { OfficeSummary } from '../../shared/models/office-summary.model';
import { OfficeService } from '../../shared/services/office.service';
import { WorkerService } from '../../shared/services/worker.service';
import { PadPipe } from '../../shared/pipes/pad.pipe';
import { Utilities } from '../../shared/utilities';
import { WhyReason } from '../../shared/models/why-reasons.model';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./../../shared/modal/modal-placeholder/modal-placeholder.component.css', './transfer.component.css'],
  providers: [AgencyService, OfficeService, WorkerService]
})
export class TransferComponent extends ModalBase implements OnInit, DestroyableComponent, OnDestroy {
  public officeDrop: DropDownField[] = [];
  public programDrop: DropDownField[] = [];
  public workerDrop: DropDownField[] = [];
  public isLoaded = false;

  public isPrecheckLoading = false;
  public isModified = false;
  public pin: string;

  public preCheckError = false;
  public hadSaveError = false;
  public isSaving = false;
  public isSaveAble = false;
  public officeSub: Subscription;
  public workerSub: Subscription;
  private preSub: Subscription;
  isProgramDropDisabled = false;
  public programId = null;
  public originalProgramId = null;
  public workProgramOfficeId = null;
  public originalWorkProgramOfficeId = null;
  public workerId = null;
  public originalWorkerId = null;
  public pepW2Id = 0;
  public pepTJId = 0;
  public pepLFId = 0;
  public pepCFId = 0;
  public pepTmjId = 0;
  public participantDetails: ParticipantDetails;
  public model: Participant;

  public precheckMsgs: WhyReason;
  public isValid = false;
  public isRequired = false;

  private officesList: OfficeSummary[] = [];

  constructor(
    private aService: AgencyService,
    private officeService: OfficeService,
    private workerService: WorkerService,
    private appService: AppService,
    private partService: ParticipantService
  ) {
    super();
  }

  ngOnInit() {
    Observable.forkJoin(this.partService.getParticipant(this.pin).take(1), this.partService.getParticipantSummaryDetails(this.pin).take(1))
      .take(1)
      .subscribe(results => {
        this.initPart(results[0]);
        this.initDetailsParticipant(results[1]);
        this.initProgramDrop();
        this.isLoaded = true;
      });
  }

  programChange() {
    // Reset all data.
    this.workProgramOfficeId = null;
    this.originalWorkProgramOfficeId = null;
    this.workerId = null;
    this.originalWorkerId = null;
    this.precheckMsgs = null;
    this.officesList = [];
    this.officeDrop = [];
    this.workerDrop = [];
    this.loadOffices();
  }

  loadOffices() {
    const program = this.model.programs.find(x => x.id === this.programId);

    if (program == null) {
      return;
    }

    this.officeSub = this.officeService.getTransferOfficesByProgramWorkerSourceOffice(program.programCd, this.appService.user.mainFrameId, program.officeNumber).subscribe(data => {
      this.initOfficeDestinationsDrop(data);
    });
  }

  loadWorkers($event) {
    if (this.officeDrop == null) {
      return;
    }

    if (this.programId == null || this.programId <= 0) {
      return;
    }

    // Use the agency from the selected office.
    const selectedOrg = this.officesList.find(x => x.id === this.workProgramOfficeId).organizationCode;

    this.workerSub = this.aService.getAgencyWorkersByAgencyCodeAndProgramCode(selectedOrg, this.model.programs.find(x => x.id === this.programId).programCd).subscribe(data => {
      this.initWorkerDrop(data);
    });
  }

  initOfficeDestinationsDrop(data: OfficeSummary[]) {
    this.officesList = data;

    // If there is a value for the office transfer ID, then things are out-of-sync.
    if (this.participantDetails != null && this.participantDetails.officeTransferId != null && this.participantDetails.officeTransferId > 0) {
      // We have CWW setting the default office for W-2.
      if (
        this.model.enrolledW2Program != null &&
        +this.model.enrolledW2Program.id === +this.programId &&
        this.model.enrolledW2Program.officeNumber !== this.participantDetails.officeTransferNumber // We need to ignore when the W2 Office Number matches the office transfer #
      ) {
        this.workProgramOfficeId = this.participantDetails.officeTransferId;
        this.originalWorkProgramOfficeId = this.participantDetails.officeTransferId;
      }

      if (this.workProgramOfficeId > 0) {
        this.preCheck();
        this.loadWorkers(this.workProgramOfficeId);
      }
    }

    if (data != null) {
      for (const o of data) {
        const dd = new DropDownField();
        dd.id = o.id;
        const officePadded = new PadPipe().transform(o.officeNumber, 4);
        dd.name = o.countyName + ' - ' + officePadded.toString();
        this.officeDrop.push(dd);
      }
    }
  }

  private initWorkerDrop(data: AgencyWorker[]) {
    this.workerDrop = [];
    if (data != null) {
      for (const item of data) {
        const dd = new DropDownField();
        dd.id = item.id;
        dd.name = item.fullNameWithMiddleInitialTitleCase;
        dd.code = item.workerId;
        this.workerDrop.push(dd);
      }
    }
    this.assignFep();
  }

  initProgramDrop() {
    let eps = this.model.getTransferableProgramsByAgency(this.appService.user.agencyCode);
    eps = this.appService.filterProgramsForUserAuthorized<EnrolledProgram>(eps);

    if (eps != null) {
      for (const ep of eps) {
        const dd = new DropDownField();
        dd.id = ep.id;
        dd.name = ep.programCode;
        this.programDrop.push(dd);
      }
    }

    this.pepW2Id = Utilities.idByFieldDataName('W-2', this.programDrop);
    this.pepTJId = Utilities.idByFieldDataName('Transitional Jobs', this.programDrop);
    this.pepLFId = Utilities.idByFieldDataName('Learnfare', this.programDrop);
    this.pepCFId = Utilities.idByFieldDataName('Children First', this.programDrop);
    this.pepTmjId = Utilities.idByFieldDataName('Transform Milwaukee Jobs', this.programDrop);
    // If only one program we set the default on the disabled dropdown.
    if (this.programDrop != null && this.programDrop.length === 1) {
      this.programId = this.programDrop[0].id;
      this.isProgramDropDisabled = true;
      // set originalProgramId.
      this.originalProgramId = this.programId;
      this.loadOffices();
    }
  }

  private initPart(data) {
    this.model = data;
  }

  private initDetailsParticipant(partDetails: ParticipantDetails) {
    this.participantDetails = partDetails;
  }

  assignFep() {
    if (this.participantDetails) {
      if (this.participantDetails.cwwTransferDetails.fepOutOfSync) {
        if (this.participantDetails.cwwTransferDetails.newFepId) {
          const cwwAssignedFep = this.workerDrop.find(x => x.code === this.participantDetails.cwwTransferDetails.newFepId);
          this.workerId = cwwAssignedFep.id;
        }
      } else {
        this.isRequired = true;
        if (this.participantDetails.cwwTransferDetails.newFepId) {
          const cwwAssignedFep = this.workerDrop.find(x => x.code === this.participantDetails.cwwTransferDetails.newFepId);
          this.workerId = cwwAssignedFep.id;
        }
      }
    }
  }

  saveAndExit() {
    if (this.isValid !== true) {
      return;
    }
    this.isSaving = true;

    // Post cleansed Model.
    const model = this.cleansedModel();

    this.model.programById(this.programId).officeId = this.workProgramOfficeId;
    this.model.programById(this.programId).assignedWorker.id = this.workerId;

    this.partService.transferParticipant(this.pin, model).subscribe(
      data => {
        this.partService.clearCachedParticipant();
        this.exit();
      },
      error => {
        this.isSaving = false;
        this.hadSaveError = true;
      }
    );
  }

  /**
   * Cleanse before we send model to api.
   *
   * @private
   * @memberof TransferComponent
   */
  private cleansedModel(): EnrolledProgram {
    // Create Post Model.
    const model = this.model.programById(this.programId);
    const postModel = new EnrolledProgram();
    EnrolledProgram.clone(model, postModel);

    // Set Model for precheck.
    postModel.officeId = this.workProgramOfficeId;
    postModel.assignedWorker.id = this.workerId;

    const selectedOffice = this.officesList.find(x => +x.id === +this.workProgramOfficeId);

    if (selectedOffice != null) {
      postModel.officeNumber = selectedOffice.officeNumber;
    } else {
      console.warn('Office not found');
    }

    return postModel;
  }

  preCheck() {
    this.precheckMsgs = null;
    this.isPrecheckLoading = true;
    this.preCheckError = false;

    // Post cleansed Model.
    const model = this.cleansedModel();

    this.preSub = this.partService.canTransferParticipant(this.pin, model).subscribe(
      data => {
        this.initPreCheckStatus(data);
        this.isPrecheckLoading = false;
      },
      error => {
        this.isPrecheckLoading = false;
        this.preCheckError = true;
        this.isSaveAble = false;
      }
    );
  }

  initPreCheckStatus(data) {
    this.precheckMsgs = data;
    this.validate();
  }

  validate() {
    if (this.workProgramOfficeId != null && this.workProgramOfficeId > 0 && this.precheckMsgs != null && this.precheckMsgs.status === true) {
      this.isValid = true;
    } else {
      this.isValid = false;
    }
  }

  ngOnDestroy() {
    if (this.officeSub != null) {
      this.officeSub.unsubscribe();
    }
    if (this.workerSub != null) {
      this.workerSub.unsubscribe();
    }
    if (this.preSub != null) {
      this.preSub.unsubscribe();
    }
  }
}
