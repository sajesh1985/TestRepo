import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { DestroyableComponent } from '../../shared/modal/index';
import { ModalBase } from '../../shared/modal/modal-base';
import { DropDownField } from '../../shared/models/dropdown-field';
import { AgencyService } from '../../shared/services/agency.service';
import { AgencyWorker } from '../../shared/models/agency-worker';
import { AppService } from '../../shared/services/app.service';
import { ParticipantService } from '../../shared/services/participant.service';
import { Participant } from '../../shared/models/participant';
import { EnrolledProgram } from '../../shared/models/enrolled-program.model';
import { Utilities } from '../../shared/utilities';

@Component({
  selector: 'app-reassign',
  templateUrl: './reassign.component.html',
  styleUrls: ['./../../shared/modal/modal-placeholder/modal-placeholder.component.css', './reassign.component.css'],
  providers: [AgencyService]
})
export class ReassignComponent extends ModalBase implements OnInit, DestroyableComponent, OnDestroy {
  public workerDrop: DropDownField[] = [];
  public isLoaded = false;
  public pin: string;
  public hadSaveError = false;
  public isSaving = false;
  public isSaveAble = false;
  public model: Participant;
  public programDrop: DropDownField[] = [];
  public selectedWorkerId: number;
  public selectedProgram: EnrolledProgram;
  public selectedProgramNameDisabled = false;
  public selectedProgramName: string;
  public originalSelectedProgramName: string;
  private wSub: Subscription;
  private partSub: Subscription;
  public workerId = null;
  public originalWorkerId = null;
  public pepW2Id = 0;
  public pepTJId = 0;
  public pepLFId = 0;
  public pepCFId = 0;
  public pepTmjId = 0;

  public isProgramDropDisabled = false;
  public programId = null;
  public originalProgramId = null;

  constructor(private agencyService: AgencyService, private appService: AppService, private partService: ParticipantService) {
    super();
  }

  ngOnInit() {
    this.partSub = this.partService.getParticipant(this.pin).subscribe(part => {
      this.initPart(part);
    });
  }

  initPart(data: Participant) {
    this.model = data;

    if (this.model.programs == null) {
      this.model.programs = [];
    }

    this.initProgramDrop();
    this.isLoaded = true;
  }

  saveAndExit() {
    this.isSaving = true;
    this.hadSaveError = false;

    // Find the program that is selected.
    const program = this.model.programs.find(x => x.id === this.programId);

    // Update the assigned worker to the selected one.
    program.assignedWorker.id = this.workerId;

    this.partService.reassignParticipant(program).subscribe(
      data => {
        this.partService.clearCachedParticipant();
        this.exit();
      },
      error => {
        this.isSaving = false;
        this.hadSaveError = true;
      }
    );
  }

  ngOnDestroy() {
    if (this.wSub != null) {
      this.wSub.unsubscribe();
    }

    if (this.partSub != null) {
      this.partSub.unsubscribe();
    }
  }

  initProgramDrop() {
    this.programDrop = [];

    let eps = this.model.getCurrentEnrolledProgramsByAgency(this.appService.user.agencyCode);
    eps = this.appService.filterProgramsForUserAuthorized<EnrolledProgram>(eps);

    if (eps != null) {
      for (const ep of eps) {
        const dd = new DropDownField();
        dd.id = ep.id;
        dd.name = ep.programCode;
        this.programDrop.push(dd);
      }
    }

    this.pepW2Id = Utilities.idByFieldDataName('W-2', this.programDrop);
    this.pepTJId = Utilities.idByFieldDataName('Transitional Jobs', this.programDrop);
    this.pepLFId = Utilities.idByFieldDataName('Learnfare', this.programDrop);
    this.pepCFId = Utilities.idByFieldDataName('Children First', this.programDrop);
    this.pepTmjId = Utilities.idByFieldDataName('Transform Milwaukee Jobs', this.programDrop);

    // If only one program we set the default on the disabled dropdown.
    if (this.programDrop != null && this.programDrop.length === 1) {
      this.programId = this.programDrop[0].id;
      this.isProgramDropDisabled = true;
      this.originalProgramId = this.programId;
      this.programChange();
    }
  }

  private initWorkerDrop(data: AgencyWorker[]) {
    this.workerDrop = [];

    if (data != null && data.length > 0) {
      // sort
      for (const item of data) {
        const dd = new DropDownField();
        dd.id = item.id;
        dd.name = item.fullNameWithMiddleInitialTitleCase;
        this.workerDrop.push(dd);
      }
    }
  }

  loadWorkers($event) {
    if (this.programId == null || this.programId === 0) {
      return;
    }

    const program = this.model.programs.find(x => x.id === this.programId);

    this.wSub = this.agencyService.getAgencyWorkersByAgencyCodeAndProgramCode(program.agencyCode, program.programCd).subscribe(data => {
      this.initWorkerDrop(data);
    });
  }

  programChange() {
    // Reset all data.
    this.isSaveAble = false;
    this.workerId = null;
    this.originalWorkerId = null;
    this.workerDrop = [];

    if (this.programId > 0) {
      this.loadWorkers(this.programId);
    }
  }

  workerChange($event) {
    this.workerId = $event;

    if (this.programId == null || this.programId === 0 || this.workerId == null) {
      this.isSaveAble = false;
    } else {
      this.isSaveAble = true;
    }
  }
}
