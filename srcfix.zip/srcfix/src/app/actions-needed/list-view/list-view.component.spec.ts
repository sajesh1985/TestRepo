// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ActionNeededListViewComponent } from './list-view.component';

// describe('ListComponent', () => {
//   let component: ActionNeededListViewComponent;
//   let fixture: ComponentFixture<ActionNeededListViewComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ActionNeededListViewComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ActionNeededListViewComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
