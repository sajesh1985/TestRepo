/* tslint:disable:no-unused-variable */
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { By } from '@angular/platform-browser';
// import { DebugElement } from '@angular/core';

// import { DateMmDdYyyyComponent } from './date-mm-dd-yyyy.component';

// describe('DateMmDdYyyyComponent', () => {
//   let component: DateMmDdYyyyComponent;
//   let fixture: ComponentFixture<DateMmDdYyyyComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DateMmDdYyyyComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DateMmDdYyyyComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
