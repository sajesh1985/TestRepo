// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { YesNoRefuseComponent } from './yes-no-refuse.component';

// describe('YesNoRefuseComponent', () => {
//   let component: YesNoRefuseComponent;
//   let fixture: ComponentFixture<YesNoRefuseComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ YesNoRefuseComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(YesNoRefuseComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
