/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { SelectComponent } from './select.component';

// describe('Component: Select', () => {
//   it('should create an instance', () => {
//     let component = new SelectComponent();
//     expect(component).toBeTruthy();
//   });
// });
