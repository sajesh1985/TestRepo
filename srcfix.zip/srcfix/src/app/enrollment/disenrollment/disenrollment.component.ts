import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { DestroyableComponent } from '../../shared/modal/index';
import { DropDownField } from '../../shared/models/dropdown-field';
import { ModalBase } from '../../shared/modal/modal-base';
import { AgencyWorker } from '../../shared/models/agency-worker';
import { AppService } from '../../shared/services/app.service';
import { ParticipantService } from '../../shared/services/participant.service';
import { FieldDataService } from '../../shared/services/field-data.service';
import { Participant } from '../../shared/models/participant';
import { AssignedWorker } from '../../shared/models/assigned-worker.model';
import { WhyReason } from '../../shared/models/why-reasons.model';
import { EnrolledProgram } from '../../shared/models/enrolled-program.model';
import { Utilities } from '../../shared/utilities';
import { ModelErrors } from '../../shared/interfaces/model-errors';
import { ValidationCode, } from '../../shared/models/validation-error';
import { ValidationManager } from '../../shared/models/validation-manager';

@Component({
  selector: 'app-disenrollment',
  templateUrl: './disenrollment.component.html',
  styleUrls: ['./../../shared/modal/modal-placeholder/modal-placeholder.component.css', './disenrollment.component.css'],
  providers: [FieldDataService]
})
export class DisenrollmentComponent extends ModalBase implements OnInit, OnDestroy, DestroyableComponent {

  public title = 'Disenroll';
  public isLoaded = false;
  public isModified = false;
  public pin: string;
  public preCheckError = false;
  public hadSaveError = false;
  private isModelValid = false;
  public isSaving = false;
  public isSaveAble = false;
  public isPrecheckLoading = false;
  public participant: Participant;
  public disenrollmentEligibility: WhyReason;
  public programDrop: DropDownField[] = [];
  public completionReasonsDrop: DropDownField[] = [];
  public selectedProgramName: string;
  public originalSelectedProgramName: string;
  public model: EnrolledProgram;
  public originalModel: EnrolledProgram;
  public selectedProgramNameDisabled = false;
  private partSub: Subscription;
  private preSub: Subscription;
  private cloneModelString: string;

  public validationManager: ValidationManager = new ValidationManager(this.appService);
  public modelErrors: ModelErrors = {};   // Note: this must be initialized to an empty object for the UI in initial state.

  constructor(private appService: AppService, private partService: ParticipantService,
    private fieldDataService: FieldDataService) { super(); }

  ngOnInit() {
    this.partSub = this.partService.getParticipant(this.pin).subscribe(data => {
      this.initPart(data);
      this.initProgramsDrop();
      this.isLoaded = true;
    });
  }

  initProgramsDrop() {
    this.programDrop = [];
    if (this.participant != null && this.participant.programs != null) {
      let refPrograms = this.participant.getCurrentEnrolledProgramsByAgency(this.appService.user.agencyCode);
      refPrograms = this.appService.filterProgramsForUserAuthorized(refPrograms);

      if (refPrograms != null) {
        for (const pro of refPrograms) {
          const x = new DropDownField();
          x.id = pro.programCode;
          x.name = pro.programCode;
          this.programDrop.push(x);
        }
      }

      if (this.programDrop.length === 1) {
        this.selectedProgramNameDisabled = true;
        this.selectedProgramName = this.programDrop[0].id;
        this.programChange();
      }
    }
  }

  initEnrollStatus(data: WhyReason) {
    this.disenrollmentEligibility = data;
    this.validate();
  }

  initPart(data: Participant) {
    this.participant = data;
  }

  validate() {
    this.validationManager.resetErrors();
    let precheckStatus = true;
    if (this.disenrollmentEligibility == null || this.disenrollmentEligibility.status !== true) {
      precheckStatus = false;
    }
    const result = EnrolledProgram.disenrollmentValidate(this.model, this.selectedProgramName, this.validationManager, this.disenrollmentEligibility);
    // Update our properties so the UI can bind to the results.
    this.modelErrors = result.errors;

    this.isSaveAble = result.isValid;
  }

  programChange() {
    this.resetForm();

    if (Utilities.isStringEmptyOrNull(this.selectedProgramName)) {
      return;
    }

    this.model = this.getWorkingPep();
    if (this.model.isCFTmjTJProgram) {
      this.loadCompletionReasons();
    }
    this.preDisenrollCheck();
  }

  preDisenrollCheck() {
    this.isPrecheckLoading = true;
    this.preCheckError = false;
    this.preSub = this.partService.canDisenrollParticipant(this.pin,
      this.participant.currentEnrolledProgramByName(this.selectedProgramName).id).subscribe(data => {
        this.initEnrollStatus(data);
        this.isPrecheckLoading = false;
      },
      error => {
        this.isPrecheckLoading = false;
        this.preCheckError = true;
        this.isSaveAble = false;
      });
  }

  saveAndExit() {
    this.isSaving = true;
    this.hadSaveError = false;
    this.partService.disenrollParticipant(this.participant.currentEnrolledProgramByName(this.selectedProgramName)).subscribe(data => {
      this.partService.clearCachedParticipant();
      this.exit();
    },
      error => {
        this.isSaving = false;
        this.hadSaveError = true;
      });
  }

  resetForm() {
    this.model = null;
    this.isSaveAble = false;
    this.disenrollmentEligibility = null;
  }

  ngOnDestroy() {
    if (this.partSub != null) {
      this.partSub.unsubscribe();
    }
    if (this.preSub != null) {
      this.preSub.unsubscribe();
    }
  }

  private getWorkingPep(): EnrolledProgram {
    return this.participant.currentEnrolledProgramByName(this.selectedProgramName);
  }

  private loadCompletionReasons() {
    this.fieldDataService.getCompletionReasons(this.model.programCd).subscribe(data => this.initCompletion(data));
  }

  private initCompletion(data) {
    this.completionReasonsDrop = data;
    this.model.otherCompletionReasonId = Utilities.idByFieldDataName('Unsuccessful participation: Other', data);
  }
}
