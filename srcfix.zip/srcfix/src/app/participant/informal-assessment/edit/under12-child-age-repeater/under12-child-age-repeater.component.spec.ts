/* tslint:disable:no-unused-variable */
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { By } from '@angular/platform-browser';
// import { DebugElement } from '@angular/core';

// import { Under12ChildAgeRepeaterComponent } from './under12-child-age-repeater.component';

// describe('Under12ChildAgeRepeaterComponent', () => {
//   let component: Under12ChildAgeRepeaterComponent;
//   let fixture: ComponentFixture<Under12ChildAgeRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ Under12ChildAgeRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(Under12ChildAgeRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
