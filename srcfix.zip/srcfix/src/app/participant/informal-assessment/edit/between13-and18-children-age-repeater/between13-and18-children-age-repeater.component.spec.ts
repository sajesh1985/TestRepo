/* tslint:disable:no-unused-variable */
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { By } from '@angular/platform-browser';
// import { DebugElement } from '@angular/core';

// import { Between13And18ChildrenAgeRepeaterComponent } from './between13-and18-children-age-repeater.component';

// describe('Between13And18ChildrenAgeRepeaterComponent', () => {
//   let component: Between13And18ChildrenAgeRepeaterComponent;
//   let fixture: ComponentFixture<Between13And18ChildrenAgeRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ Between13And18ChildrenAgeRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(Between13And18ChildrenAgeRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
