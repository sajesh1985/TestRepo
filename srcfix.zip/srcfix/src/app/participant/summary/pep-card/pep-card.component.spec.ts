// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PepCardComponent } from './pep-card.component';

// describe('PepCardComponent', () => {
//   let component: PepCardComponent;
//   let fixture: ComponentFixture<PepCardComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PepCardComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PepCardComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
