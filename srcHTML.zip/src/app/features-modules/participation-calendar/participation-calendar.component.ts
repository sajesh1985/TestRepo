import { Participant } from './../../shared/models/participant';
import { Component, OnInit } from '@angular/core';

import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { take, concatMap } from 'rxjs/operators';
import { ParticipationTracking } from './models/participation-tracking.model';
import { AppService } from 'src/app/core/services/app.service';
import { ParticipantService } from 'src/app/shared/services/participant.service';
import { ParticipationTrackingService } from './services/participation-tracking.service';

@Component({
  selector: 'app-participation-calendar',
  templateUrl: './participation-calendar.component.html',
  styleUrls: ['./participation-calendar.component.scss']
})
export class ParticipationCalendarComponent implements OnInit {
  public showCalendar = true;
  public momentDate = moment(new Date()).toDate();
  public viewDate: any;
  public events: any;

  public PTDetails: ParticipationTracking[];
  public participantId: number;
  public goBackUrl: string;
  public pin;
  public iseventsLoaded = false;

  // set this to true if you want to load Participation Entry page.
  public isPEEnabled = false;
  public singlePTEvent: any;
  public participant: Participant;

  constructor(private route: ActivatedRoute, private appService: AppService, private partService: ParticipantService, private ptService: ParticipationTrackingService) {}

  ngOnInit() {
    this.route.params
      .pipe(
        concatMap(result => {
          this.pin = result.pin;
          this.goBackUrl = '/pin/' + this.pin;
          return this.partService.getCachedParticipant(this.pin);
        })
      )
      .subscribe(res => {
        this.participant = res;
        this.participantId = res.id;
        if (moment().date() < 16) {
          this.momentDate = moment(this.momentDate)
            .subtract(1, 'M')
            .toDate();
        }
        this.ptService.viewDate.next({ viewDate: moment(new Date(this.momentDate.getFullYear(), this.momentDate.getMonth(), 16)).toDate() });
        this.getEvents();
      });
    this.ptService.modeForParticipationEntry.subscribe(res => {
      this.isPEEnabled = res.inEditView;
    });
  }

  showCalendarView() {
    this.showCalendar = !this.showCalendar;
  }
  closeCalendar(e: boolean) {
    this.showCalendar = e;
    this.ptService.viewDate.next({ viewDate: moment(new Date(this.momentDate.getFullYear(), this.momentDate.getMonth(), 16)).toDate() });
  }
  nextMonthClicked(e) {
    this.ptService.viewDate.next({ viewDate: e });
    this.getEvents();
  }
  previousMonthClicked(e) {
    this.ptService.viewDate.next({ viewDate: e });
    this.getEvents();
  }
  getEvents() {
    let startDate;
    let endDate;
    this.ptService.viewDate.subscribe(res => {
      this.viewDate = res.viewDate;
      startDate = moment(res.viewDate).format('MMDDYYYY');
      // ToDo: subtract one day here
      endDate = moment(this.viewDate)
        .add(1, 'M')
        .subtract(1, 'day')
        .format('MMDDYYYY');
    });
    this.ptService.getParticipationTrackingDetails(this.pin, this.participantId, startDate, endDate).subscribe(res => {
      this.iseventsLoaded = true;
      this.events = res;
    });
  }
  loadPE(e) {
    this.singlePTEvent = e;
    this.ptService.modeForParticipationEntry.next({ readOnly: false, inEditView: true });
  }
}
