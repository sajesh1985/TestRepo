export class ParticipationMakeup {
  public MakeupDate: Date;
  public MakeupHours: number;
}
