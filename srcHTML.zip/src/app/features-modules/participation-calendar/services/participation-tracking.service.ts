import { AppService } from 'src/app/core/services/app.service';
import { LogService } from './../../../shared/services/log.service';
import { BaseService } from 'src/app/core/services/base.service';
import { Injectable } from '@angular/core';
import { ParticipationTracking } from '../models/participation-tracking.model';
import { AuthHttpClient } from 'src/app/core/interceptors/AuthHttpClient';
import { catchError, map } from 'rxjs/operators';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ParticipationTrackingService extends BaseService {
  private PTUrl: string;
  public momentDate = moment(new Date()).toDate();
  // this is  only for Participation Tracking.
  public viewDate: any = new BehaviorSubject<any>({ viewDate: moment(new Date(this.momentDate.getFullYear(), this.momentDate.getMonth(), 16)).toDate() });
  public modeForParticipationEntry = new BehaviorSubject<any>({ readOnly: false, inEditView: false });
  constructor(http: AuthHttpClient, logService: LogService, private appService: AppService) {
    super(http, logService);
    this.PTUrl = this.appService.apiServer + 'api/participation-tracking/';
  }

  getParticipationTrackingDetails(pin, participantId, startDate, endDate) {
    return this.http.get(`${this.PTUrl}${pin}/${participantId}/${startDate}/${endDate}`).pipe(map(this.extractPTData), catchError(this.handleError));
  }

  private extractPTData(res: ParticipationTracking[]): ParticipationTracking[] | null {
    const jsonObs = res as ParticipationTracking[];

    return jsonObs || null;
  }
}
