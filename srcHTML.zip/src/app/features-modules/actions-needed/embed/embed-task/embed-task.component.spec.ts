// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EmbedTaskComponent } from './embed-task.component';

// describe('EmbedTaskComponent', () => {
//   let component: EmbedTaskComponent;
//   let fixture: ComponentFixture<EmbedTaskComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EmbedTaskComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EmbedTaskComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
