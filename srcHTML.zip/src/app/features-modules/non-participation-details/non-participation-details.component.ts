import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { forkJoin } from 'rxjs';
import { take, concatMap } from 'rxjs/operators';
import { ParticipationTrackingService } from '../participation-calendar/services/participation-tracking.service';
import { ParticipantService } from 'src/app/shared/services/participant.service';
import * as moment from 'moment';
import { ParticipationTracking } from '../participation-calendar/models/participation-tracking.model';

@Component({
  selector: 'app-non-participation-details',
  templateUrl: './non-participation-details.component.html',
  styleUrls: ['./non-participation-details.component.scss']
})
export class NonParticipationDetailsComponent implements OnInit {
  
  @Output() closeDetails = new EventEmitter<any>();

  public events: any;
  public goBackUrl: string = '';
  public pageTitle: string = 'Non-Participation/Good Cause Details';
  public pin;
  public viewDate: any;
  public PTDetails: ParticipationTracking[];
  public isLoaded = true;
  public participantId: number;
  public momentDate = moment(new Date()).toDate();
  public iseventsLoaded = false;
  public headerMonth = moment().format('MMMM');
  public headerNextMonth;
  public isPTPeriod = false;

  constructor(private route: ActivatedRoute, private partService: ParticipantService, private ptService: ParticipationTrackingService) {}

  ngOnInit() {
    this.route.params
      .pipe(
        concatMap(result => {
          this.pin = result.pin;                  
          this.goBackUrl = '/pin/' + this.pin;
          return this.partService.getCachedParticipant(this.pin);
        })
      )
      .subscribe(res => {
        this.participantId = res.id;
        if (moment().date() < 16) {
          this.momentDate = moment(this.momentDate)
            .subtract(1, 'M')
            .toDate();
        }
        this.viewDate = moment(new Date(this.momentDate.getFullYear(), this.momentDate.getMonth(), 16)).toDate();        
        this.getData();
      });
  } 

  nextClicked(e) {
    this.viewDate = moment(this.viewDate)
      .add(1, 'M')
      .toDate();
    this.headerMonth = moment(this.viewDate).format('MMMM');
    this.getData();   

  }
  previousClicked(e) {
    this.viewDate = moment(this.viewDate)
      .subtract(1, 'M')
      .toDate();
    this.headerMonth = moment(this.viewDate).format('MMMM');
    this.getData();
  }
  
  close() {
    this.closeDetails.emit(false);
  }

  getData() {
    let startDate;
    let endDate;    
      
      startDate = moment(this.viewDate).format('MMDDYYYY');
      // ToDo: subtract one day here
      endDate = moment(this.viewDate)
        .add(1, 'M')
        .format('MMDDYYYY');
      this.headerMonth = moment(this.viewDate).format('MMMM');
      this.headerNextMonth = moment(this.viewDate).add(1, 'M').format('MMMM'); 

    
    this.ptService.getParticipationTrackingDetails(this.pin, this.participantId, startDate, endDate).subscribe(res => {
      this.iseventsLoaded = true;
      this.events = res;
    });
  }
}
