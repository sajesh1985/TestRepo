// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AliasSsnRepeaterComponent } from './alias-ssn-repeater.component';

// describe('AliasSsnRepeaterComponent', () => {
//   let component: AliasSsnRepeaterComponent;
//   let fixture: ComponentFixture<AliasSsnRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AliasSsnRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AliasSsnRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
