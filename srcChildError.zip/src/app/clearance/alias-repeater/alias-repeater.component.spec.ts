// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AliasRepeaterComponent } from './alias-repeater.component';

// describe('AliasRepeaterComponent', () => {
//   let component: AliasRepeaterComponent;
//   let fixture: ComponentFixture<AliasRepeaterComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AliasRepeaterComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AliasRepeaterComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
