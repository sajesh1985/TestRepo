// tslint:disable: no-use-before-declare
import { FinalistAddress } from '../../../shared/models/finalist-address.model';
import { Utilities } from '../../../shared/utilities';
import { ValidationManager, ValidationResult, ValidationCode } from 'src/app/shared/models/validation';

export class OrganizationInformation {
  public id: number;
  public programId: number;
  public programName: string;
  public organizationId: number;
  public organizationName: string;
  public locations: FinalistLocation[];
  public modifiedBy: string;
  public modifiedDate: string;

  public static clone(input: any, instance: OrganizationInformation) {
    instance.id = input.id;
    instance.programId = input.programId;
    instance.programName = input.programName;
    instance.organizationId = input.organizationId;
    instance.organizationName = input.organizationName;
    instance.locations = Utilities.deserilizeChildren(input.locations, FinalistLocation, 0);
    instance.modifiedBy = input.modifiedBy;
    instance.modifiedDate = input.modifiedDate;
  }

  public static create(): OrganizationInformation {
    const obj = new OrganizationInformation();
    return obj;
  }

  public deserialize(input: any) {
    OrganizationInformation.clone(input, this);
    return this;
  }
}

export class FinalistLocation {
  public id: number;
  public finalistAddress: FinalistAddress;
  public effectiveDate: string;
  public endDate: string;

  public static clone(input: any, instance: FinalistLocation) {
    instance.id=input.id;
    instance.finalistAddress = Utilities.deserilizeChild(input.finalistAddress, FinalistAddress);
    instance.effectiveDate = input.effectiveDate;
    instance.endDate = input.endDate;
  }

  public static create(): FinalistLocation {
    const obj = new FinalistLocation();
    obj.id = 0;
    return obj;
  }

  public deserialize(input: any) {
    FinalistLocation.clone(input, this);
    return this;
  }

  public validate(validationManager: ValidationManager): ValidationResult {
    const result = new ValidationResult();
    if (this.effectiveDate == null || this.effectiveDate.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Effective Date is required.');
    result.addError('effectiveDate');
    }

    if (this.endDate == null || this.endDate.toString() === '') {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'End Date is required');
      result.addError('endDate');
    }

    if(this.finalistAddress)
    {
      if (this.finalistAddress.addressLine1 == null || this.finalistAddress.addressLine1.toString() === '') {
        validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Address Line is required');
        result.addError('addressLine1');
      }
      if (this.finalistAddress.city == null || this.finalistAddress.city.toString() === '') {
        validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'City is required');
        result.addError('city');
      }
      if (this.finalistAddress.zip == null || this.finalistAddress.zip.toString() === '') {
        validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Zip is required');
        result.addError('zip');
      }
    }
    else
    {
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Address Line is required');
      result.addError('addressLine1');
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'City is required');
      result.addError('city');
      validationManager.addErrorWithDetail(ValidationCode.RequiredInformationMissing_Details, 'Zip is required');
      result.addError('zip');
    }

    return result;
  }

  public clear(): void {
    this.finalistAddress = null;
    this.effectiveDate = null;
    this.endDate = null;
  }

  public isEmpty(): boolean {
    return !this.finalistAddress && (this.effectiveDate === null || this.effectiveDate.trim() === '') && (this.endDate === null || this.endDate.trim() === '');
  }
}
