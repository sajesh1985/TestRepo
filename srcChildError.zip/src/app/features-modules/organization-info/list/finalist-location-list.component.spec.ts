// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { PinCommentsListComponent } from './finalist-location-list.component';

// describe('PinCommentsListComponent', () => {
//   let component: PinCommentsListComponent;
//   let fixture: ComponentFixture<PinCommentsListComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [PinCommentsListComponent]
//     }).compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PinCommentsListComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
