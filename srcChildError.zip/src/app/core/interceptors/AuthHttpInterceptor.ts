import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError as observableThrowError } from 'rxjs';

import { AuthHttpClient } from './AuthHttpClient';

@Injectable({
  providedIn: 'root'
})
export class AuthHttpInterceptor implements HttpInterceptor {
  constructor(private authHttpClient: AuthHttpClient) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    //const jwt = this.authService.getAuthToken();

    const jwt = localStorage.getItem('token');
    let tokenExpired: boolean = false;
    if (!(request.url.indexOf('auth/status') > -1)) {
      tokenExpired = this.authHttpClient.requestWithToken(request, jwt);
    }

    if (jwt && !tokenExpired) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${jwt}`
        },
        withCredentials: false
      });
    }
    return next.handle(request);
  }
}
