/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { DegreeRepeaterComponent } from './degree-repeater.component';

// describe('Component: DegreeRepeater', () => {
//   it('should create an instance', () => {
//     let component = new DegreeRepeaterComponent();
//     expect(component).toBeTruthy();
//   });
// });
