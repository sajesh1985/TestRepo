import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

// import { Authorization } from './shared/models/authorization';
// import { ChildYouthSupportsEditComponent } from './participant/informal-assessment/edit/child-youth-supports.component';
// import { ContactDetailComponent } from './contacts/detail/detail.component';
// import { ContactsListPageComponent } from './contacts/list-page/list-page.component';
import { HomePageComponent } from "./home-page/home-page.component";
// import { EditComponent as EditInformalAssessmentComponent } from './participant/informal-assessment/edit/edit.component';
// import { EducationHistoryEditComponent } from './participant/informal-assessment/edit/education-history.component';
// import { FamilyBarriersEditComponent } from './participant/informal-assessment/edit/family-barriers.component';
// import { HousingEditComponent } from './participant/informal-assessment/edit/housing.component';
// import { LanguagesEditComponent } from './participant/informal-assessment/edit/languages.component';
// import { LegalIssuesEditComponent } from './participant/informal-assessment/edit/legal-issues.component';
import { LoginComponent } from "./login/login.component";
import { LogoutComponent } from "./logout/logout.component";
// import { MilitaryTrainingEditComponent } from './participant/informal-assessment/edit/military-training.component';
// import { ParticipantBarriersEditComponent } from './participant/informal-assessment/edit/participant-barriers.component';
// import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
// import { ParticipantBarriersListPageComponent } from './participant-barriers/list-page/list-page.component';
// import { PostSecondaryEducationEditComponent } from './participant/informal-assessment/edit/post-secondary-education.component';
// import { ReleaseNotesComponent } from './release-notes/release-notes.component';
import { PageHelpComponent } from './help/help.component';
import { StartComponent } from "./start/start.component";
// import { SummaryComponent as InformalAssessmentSummaryComponent } from './participant/informal-assessment/summary/summary.component';
import { SummaryComponent as ParticipantSummaryComponent } from "./participant/summary/summary.component";
// import { TestScoresListPageComponent } from './test-scores/list-page/list-page.component';
// import { TransportationEditComponent } from './participant/informal-assessment/edit/transportation.component';
// import { WorkHistoryGatepostEditComponent } from './participant/informal-assessment/edit/work-history.component';
// import { WorkHistoryListPageComponent } from './work-history/list-page/list-page.component';
// import { WorkProgramsEditComponent } from './participant/informal-assessment/edit/work-programs.component';
// import { WorkHistorySingleComponent } from './work-history/single/single.component';
import { SummaryComponent as TimeLimitsSummaryComponent } from "./time-limits/summary/summary.component";
import { ExtensionListPageComponent } from "./time-limits/extensions/list-page/list-page.component";
import { ExtensionDetailComponent } from "./time-limits/extensions/detail/detail.component";
//import { SearchComponent as TimelimitsSearchComponent } from "./time-limits/search/search.component";
// import { ParticipantBarriersSingleComponent } from './participant-barriers/single/single.component';
// import { NcpEditComponent } from './participant/informal-assessment/edit/ncp.component';
// import { NcprEditComponent } from './participant/informal-assessment/edit/ncpr.component';
// import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
// import { ActionsNeededComponent } from './actions-needed/actions-needed.component';
// import { ClearanceComponent } from './clearance/clearance.component';
// import { ParticipantService } from './shared/services/participant.service';
// import { RfaPageComponent } from './rfa/page/page.component';
// import { RfaSingleComponent } from './rfa/single/single.component';
// import { ReportsComponent } from './webi/reports/reports.component';
// import { WorkHistoryAppGuard } from './shared/guards/work-history-app.guard';
import { TimeLimitsAppGuard } from "./shared/guards/time-limits-app.guard";
import { ParticipantGuard } from "./shared/guards/participant-guard";
import { CoreAccessGuard } from "./shared/guards/core-access-guard";
// import { ClientRegistrationGuard } from './shared/guards/client-registration-guard';
// import { InformalAssessmentGuard } from './shared/guards/informal-assessment-guard';
// import { ParticipantBarriersAppGuard } from './shared/guards/participant-barriers-app-guard';
import { AuthGuard } from "./shared/guards/auth-guard";
// import { RegistrationComponent } from './enrollment/registration/registration.component';

const appRoutes: Routes = [
  { path: "", redirectTo: "/start", pathMatch: "full" },
  { path: "start", component: StartComponent },
  { path: "login", component: LoginComponent },
  { path: "logout", component: LogoutComponent },
  // { path: 'unauthorized', component: UnauthorizedComponent },
  { path: "home", component: HomePageComponent, canActivate: [AuthGuard] },
  //{ path: 'home', component: HomePageComponent },
  //{ path: 'home/:pin', component: HomePageComponent, canActivate: [AuthGuard] },   // this used to be the route for no-access
  // { path: 'release-notes', component: ReleaseNotesComponent },
  { path: 'help', component: PageHelpComponent },
  // { path: 'reports', component: ReportsComponent, canActivate: [AuthGuard] },
  // { path: 'clearance',
  //   data: { authorizations: [Authorization.canAccessClearance] },
  //   component: ClearanceComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard]
  // },
  // {
  //   path: 'pin/:pin/client-registration',
  //   data: {authorizations: [Authorization.canAccessClientReg_View] },
  //   component: RegistrationComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ClientRegistrationGuard]
  // },
  // {
  //   path: 'pin/:pin/assessment/edit',
  //   // sec_page Assessment Edit
  //   // sec_usage Retricts access to any of the edit assessement functionality
  //   data: { authorizations: [Authorization.canAccessInformalAssessment_Edit] },
  //   component: EditInformalAssessmentComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
  //   canDeactivate: [InformalAssessmentGuard],
  //   children: [
  //     {
  //       path: 'languages',
  //       component: LanguagesEditComponent
  //     },
  //     {
  //       path: 'education',
  //       component: EducationHistoryEditComponent
  //     },
  //     {
  //       path: 'post-secondary',
  //       component: PostSecondaryEducationEditComponent
  //     },
  //     {
  //       path: 'military',
  //       component: MilitaryTrainingEditComponent
  //     },
  //     {
  //       path: 'work-programs',
  //       component: WorkProgramsEditComponent
  //     },
  //     {
  //       path: 'child-youth-supports',
  //       component: ChildYouthSupportsEditComponent
  //     },
  //     {
  //       path: 'housing',
  //       component: HousingEditComponent
  //     },
  //     {
  //       path: 'legal-issues',
  //       component: LegalIssuesEditComponent
  //     },
  //     {
  //       path: 'work-history',
  //       component: WorkHistoryGatepostEditComponent
  //     },
  //     {
  //       path: 'family-barriers',
  //       component: FamilyBarriersEditComponent
  //     },
  //     {
  //       path: 'participant-barriers',
  //       component: ParticipantBarriersEditComponent
  //     },
  //     {
  //       path: 'non-custodial-parents',
  //       component: NcpEditComponent
  //     },
  //     {
  //       path: 'non-custodial-parents-referral',
  //       component: NcprEditComponent
  //     },
  //     {
  //       path: 'transportation',
  //       component: TransportationEditComponent
  //     },
  //     {
  //       path: '',
  //       component: LanguagesEditComponent
  //     }
  //   ]
  // },
  // {
  //   path: 'pin/:pin/assessment',
  //   component: InformalAssessmentSummaryComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
  //   data: { authorizations: [Authorization.canAccessInformalAssessment_View] }
  // },
  // {
  //   path: 'pin/:pin/contacts/:id',
  //   component: ContactDetailComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
  //   data: { authorizations: [Authorization.canAccessContactsApp_Edit]}
  // },
  // {
  //   path: 'pin/:pin/contacts',
  //   component: ContactsListPageComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard, ],
  //   data: { authorizations: [Authorization.canAccessContactsApp_View] }
  // },
  // { path: 'pin/:pin/test-scores',
  //   component: TestScoresListPageComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
  //   data: { authorizations: [Authorization.canAccessTestScoresApp_View] }
  // },
  // { path: 'pin/:pin/action-needed',
  //   component: ActionsNeededComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
  //   data: { authorizations: [Authorization.canAccessActionNeededApp_View] }
  // },
  // { path: 'pin/:pin/participant-barriers/:id', component: ParticipantBarriersSingleComponent, canActivate: [AuthGuard, ParticipantGuard] },
  // { path: 'pin/:pin/participant-barriers', component: ParticipantBarriersListPageComponent, canActivate: [AuthGuard, ParticipantGuard, ParticipantBarriersAppGuard] },
  {
    path: "pin/:pin/time-limits",
    component: TimeLimitsSummaryComponent,
    canActivate: [AuthGuard, ParticipantGuard, TimeLimitsAppGuard]
  },
  {
    path: "pin/:pin/time-limits/extensions",
    component: ExtensionListPageComponent,
    canActivate: [AuthGuard, ParticipantGuard, TimeLimitsAppGuard]
  },
  {
    path: "pin/:pin/time-limits/extensions/:id",
    component: ExtensionDetailComponent,
    canActivate: [AuthGuard, ParticipantGuard, TimeLimitsAppGuard]
  },
  // {
  //   path: 'pin/:pin/rfa',
  //   component: RfaPageComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
  //   data: { authorizations: [Authorization.canAccessRfa_View] }
  // },
  // {
  //   path: 'pin/:pin/rfa/:id',
  //   component: RfaSingleComponent,
  //   canActivate: [AuthGuard, CoreAccessGuard, ParticipantGuard],
  //   data: { authorizations: [Authorization.canAccessRfa_View] }
  // },
  // { path: 'pin/:pin/work-history/:id', component: WorkHistorySingleComponent, canActivate: [AuthGuard, ParticipantGuard, WorkHistoryAppGuard] },
  // { path: 'pin/:pin/work-history', component: WorkHistoryListPageComponent, canActivate: [AuthGuard, ParticipantGuard, WorkHistoryAppGuard] },
  {
    path: "pin/:pin",
    component: ParticipantSummaryComponent,
    canActivate: [AuthGuard, ParticipantGuard]
  }
  // { path: '**', component: PageNotFoundComponent }
];

export const appRoutingProviders: any[] = [
  AuthGuard,
  ParticipantGuard,
  // ClientRegistrationGuard,
  // CoreAccessGuard,
  // InformalAssessmentGuard,
  // ParticipantBarriersAppGuard,
  // ParticipantService,
  TimeLimitsAppGuard
  // WorkHistoryAppGuard
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
