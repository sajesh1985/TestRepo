import { Component, OnInit, Input } from '@angular/core';
import { Participant } from '../../shared/models/participant';
import { PinCommentsService } from '../../shared/services/pin-comments.service';
import { PinComment } from '../../shared/models/pin-comment.model';
import * as moment from 'moment';
import { SystemClockService } from '../../shared/services/system-clock.service';
import { AppService } from '../../shared/services/app.service';
import { AccessType } from '../../shared/enums/access-type.enum';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-pin-comments-list',
  templateUrl: './pin-comments-list.component.html',
  styleUrls: ['./pin-comments-list.component.scss']
})
export class PinCommentsListComponent implements OnInit {
  @Input() pin: string;
  @Input() isReadOnly = false;

  @Input() participant: Participant;

  public isInEditMode = false;
  public pinComments: PinComment[] = [];
  public localPinComments: PinComment[] = [];
  public isLoaded = false;
  public canAdd = true;
  public canView = true;
  public canEdit = false;
  public pinCommentId: number;
  private fullName: string;

  constructor(public pinCommentsService: PinCommentsService, private appService: AppService) {
  }

  ngOnInit() {
    this.pinCommentsService.modeForPinComment.subscribe(res => {
      this.pinCommentId = res.id;
      this.isInEditMode = res.isInEditMode;
      if (!this.isInEditMode) {
        this.getAllPinCommentsForPin();
      }
    });
  }

  getAllPinCommentsForPin() {
    // this.pinCommentsService.getAllPinCommentsForPin(this.pin).subscribe(res => {
    //   this.pinComments = res;
    //   console.log(res);
    //   this.isLoaded = true;
    // });
  }

  onAdd() {
    this.isInEditMode = true;
    this.pinCommentId = 0;
    this.pinCommentsService.modeForPinComment.next({ id: 0, readOnly: false, isInEditMode: this.isInEditMode });
  }

  edit(a, readOnly) {
    this.isInEditMode = true;
    this.pinCommentId = a.id;
    this.pinCommentsService.modeForPinComment.next({ id: a.id, readOnly: readOnly, isInEditMode: this.isInEditMode });
  }

  isEditable(createdDate, wiuid): boolean {
    const formattedCreatedDate = moment(createdDate).format('MM/DD/YYYY');
    if (SystemClockService.appDateTime.format('MM/DD/YYYY') === formattedCreatedDate && this.appService.user.wiuid === wiuid && this.appService.coreAccessContext.evaluate() === AccessType.edit) {
      return true;
    } else {
      return false;
    }
  }
}
