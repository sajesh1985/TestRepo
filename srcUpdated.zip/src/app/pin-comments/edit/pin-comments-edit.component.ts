import { Component, OnInit, Input } from '@angular/core';
import { ModelErrors } from '../../shared/interfaces/model-errors';
import { ValidationManager } from '../../shared/models/validation';
import { AppService } from '../../shared/services/app.service';
import { PinCommentsService } from '../../shared/services/pin-comments.service';
import { FieldDataService } from '../../shared/services/field-data.service';
import { Observable, of } from 'rxjs';
import { PinComment } from '../../shared/models/pin-comment.model';
import { PinCommentType } from '../../shared/models/pin-comment-type.model';
import { Utilities } from '../../shared/utilities';
import { DropDownField } from '../../shared/models/dropdown-field';
import { IMultiSelectSettings } from '../../shared/components/multi-select-dropdown/multi-select-dropdown.component';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-pin-comments-edit',
  templateUrl: './pin-comments-edit.component.html',
  styleUrls: ['./pin-comments-edit.component.scss']
})
export class PinCommentsEditComponent implements OnInit {
  commentTypeSettings: IMultiSelectSettings = {
    pullRight: false,
    enableSearch: false,
    checkedStyle: 'checkboxes',
    buttonClasses: 'btn btn-default',
    selectionLimit: 0,
    closeOnSelect: false,
    showCheckAll: false,
    showUncheckAll: false,
    dynamicTitleMaxItems: 3,
    maxHeight: '160px',
  };
  @Input() pinCommentId: number;

  public isSaving = false;
  public disableSave = false;
  public hasSaveError = false;
  public mode = 'Add';
  public modelErrors: ModelErrors = {};
  public isLoaded = false;
  public selectedProgramNameDisabled = false;
  public isSectionValid = false;
  public isSectionModified = false;
  public hasTriedSave = false;
  public hadSaveError = false;
  public isEnding = false;
  public sectedStatusName: string;
  public validationManager: ValidationManager = new ValidationManager(this.appService);
  public currentProgram: any;
  public pinComment: PinComment;
  public cachedModel: PinComment = new PinComment();
  public pinCommentTypesDrop: DropDownField[];
  public isReadOnly = false;

  constructor(
    private appService: AppService,
    private pinCommentsService: PinCommentsService,
    private fdService: FieldDataService
  ) {
  }

  ngOnInit() {
    if (this.pinCommentsService.participantPin) {
      this.initPinCommentModel();
    }
  }

  initPinCommentModel() {
    // this.pinCommentsService.modeForPinComment
    // .pipe(
    //   switchMap(res => {
    //     this.isReadOnly = res.readOnly;
    //     if (res.readOnly) {
    //       this.disableSave = true;
    //     } else {
    //       this.disableSave = false;
    //     }
    //     return (res.id > 0 ? this.pinCommentsService.getPinComment(this.pinCommentsService.participantPin, res.id) : of(null));
    //   })) 
    //   .subscribe(data => {
    //     if (data) {
    //       this.pinComment = data;
    //       this.initPinCommentTypesDrop();
    //       PinComment.clone(this.pinComment, this.cachedModel);
    //     } else {
    //       this.pinComment = new PinComment();
    //       this.pinComment.id = 0;
    //       this.initPinCommentTypesDrop();
    //       PinComment.clone(this.pinComment, this.cachedModel);
    //     }
    //   });
  }

  validate() {
    this.isSectionModified = true;
    if (this.hasTriedSave === true) {
      this.validationManager.resetErrors();
      let result = this.pinComment.validate(this.validationManager);
      this.isSectionValid = result.isValid;
      this.modelErrors = result.errors;
      if (this.modelErrors) {
        this.isSaving = false;
      }
    }
  }

  selectCommentTypes(commentTypeIds) {
    this.pinComment.commentTypeIds = commentTypeIds;
    this.pinComment.commentTypes = new Array<PinCommentType>();

    this.pinComment.commentTypeIds.forEach(id => {
      const pinCommentType = new PinCommentType();
      let fieldId = +id;
      pinCommentType.commentTypeId = +id;
      pinCommentType.commentTypeName = Utilities.fieldDataNameById(fieldId++, this.pinCommentTypesDrop);
      this.pinComment.commentTypes.push(pinCommentType);
    });
  }

  exitPCEditIgnoreChanges(e) {
    this.pinCommentsService.modeForPinComment.next({ readOnly: false, isInEditMode: false });
  }

  initPinCommentTypesDrop() {
    this.fdService.getPinCommentTypes().subscribe(res => {
      this.pinCommentTypesDrop = res;
      this.isLoaded = true;
    });
  }

  public exit() {
    if (this.isSectionModified) {
      this.appService.isUrlChangeBlocked = false;
      this.appService.isDialogPresent = true;
    } else {
      this.pinCommentsService.modeForPinComment.next({ readOnly: false, isInEditMode: false });
    }
  }

  save() {
    if (this.isSectionValid) {
      this.pinCommentsService.savePinComment(this.pinComment, this.pinCommentsService.participantPin).subscribe(res => {
        this.pinCommentsService.modeForPinComment.next({ readOnly: false, isInEditMode: false });
      });
    }
  }

  saveAndExit() {
    this.hasTriedSave = true;
    this.validate();
    this.save();
  }
}
