import { Component, OnInit } from '@angular/core';
import { Participant } from '../../../shared/models/participant';
import { ActivatedRoute } from '@angular/router';
import { Observable, forkJoin } from 'rxjs';
import { ParticipantService } from '../../../shared/services/participant.service';
import { PinCommentsService } from '../../../shared/services/pin-comments.service';
import { take, flatMap } from 'rxjs/operators';

@Component({
  selector: 'app-pin-comments-page',
  templateUrl: './pin-comments-page.component.html',
  styleUrls: ['./pin-comments-page.component.scss']
})
export class PinCommentsPageComponent implements OnInit {
  public goBackUrl: string;
  public isReadOnly: boolean;
  public isInEditMode: boolean;
  public canEdit: boolean;
  public canView: boolean;
  public pin: string;
  public pinComments: any[];
  public isLoaded = false;
  public participant: Participant;

  constructor(private route: ActivatedRoute, 
    private pinCommentsService: PinCommentsService, 
    private partService: ParticipantService) { }

  ngOnInit() {
    forkJoin(
      this.route.params.pipe(take(1)), 
      this.pinCommentsService.modeForPinComment.pipe(take(1)), 
      // this.partService.getCurrentParticipant().subscribe(
      //   result => {
      //     this.pin = result[0].pin;
      //     this.goBackUrl = '/pin/' + this.pin;
      //     this.isReadOnly = result[1].readOnly;
      //     this.isInEditMode = result[1].isInEditMode;
      //     this.participant = result[2];
      //     this.isLoaded = true;
      // }
    )
  }

}
