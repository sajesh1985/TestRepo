/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { ReleaseNotesComponent } from './release-notes.component';

// describe('Component: ReleaseNotes', () => {
//   it('should create an instance', () => {
//     let component = new ReleaseNotesComponent();
//     expect(component).toBeTruthy();
//   });
// });
