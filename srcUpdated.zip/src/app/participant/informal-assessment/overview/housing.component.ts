import { Component, OnInit, Input, OnChanges, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { BaseOverviewSecton } from '../overview/base-overview';
import { AppService } from '../../../shared/services/app.service';
import { InformalAssessment } from '../../../shared/models/informal-assessment';
import { ValidationManager } from '../../../shared/models/validation-manager';
import { InformalAssessmentService } from '../../../shared/services/informal-assessment.service';
import { ModalService } from '../../../shared/modal';
import { HousingSection } from '../../../shared/models/housing-section';
import { InformalAssessmentSectionName } from '../../../shared/enums/informal-assessment-section.enum';

@Component({
  selector: 'app-housing-overview',
  templateUrl: 'housing.component.html',
  styleUrls: ['./overview.css']
})
export class HousingOverviewComponent extends BaseOverviewSecton implements OnInit, OnChanges, OnDestroy {
  @Input()
  section: HousingSection;
  @Input()
  validationManager: ValidationManager;

  private routeSub: Subscription;

  constructor(
    public appService: AppService,
    public iaService: InformalAssessmentService,
    private route: ActivatedRoute,
    public modalService: ModalService,
    private router: Router
  ) {
    super(appService, iaService, modalService);
  }

  ngOnInit() {
    this.routeSub = this.route.params.subscribe(params => {
      this.pin = params['pin'];
    });
  }

  ngOnChanges() {
    if (this.section != null) {
      this.cachedSection = new HousingSection();
      HousingSection.clone(this.section, this.cachedSection);
    }
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }

  onEdit($event) {
    const route = `/pin/${this.pin}/assessment/edit/housing`;
    this.router.navigateByUrl(route);
  }

  public isEditAssessmentEnabled(): boolean {
    return this.section != null;
  }

  toggleHistory($event) {
    super.toggleHistory($event, 'housing', this.section, cs => {
      this.section = cs;
    });
    this.iaService.isHousingHistoryActive = this.isHistoryActive;
  }

  loadHistorySection($event) {
    if (this.isHistoryActive === true) {
      this.section = this.historyManager.getHistoryAtIndex($event);
    }
  }
}
