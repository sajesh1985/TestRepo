/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { SummaryComponent } from './summary.component';

// describe('Component: Summary', () => {
//   it('should create an instance', () => {
//     let component = new SummaryComponent();
//     expect(component).toBeTruthy();
//   });
// });
