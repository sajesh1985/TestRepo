/* tslint:disable:no-unused-variable */

// import { TestBed, async } from '@angular/core/testing';
// import { TextAreaComponent } from './text-area.component';

// describe('Component: TextArea', () => {
//   it('should create an instance', () => {
//     let component = new TextAreaComponent();
//     expect(component).toBeTruthy();
//   });
// });
